﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.EntityClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Helper
{
    public class ConnectionStringChanger
    {

        public static String BuildConnectionString()
        {
            String DataSource = Program.NTC_ServerName;
            String Database = Program.NTC_DBName;
            String user_name = Program.NTC_dbuserName;
            String pass_word = Program.NTC_dbpassword;
            String IntegSecurity = "SSPI";
            String PerSecurity = "False";

            // Build the connection string from the provided datasource and database
            //String connString = @"data source=" + DataSource +
            //    ";initial catalog=" + Database + ";user id=" + user_name + ";password=" + pass_word + 
            //    ";integrated security=" + IntegSecurity + ";MultipleActiveResultSets=True;App=EntityFramework;";


            String connString = @"data source=" + DataSource + ";initial catalog=" + Database + ";user id=" + user_name + ";password=" + pass_word + ";MultipleActiveResultSets=True;App=EntityFramework;";

            // Build the MetaData... feel free to copy/paste it from the connection string in the config file.
            EntityConnectionStringBuilder esb = new EntityConnectionStringBuilder();
            esb.Metadata = "res://*/Data.NTC_Model.csdl|res://*/Data.NTC_Model.ssdl|res://*/Data.NTC_Model.msl";

            esb.Provider = "System.Data.SqlClient";
            esb.ProviderConnectionString = connString;

            // Generate the full string and return it
            return esb.ToString();
        }
    }
}
