﻿namespace NTC_Consolidator.ReportSource
{


    partial class dszeroassetsize
    {
        partial class dszeroassetsizeDataTable
        {

        }
    }
}
