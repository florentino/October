﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmExcelTemplate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExecute = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // btnExecute
            // 
            this.btnExecute.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnExecute.Location = new System.Drawing.Point(194, 325);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(52, 23);
            this.btnExecute.TabIndex = 87;
            this.btnExecute.Text = "&Close";
            this.btnExecute.UseCustomBackColor = true;
            this.btnExecute.UseCustomForeColor = true;
            this.btnExecute.UseSelectable = true;
            this.btnExecute.UseStyleColors = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(27, 83);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(127, 19);
            this.metroLabel2.TabIndex = 92;
            this.metroLabel2.Text = "Download Template";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.Location = new System.Drawing.Point(193, 124);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(55, 13);
            this.linkLabel1.TabIndex = 93;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Download";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(27, 121);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(97, 19);
            this.metroLabel1.TabIndex = 94;
            this.metroLabel1.Text = "1. APL Account";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(27, 142);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(132, 19);
            this.metroLabel3.TabIndex = 96;
            this.metroLabel3.Text = "2. NTC Consolidator ";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel2.Location = new System.Drawing.Point(193, 145);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(55, 13);
            this.linkLabel2.TabIndex = 95;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Download";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(27, 163);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(130, 19);
            this.metroLabel4.TabIndex = 98;
            this.metroLabel4.Text = "3. Corresponding GL";
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel3.Location = new System.Drawing.Point(193, 166);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(55, 13);
            this.linkLabel3.TabIndex = 97;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "Download";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(27, 184);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(70, 19);
            this.metroLabel5.TabIndex = 100;
            this.metroLabel5.Text = "4. Daily GL";
            // 
            // linkLabel4
            // 
            this.linkLabel4.AutoSize = true;
            this.linkLabel4.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel4.Location = new System.Drawing.Point(193, 187);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(55, 13);
            this.linkLabel4.TabIndex = 99;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "Download";
            this.linkLabel4.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel4_LinkClicked);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(27, 205);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(128, 19);
            this.metroLabel6.TabIndex = 102;
            this.metroLabel6.Text = "5. Migrated Account";
            // 
            // linkLabel5
            // 
            this.linkLabel5.AutoSize = true;
            this.linkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel5.Location = new System.Drawing.Point(193, 208);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(55, 13);
            this.linkLabel5.TabIndex = 101;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "Download";
            this.linkLabel5.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel5_LinkClicked);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(27, 226);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(125, 19);
            this.metroLabel7.TabIndex = 104;
            this.metroLabel7.Text = "6. Past Due Account";
            // 
            // linkLabel6
            // 
            this.linkLabel6.AutoSize = true;
            this.linkLabel6.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel6.Location = new System.Drawing.Point(193, 229);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(55, 13);
            this.linkLabel6.TabIndex = 103;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "Download";
            this.linkLabel6.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel6_LinkClicked);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(27, 247);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(116, 19);
            this.metroLabel8.TabIndex = 106;
            this.metroLabel8.Text = "7. Under Litigation";
            // 
            // linkLabel7
            // 
            this.linkLabel7.AutoSize = true;
            this.linkLabel7.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel7.Location = new System.Drawing.Point(193, 250);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(55, 13);
            this.linkLabel7.TabIndex = 105;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "Download";
            this.linkLabel7.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel7_LinkClicked);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(27, 270);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(167, 19);
            this.metroLabel9.TabIndex = 108;
            this.metroLabel9.Text = "8. Dollar Rate And Account";
            // 
            // linkLabel8
            // 
            this.linkLabel8.AutoSize = true;
            this.linkLabel8.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel8.Location = new System.Drawing.Point(193, 273);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Size = new System.Drawing.Size(55, 13);
            this.linkLabel8.TabIndex = 107;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Text = "Download";
            this.linkLabel8.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel8_LinkClicked);
            // 
            // frmExcelTemplate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(275, 369);
            this.Controls.Add(this.metroLabel9);
            this.Controls.Add(this.linkLabel8);
            this.Controls.Add(this.metroLabel8);
            this.Controls.Add(this.linkLabel7);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.linkLabel6);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.linkLabel5);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.linkLabel4);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.linkLabel3);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.btnExecute);
            this.MaximizeBox = false;
            this.Name = "frmExcelTemplate";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "NTC Excel Template";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmExcelTemplate_FormClosed);
            this.Load += new System.EventHandler(this.frmExcelTemplate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton btnExecute;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private System.Windows.Forms.LinkLabel linkLabel8;
    }
}