﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmDailyGL : MetroFramework.Forms.MetroForm
    {

        private IDailyGL dailyGLRepository;
        private static frmDailyGL frmdailyGL = null;

        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtDailyGL = new DataTable();
        string ErrorID = "";
        //DataTable dtupdated = new DataTable("Updated");
        NumberStyles styles;
        DateTime dateparam;
        string[] progressArray = new string[5];
        bool isNoData = false;

        public static frmDailyGL Instance()
        {
            if (frmdailyGL == null)
            {
                frmdailyGL = new frmDailyGL();
            }
            return frmdailyGL;
        }

        public frmDailyGL()
        {
            InitializeComponent();
            this.dailyGLRepository = new DailyGLRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
            pnlWaitInfo.Location = new Point(this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2, this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            lblBusy.Text = "";
        }

        private void frmDailyGL_Load(object sender, EventArgs e)
        {
            //lblWaitInfo.Text = "Fetching Data from server, Please wait...";
            //lblWaitStatus.Text = "Status: Processing...";

            //pnlWaitInfo.Visible = true;

            //retrieveWorker = new BackgroundWorker();
            //retrieveWorker.WorkerReportsProgress = true;
            //retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
            //retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
            //retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
            //retrieveWorker.WorkerSupportsCancellation = true;
            //retrieveWorker.RunWorkerAsync();

            btnExecute.Enabled = dtDailyGL.Rows.Count > 0 ? true : false;

        }

        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Fetching Data from server, Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (isNoData)
                {
                    isNoData = false;
                    MetroMessageBox.Show(this, "\r\n\r\nDaily GL excel files contains no data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                return;
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (e.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else if (e.ToString().Contains("External table is not in the expected format"))
                {
                    MetroMessageBox.Show(this, "\r\nPlease save first the file with the extension name of \".xls\".\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else
                {
                    ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                    var Modulename = this.GetType().FullName;
                    var methodName = MethodBase.GetCurrentMethod().Name;
                    ErrorLog.GetLogFilePath(e.Error, Modulename, methodName, ErrorID);

                    MetroMessageBox.Show(this, "ERROR LogID: " +  ErrorID + "\r\nError Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                btnExecute.Enabled = dtDailyGL.Rows.Count > 0 ? true : false;
                lblInfo.Text = "Total Records: " + string.Format("{0:n0}", dtDailyGL.Rows.Count);
                dgvPastDueAccount.DataSource = dtDailyGL;
                pnlWaitInfo.Visible = false;
            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                var invalidExcel = false;
                string connString = "";

                if (Path.GetExtension(txtFilePath.Text) == ".xls")
                    connString = string.Format("Provider = Microsoft.Jet.OLEDB.4.0;Data Source={0};" + "Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);

                if (Path.GetExtension(txtFilePath.Text) == ".xlsx")
                {
                    // connString = string.Format("Provider = Microsoft.ACE.OLEDB.12.0;Data Source={0};" + "Extended Properties='Excel 12.0 Xml;HDR=NO;IMEX=1;'", txtFilePath.Text);

                    MetroMessageBox.Show(this, "\r\nPlease change the file format from XLSX to XLS.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                // string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();


                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM[" + worksheetname + "] WHERE [F1] <> ''", conn);


                    DataTable dtold = new DataTable(worksheetname);
                    da.Fill(dtold);

                    dtold.Rows.RemoveAt(0);
                    dtold.Rows.RemoveAt(0);
                    dtold.Rows.RemoveAt(0);
                    dtold.Rows.RemoveAt(0);

                    foreach (DataColumn dc in dtold.Columns)
                    {
                        var name = dtold.Rows[0][dc].ToString().Trim().ToUpper();
                        // var newname = Regex.Replace(name, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToUpper();
                        dc.ColumnName = name;
                    }

                    dtold.Rows.RemoveAt(0);

                    if (dtold.Rows.Count <= 0)
                    {
                        if (retrieveWorker.IsBusy)
                        {
                            isNoData = true;
                            e.Cancel = true;
                            retrieveWorker.CancelAsync();
                            
                        }
                    }
                    

                    var requiredColumns = new HashSet<string>
                    { "GMACT", "GMCURC", "GMCNTR", "GMNAME", "GMCBAL", "GMFCYE", "GMEMO", "GFEMO", "GMYBAL", "GMFCYY" };

                    for (int i = 0; i < dtold.Columns.Count; i++)
                    {
                        string colname = dtold.Columns[i].ColumnName;
                        if (!requiredColumns.Contains(colname.Trim()))
                        {
                            invalidExcel = true;
                        }
                    }
                    if (invalidExcel)
                    {
                        throw new Exception("does not belong to table");
                    }



                   
                    progressArray[0] = (1 * 100 / dtold.Rows.Count).ToString(); // percent
                    progressArray[1] = "Loading records, Please wait..."; //header text
                    progressArray[2] = "Status: In-progress"; //Status
                    progressArray[3] = "";// i.ToString(); //column
                    progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                    retrieveWorker.ReportProgress(1 * 100 / dtold.Rows.Count, progressArray); // wla lng, just to show the loading information
                    dtDailyGL = dtold;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void table()
        {
            dtDailyGL.Columns.Add("GMACT");
            dtDailyGL.Columns.Add("GMCURC");
            dtDailyGL.Columns.Add("GMCNTR");
            dtDailyGL.Columns.Add("GMNAME");
            dtDailyGL.Columns.Add("GMCBAL");
            dtDailyGL.Columns.Add("GMFCYE");
            dtDailyGL.Columns.Add("GMEMO");
            dtDailyGL.Columns.Add("GFEMO");
            dtDailyGL.Columns.Add("GMYBAL");
            dtDailyGL.Columns.Add("GMFCYY");
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Please wait, While loading excel file.";
            lblWaitStatus.Text = "Status: Processing...";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlWaitInfo.Visible = true;

                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
           
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Saving records, Please wait...";
            lblWaitStatus.Text = "Status: In-progress...";

            #region Remove Negative(-) Amount inside the parentheses
            styles = NumberStyles.AllowParentheses | NumberStyles.AllowTrailingSign | NumberStyles.Float | NumberStyles.AllowThousands;
            #endregion
            saveWorker = new BackgroundWorker();
            saveWorker.WorkerReportsProgress = true;
            saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
            saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
            saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
            saveWorker.WorkerSupportsCancellation = true;
            saveWorker.RunWorkerAsync();
        }


        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var asa = "";
            try
            {
                var isDeleted = false;
                var iCount = 1;
                foreach (DataRow dritem in dtDailyGL.Rows)
                {
                    BDOLF_DailyGL data = new BDOLF_DailyGL();

                    if (dritem["GMACT"].ToString() == "110400100500")
                    { }
                    // var _System = dritem["SYSTEM"].ToString();
                   
                    #region Data
                    progressArray[0] = (iCount * 100 / dtDailyGL.Rows.Count).ToString(); // percent
                    progressArray[1] = "Saving records, Please wait..."; //header text
                    progressArray[2] = "Status: In-progress"; //Status
                    progressArray[3] = "";// i.ToString(); //column
                    progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                    //  item.AO = (entityToInsert["AO"].ToString() == "" || entityToInsert["AO"].ToString() == "--") ? "" : entityToInsert["AO"].ToString();
                    data.GMACT = (dritem["GMACT"].ToString() == "" || dritem["GMACT"].ToString() == "--" || dritem["GMACT"].ToString() == "-") ? "" : dritem["GMACT"].ToString();
                    data.isDeleted = false;
                    data.CreatedBy = frmConsolidator.UserName;
                    data.CreatedDate = DateTime.Today;

                    

                    data.GMCURC = (dritem["GMCURC"].ToString() == "" || dritem["GMCURC"].ToString() == "--" || dritem["GMCURC"].ToString() == "-") ? 0 : Convert.ToInt32(dritem["GMCURC"].ToString()); 
                    data.GMCNTR = (dritem["GMCNTR"].ToString() == "" || dritem["GMCNTR"].ToString() == "--" || dritem["GMCNTR"].ToString() == "-") ? 0 : Convert.ToInt32(dritem["GMCNTR"].ToString()); 
                    data.GMNAME = (dritem["GMNAME"].ToString() == "" || dritem["GMNAME"].ToString() == "--" || dritem["GMNAME"].ToString() == "-") ? "" : dritem["GMNAME"].ToString();
                    //data.GMCBAL = (dritem["GMCBAL"].ToString() == "" || dritem["GMCBAL"].ToString() == "--" || dritem["GMCBAL"].ToString() == "-") ? 0M : GetOutputStramount(styles, dritem["GMCBAL"].ToString().Trim());

                    //var amountTotalLoan = dtold.Rows[irowCount]["Total Loan"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Total Loan"].ToString().Trim();
                    //dr["TotalLoan"] = ((GetOutputStramount(styles, amountTotalLoan)) * currencyRate).ToString("#,0.00");


                    var GMCBAL = (dritem["GMCBAL"].ToString() == "" || dritem["GMCBAL"].ToString() == "-") ? "0" : dritem["GMCBAL"].ToString().Trim();
                    data.GMCBAL = GetOutputStramount(styles, GMCBAL);

                    var GMFCYE = (dritem["GMFCYE"].ToString() == "" || dritem["GMFCYE"].ToString() == "--" || dritem["GMFCYE"].ToString() == "-") ? "0" : dritem["GMFCYE"].ToString().Trim();
                    data.GMFCYE = GetOutputStramount(styles, GMFCYE);

                    var GMEMO = (dritem["GMEMO"].ToString() == "" || dritem["GMEMO"].ToString() == "--" || dritem["GMEMO"].ToString() == "-") ? "0" : dritem["GMEMO"].ToString().Trim();
                    data.GMEMO = GetOutputStramount(styles, GMEMO);

                    var GFEMO = (dritem["GFEMO"].ToString() == "" || dritem["GFEMO"].ToString() == "--" || dritem["GFEMO"].ToString() == "-") ? "0" : dritem["GFEMO"].ToString().Trim();
                    data.GFEMO = GetOutputStramount(styles, GFEMO);

                    var GMYBAL = (dritem["GMYBAL"].ToString() == "" || dritem["GMYBAL"].ToString() == "--" || dritem["GMYBAL"].ToString() == "-") ? "0" : dritem["GMYBAL"].ToString().Trim();
                    data.GMYBAL = GetOutputStramount(styles, GMYBAL);

                    var GMFCYY = (dritem["GMFCYY"].ToString() == "" || dritem["GMFCYY"].ToString() == "--" || dritem["GMFCYY"].ToString() == "-") ? "0" : dritem["GMFCYY"].ToString().Trim();
                    data.GMFCYY = GetOutputStramount(styles, GMFCYY);

                    //data.GMFCYE = (dritem["GMFCYE"].ToString() == "" || dritem["GMFCYE"].ToString() == "--" || dritem["GMFCYE"].ToString() == "-") ? 0M : GetOutputStramount(styles, dritem["GMFCYE"].ToString().Trim());
                    //data.GMEMO = (dritem["GMEMO"].ToString() == "" || dritem["GMEMO"].ToString() == "--" || dritem["GMEMO"].ToString() == "-") ? 0M : GetOutputStramount(styles, dritem["GMEMO"].ToString().Trim());
                    //data.GFEMO = (dritem["GFEMO"].ToString() == "" || dritem["GFEMO"].ToString() == "--" || dritem["GFEMO"].ToString() == "-") ? 0M : GetOutputStramount(styles, dritem["GFEMO"].ToString().Trim());
                    //data.GMYBAL = (dritem["GMYBAL"].ToString() == "" || dritem["GMYBAL"].ToString() == "--" || dritem["GMYBAL"].ToString() == "-") ? 0M : GetOutputStramount(styles, dritem["GMYBAL"].ToString().Trim());
                    //data.GMFCYY = (dritem["GMFCYY"].ToString() == "" || dritem["GMFCYY"].ToString() == "--" || dritem["GMFCYY"].ToString() == "-") ? 0M : GetOutputStramount(styles, dritem["GMFCYY"].ToString().Trim());
                    #endregion
                    asa = data.GMACT;
                    //
                    if (!isDeleted)
                    {
                        dailyGLRepository.DeleteGL(data);
                        isDeleted = true;
                    }

                    dailyGLRepository.InsertRecord(data);
                    saveWorker.ReportProgress(iCount++ * 100 / dtDailyGL.Rows.Count, progressArray); // wla lng
                }
            }
            catch (Exception ex)
            {
                var df = asa;
                if (ex.TargetSite.MetadataToken == 100666133)
                {
                    throw new Exception("does not belong to table");
                }
                else
                    throw ex;
            }
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                lblWaitStatus.Text = "Status: Error Encountered while processing";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\nDaily GL File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                    var Modulename = this.GetType().FullName;
                    var methodName = MethodBase.GetCurrentMethod().Name;
                    ErrorLog.GetLogFilePath(e.Error, Modulename, methodName, ErrorID);

                    MetroMessageBox.Show(this, "ERROR LogID: " +  ErrorID + "\r\nError Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while saving the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                return;
            }
            else
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "DONE";
                lblWaitStatus.Text = "Status: Success";

                MetroMessageBox.Show(this, "\r\nDaily GL data was successfully inserted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitStatus.Text = labelsreports[2].ToString();
            lblWaitInfo.Text = labelsreports[1].ToString();
        }

        private void frmDailyGL_FormClosing(object sender, FormClosingEventArgs e)
        {
            //frmConsolidator frmreload = new frmConsolidator();
            //frmreload.GetConsolidator();

            frmDailyGL.frmdailyGL = null;
        }

        private static decimal GetOutputStramount(NumberStyles styles, string amount)
        {
            var _amount = decimal.Parse(amount, styles).ToString("#,0.00;-#,0.00");
            return decimal.Parse(_amount);
        }


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                var retVal = DownloadExcelTemplate.DownloadTemplate("Daily GL");
                if (retVal == 1)
                {
                    MetroMessageBox.Show(this, "\r\nDaily GL excel Template was successfully downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                var Modulename = this.GetType().FullName;
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID);

                MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while downloading the template, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
