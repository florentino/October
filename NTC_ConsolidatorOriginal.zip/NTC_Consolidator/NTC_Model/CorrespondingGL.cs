﻿using System;
using System.ComponentModel.DataAnnotations;

namespace NTC_Consolidator.Model
{
    public class CorrespondingGL
    {
        private int _GLID;
        private string _GLCode;
        private string _GLName;
        private DateTime _CreatedDate;
        private string _CreatedBy;
        private string _System;
        private string _Status;
        private string _ProductDesc;
        private bool _isDeleted;

        public bool isDeleted
        {
            get { return _isDeleted; }
            set { _isDeleted = value; }
        }


        public int GLID
        {
            get { return _GLID; }
            set { _GLID = value; }
        }

        public string CreatedBy
        {
            get { return _CreatedBy; }
            set { _CreatedBy = value; }
        }

        public DateTime CreatedDate
        {
            get { return _CreatedDate; }
            set { _CreatedDate = value; }
        }

        [Required(ErrorMessage = "GL Name is required.")]
        public string GLName
        {
            get { return _GLName; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "GLName" });
                _GLName = value;
            }
        }

        [Required(ErrorMessage = "GL Code is required.")]
        public string GLCode
        {
            get { return _GLCode; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "GLCode" });
                _GLCode = value;
            }
        }

        [Required(ErrorMessage = "System Tagging is required.")]
        public string System
        {
            get { return _System; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "System" });
                _System = value;
            }
        }

        [Required(ErrorMessage = "Status is required.")]
        public string Status
        {
            get { return _Status; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "Status" });
                _Status = value;
            }
        }

        [Required(ErrorMessage = "Status is required.")]
        public string ProductDesc
        {
            get { return _ProductDesc; }
            set
            {
                Validator.ValidateProperty(value, new ValidationContext(this, null, null) { MemberName = "ProductDesc" });
                _ProductDesc = value;
            }
        }
    }
}
