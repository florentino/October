﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
   public interface IDailyGL
    {
        IEnumerable<BDOLF_DailyGL> GetAll();
        BDOLF_DailyGL GetByAccountNo(int AccountNo);
        BDOLF_DailyGL GetByAccountNo(string AccountNo);
        void InsertRecord(BDOLF_DailyGL DailyGLData);
        void UpdateDailyGL(BDOLF_DailyGL DailyGLData);
        bool AccountNotExists(string AccountNo, string System);
        void DeleteGL(BDOLF_DailyGL GLData);
        DateTime GetDate();
        void Save();
    }
}
