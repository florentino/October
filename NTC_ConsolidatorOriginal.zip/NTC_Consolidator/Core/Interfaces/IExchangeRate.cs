﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface IExchangeRate : IDisposable
    {

        IEnumerable<BDOLF_ExchangeRate> GetAll();
        BDOLF_ExchangeRate GetByID(int CurrencyID);
        BDOLF_ExchangeRate GetByCode(string CurrencyCode);
        BDOLF_ExchangeRate GetByCode(string CurrencyCode, string date);
        void InsertRate(BDOLF_ExchangeRate rate);
        void DeleteRate(int CurrencyID);
        void TruncateTable();
        void DeleteRate(string CurrencyCode);
        void UpdateRate(BDOLF_ExchangeRate rate);
        void BulkInsert(object objdata);
        void BulkDelete(object objdata);
        void BulkUpdete(object objdata);
        void Save();
    }
}
