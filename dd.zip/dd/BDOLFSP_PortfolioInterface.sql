SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/* 
 =============================================
 Author:			RTS / DJQ / ACM / VAH / CVG
 Version:			1.6.0.1
 Create date:		01/20/2015
 Update Date:		01/26/2018
 P2P Date:			03/12/2018
 Update Details:	- 1.1.0.0(RTS): Add ne columns (Asset Value, Asset Type, Approve Amount, CP number)
					- 1.2.0.0(DJQ): Update retrieval of asset value for the matured accounts, must consider original contract id
					- 1.3.0.0(DJQ): Update in total loan to eliminate the negative amount
								  Include the flow type balloon payment in computation of OB
                    - 1.4.0.0(ACM): DOSRI to RPT Classification
								  Expand the maximum lengt of Collateral column	
					- 1.5.0.0(VAH): Added "-NPL" on CurrStat for contracts tagged as NPL
					- 1.6.0.1(CVG): Added "Control Unit" to distinguish accounts, point ASSET Value to a function
 =============================================
*/


/*
Field List: 
#01 - Account No. 			#21 - Remaining Term					#41 - Borrower Type				#61 - Last Interest Pay Date		#81 - Penalty Rate
#02 - Account Ref.			#22 - Original Amortization				#42 - Nationality				#62 - Paid Interest Month			#82 - Asset Cost
#03 - Client Name			#23 - Payment Schedule Amortization 	#43 - Asset Size				#63 - Income Last Month				#83 - Tax Exemption
#04	- Account Officer		#24 - Reprice Date 	 					#44 - Payment Frequency			#64 - Income This Month				#84 - Trade As
#05	- Facility Code			#25 - Reprice Amortization 				#45 - Business Unit				#65 - GL Code						#85 - Input VAT
#06	- Contract State		#26 - Amortization After Last Reprice	#46 - Arrears/Advance			#66 - GL Description				#86 - ICBS Codes
#07	- Current Status		#27 - Next Review Date 					#47 - Original Principal		#67 - Originating Branch		    #87 - Asset Value
#08	- Value Date			#28 - Frequenct Expected Reprice 		#48 - Principal					#68 - Cost Center			        #88 - Approved Amount  
#09	- First Due Date		#29 - Rate Type 						#49 - UDI Balance				#69 - Branch Per Cost Center	    #89 - CP Number
#10	- Maturity Date			#30 - Last Month UDI 					#50 - AIR						#70 - Party Nationality				#90 - Control Unit
#11 - Total Loan			#31 - Orig GD less PVGD					#51 - GDRV Comparison			#71 - Tax ID	
#12 - Outstanding Balance	#32 - Past Due Date						#52 - PV Rate					#72 - Currency
#13 - Monthly O.B.			#33 - Industry Code						#53 - Principal Previous Month	#73 - Borrower Type Entity
#14 - UDI					#34 - DOSRI								#54 - ITL Date					#74 - Dealer
#15 - Earned Interest		#35 - REE Code							#55 - Endorsed RMU Date			#75 - Supplier Refeference
#16 - ERV					#36 - REL Code							#56 - RMU Date					#76 - Supplier TIN
#17 - GD					#37 - REE Additional Info				#57 - Penalty					#77 - Client Code
#18 - Effective Rate		#38 - Industry Header					#58 - Last Principal Pay		#78 - Type Of Lease
#19 - E.Y. After Reprice	#39 - Industry Details					#59 - Last Principal Pay Date	#79 - Product Type
#20 - Term					#40 - Collateral						#60 - Last Interest Pay			#80 - Last Interest Rate
*/
ALTER PROCEDURE [dbo].[BDOLFSP_PortfolioInterface] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
declare @cutoffdate datetime
set @cutoffdate =getdate()
Declare @tempAgingTable Table  
(  
acctno int, acctref varchar(2000),clientname varchar(2000), AO varchar(2000), facilitycode varchar(2000),  
stat varchar(2000),CurrentStat varchar(2000), valuedate date, firstduedate date, maturitydate date,  
totalloan decimal(20,2), OB decimal(20,2), monthlyOB decimal(20,2), orgiudibal decimal(20,2),  
addearnedint decimal(20,2), origERV decimal(20,2),  
origGD decimal(20,2),   
effrate decimal(20,2), eyafterreprice decimal(20,2), term decimal(20,2), remterm decimal(20,2),  
origamort decimal(20,2), payschedamort decimal(20,2), repricedate date, repriceamort decimal(20,2),  
amortafterlastreprice decimal(20,2), nxtratereviewdt date, freqexpectedreprice varchar(2000), ratetype varchar(2000),  
lastmonthUDI decimal(20,2), origGDlessPVGD decimal(20,2),   
pastduedate date, industrycode varchar(2000),DOSRI varchar(2000), REECode varchar(2000), RELCode varchar(2000),   
REEAddtlInfo varchar(2000), industryhdr varchar(2000), industrydet varchar(2000),  
Collateral varchar(max), BorrowerType varchar(2000), Nationality varchar(2000),  
assetsize varchar(2000), payfreq varchar(2000), BU varchar(2000), ArrearsAdvance varchar(2000), OrigPrincipal decimal(20,2),  
Principal Decimal(20,2), UDIBal decimal(20,2), AIR decimal(20,2), GDRVComparison varchar(2000),  
PVRate decimal(20,2), PrincipalPrevMonth decimal(20,2), ITLDate date, EndorsedRMUDate date, RMUDate date,  
Penalty decimal(20,2), LastPrincipalPay decimal(20,2), LastPrincipalPayDate date, LastInterestPay decimal(20,2), LastInterestPayDate date,  
PaidInterestMonth decimal(20,2),IncomeLastMonth decimal(20,2),IncomeThisMonth decimal(20,2),  
GLCode varchar(2000), GLDesc varchar(2000), OriginatingBranch varchar(2000), CostCenter nvarchar(2000), BranchPerCostCenter varchar(2000),  
PartyNationality varchar(2000), TaxID varchar(2000), Currency varchar(2000), BorrowerTypeEntity varchar(2000), Dealer varchar(8000),SupRef varchar(8000),  
SupplierTIN nvarchar(max), CCode nvarchar(2000), TypeOfLease varchar(2000), ProdType varchar(2000), LastIntRate decimal(20,2),  
PenaltyRate decimal(20,2), AssetCost decimal(20,2), TaxExemption varchar(2000), TradeAs nvarchar(2000), InputVAT decimal(20,2)
,Asset_Type varchar(2000), Asset_Value decimal(20,2), Approved_Amount decimal(20,2),CP_Number varchar(2000),Control_Unit varchar(2000)
) 
 

declare @FirstDayOfMonth date  
declare @LastDayOfMonth date  
DECLARE @LastDayOfLastMonth date
  
set @FirstDayOfMonth = CONVERT(varchar(max),dateadd(dd,-(day(@cutoffdate)-1),@cutoffdate),101)  
set @LastDayOfMonth = DATEADD(DAY,-1,DATEADD(month,month(@FirstDayOfMonth),dateadd(year,year(@FirstDayOfMonth)-1900,0)))  
set @LastDayOfLastMonth = DATEADD(DAY,-1,DATEADD(month,month(DATEADD(month,-1,@FirstDayOfMonth)),dateadd(year,year(DATEADD(month,-1,@FirstDayOfMonth))-1900,0)))  


insert into @tempAgingTable  
SELECT DISTINCT  
-- AccountNumber  #01#
       acv.contract_id AccountNumber,          

-- Account Reference  #02#
        acv.reference AccountRef,  
        
-- ClientName  #03#
    acv.party_ext_name ClientName,  
    
-- AO  #04#
    pc.field_value AO,  
    
-- FacilityCode  #05#
    acv.product FacilityCode,  
      
-- Status  #06#
    acv.contract_state_value Status,  
      
-- Current/Past Due/ITL/ROPA/Write-Off  #07#
     'Current' CurrentStatus,  
      
-- ValueDate  #08#
    acv.calc_dt ValueDate,     

-- FirstDueDate  #09#
    (SELECT top 1 calc_dt   
     FROM asset_price_segment  
     WHERE contract_id = acv.contract_id  
     ORDER BY calc_dt asc) FirstDueDate,  

-- MaturityDate  #10#
    CASE WHEN acv.Business_unit = 'BDOLF'
    THEN acv.maturity_dt
    ELSE (SELECT top 1 residual_value_delay_dt
		  FROM asset
		  WHERE contract_id = acv.contract_id)
    END MaturityDate,    
      
-- TotalLoan  #11#
   CASE WHEN (SELECT ISNULL((SELECT CAST(field_value as decimal(20,2))
			   FROM contract_cfv
			   WHERE contract_id = acv.contract_id
			   AND contract_cfd_id = (SELECT contract_cfd_id
									  FROM contract_cfd
									  WHERE name like '%FPMS Orig Total Loan%')),0)) = 0
		 THEN CASE WHEN acv.Business_Unit = 'BDOLF'
				   THEN(ISNULL((select TOP 1 ge.amount from gl_entry ge
						inner join contract c
						on c.contract_id = ge.contract_id
						and ge.post_dt = c.calc_dt
						where ge.contract_id = acv.contract_id
						and gl_tag_id = 37 order by ge.post_dt,ge.amount desc),0)) 
					ELSE (ISNULL((select TOP 1 ge.amount from gl_entry ge
						  inner join contract c
						  on c.contract_id = ge.contract_id
						  and ge.post_dt = c.calc_dt
						  where ge.contract_id = acv.contract_id
						  and gl_tag_id = 5 order by ge.post_dt,ge.amount desc),0)) 
					END 
		 ELSE (SELECT ISNULL((SELECT field_value
			   FROM contract_cfv
			   WHERE contract_id = acv.contract_id
			   AND contract_cfd_id = (SELECT contract_cfd_id
									  FROM contract_cfd
									  WHERE name like '%FPMS Orig Total Loan%')),0))
	 END TotalLoan,          

-- OB  #12#
    0 OB,  
 
     -- Monthly OB  #13#
    0 Monthly_OB,      

-- OriginalUDI  #14#   
	case when isnull((select sum(ge.amount) * -1 from gl_entry ge
	inner join contract c
	on c.contract_id = ge.contract_id
	and ge.post_dt = c.calc_dt
	and ge.narration = 'Unearned Interest'
	where ge.contract_id = acv.contract_id
	and gl_tag_id = 2),0) =0
	then (SELECT sum(amt_interest) 
		  from flow 
		  where contract_id = acv.contract_id
		  and flow_type in(1003,1043)
		  and is_cash  = 1 )
	else (select CASE WHEN sum(ge.amount) < 0 
					   THEN sum(ge.amount) * -1 
					   ELSE sum(ge.amount) 
					   END
		  from gl_entry ge
		 inner join contract c
		 on c.contract_id = ge.contract_id
		and ge.post_dt = c.calc_dt
		and ge.narration = 'Unearned Interest'
		where ge.contract_id = acv.contract_id
		and gl_tag_id = 2)
	end OriginalUDI, 
      
-- AdditionEarnedInterest  #15#
    0 AdditionEarnedInterest,  

-- Original_ERV  #16#
    0 Original_ERV,    

-- Original_GD  #17#
    b.gdAmount Original_GD,    

-- Effective_Rate  #18#
    acv.interest_rate Effective_Rate,  

-- EYAfterReprice  #19#
   (SELECT TOP 1 CASE WHEN acv.Contract_State <> 11160 
			 THEN (isnull(margin_rate,0))  
				 ELSE 0
				 END
     FROM price_segment_templ   
     WHERE price_schedule_id = (SELECT rates_price_schedule_id   
                                FROM contract   
                                WHERE contract_id = acv.contract_id)  
     AND calc_dt < GETDATE()  
     ORDER BY segment_no desc) EYAfterReprice,  
      
-- Term  #20#
    -- cast(round(acv.term / 30.5, 0) AS int)
	CASE WHEN acv.Business_Unit = 'BDOLF'
	THEN cast(round(acv.term / 30.5, 0) AS int) 
	ELSE (datediff(month,acv.calc_dt,(SELECT top 1 residual_value_delay_dt
		  FROM asset
		  WHERE contract_id = acv.contract_id)))
    END Term,

-- Remaining_term   #21#
    CASE WHEN DATEDIFF(Month,@cutoffdate,acv.maturity_dt)<= 0 OR acv.Contract_State = 11160 
    THEN 0
    ELSE case when @cutoffdate < acv.calc_dt 
         then acv.term_months
         else DATEDIFF(Month,@cutoffdate,acv.maturity_dt)
         end 
    END Remaining_term,        
       
-- Original_Amortization   #22#
    (SELECT top 1 amount
     FROM flow   
    WHERE contract_id = acv.contract_id   
     AND is_cash = 1 
     AND flow_type in(1003)
     AND amount > 0
     ORDER BY installment_no asc) Original_Amortization,  
       
-- PaymentSchedAmort  #23#
    --(SELECT CASE WHEN acv.Contract_State <> 11160 
    --        THEN sum(amt_base_repayment)   
    --        ELSE 0
    --        END
    -- FROM axvw_asset   
    -- WHERE contract_id = acv.contract_id
    -- and terminated_dt > @cutoffdate
    -- and calc_dt < @cutoffdate) PaymentSchedAmort,  
    (select top 1 amount from flow where contract_id = acv.contract_id
	 and is_cash = 1 and flow_type in(1003,1043)
	 and calc_dt <= @cutoffdate
	 order by calc_dt desc)PaymentSchedAmort,  
       
-- RepriceDate  #24#
    (SELECT TOP 1 CASE WHEN (isnull(calc_dt,''))  = acv.calc_dt OR acv.contract_state = 11160
				  THEN ''
				  ELSE isnull(calc_dt,'')
				  END
     FROM price_segment_templ   
     WHERE price_schedule_id = (SELECT rates_price_schedule_id   
                                FROM contract   
                                WHERE contract_id = acv.contract_id)  
     AND calc_dt < GETDATE()  
     ORDER BY segment_no desc) RepriceDate,  
  
-- RepriceAmort  #25#
    0 RepriceAmort,  
	
-- AmortAfterLastReprice    #26# 
    0 AmortAfterLastReprice,  
      
-- NextReviewDate  #27#
    null NextReviewDate,   

-- FreqExpectedReprice   #28#   
    CASE WHEN acv.contract_state <> 11160 
    THEN acv.rateset_freq_value 
    ELSE 'None' 
    END FreqExpectedReprice,  
      
-- RateType  #29#
    acv.fixed_floating_value RateType,        
      
-- LastMonthUDI  #30#
    0 LastMonthUDI,  
      
-- OrigGDLessPVGD  #31#
    (SELECT SUM(amount)   
     FROM asset_custom_flow   
     WHERE custom_flow_hdr_id = (SELECT custom_flow_hdr_id   
         FROM custom_flow_hdr   
         WHERE name like 'Guaranty Deposit')  
     AND contract_id = acv.contract_id) OrigGDLessPVGD,  
       
-- PastDueDate  #32#
    acv.suspension_dt PastDueDate,  
      
-- IndustryCode  #33#
     (SELECT replace(field_value,'''','')  
     FROM party_cfv  
     WHERE party_cfd_id = (SELECT party_cfd_id  
         FROM party_cfd   
         WHERE name = 'Industry Class')  
  AND party_id = acv.cparty_id)IndustryCode ,  
       

-- DSORITag  #34#
    (SELECT field_value   
  FROM party_cfv   
  WHERE party_cfd_id = (SELECT party_cfd_id   
         FROM party_cfd   
         WHERE name like 'RPT Classification' )  
  AND party_id = acv.cparty_id) DSORITag,  

-- REECode  #35#
    (SELECT top 1 field_value   
    FROM contract_cfv cv  
       WHERE cv.contract_cfd_id = (SELECT TOP 1 contract_cfd_id  
       FROM contract_cfd  
       WHERE name = 'Qtrly REL/REE Code')  
    AND cv.contract_id = acv.contract_id) RELREECode,  
      
-- RELCode  #36#
    (SELECT top 1 field_value   
    FROM contract_cfv cv  
       WHERE cv.contract_cfd_id = (SELECT TOP 1 contract_cfd_id  
       FROM contract_cfd  
       WHERE name = 'REL Code - STACON')  
    AND cv.contract_id = acv.contract_id) RELCode,  
        
-- REEAddInfo   #37#
    (SELECT top 1 field_value   
    FROM contract_cfv cv  
       WHERE cv.contract_cfd_id = (SELECT TOP 1 contract_cfd_id  
       FROM contract_cfd  
       WHERE name = 'Qtrly REL/REE Addtl Info Code')  
    AND cv.contract_id = acv.contract_id) RELREEAddInfo,  
      
-- IndustryHeader  #38#
     (SELECT quarterly_qlp  
      FROM BDOLF_Industry_code   
      where code =(SELECT replace(field_value,'''','')  
       FROM party_cfv  
       WHERE party_cfd_id = (SELECT party_cfd_id  
           FROM party_cfd   
           WHERE name = 'Industry Class')  
       AND party_id = acv.cparty_id)) IndustryHeader,  

-- IndustryDetails  #39#
  (SELECT top 1 description  
      FROM BDOLF_PSIC  
      where code =(SELECT replace(field_value,'''','')  
       FROM party_cfv  
       WHERE party_cfd_id = (SELECT party_cfd_id  
           FROM party_cfd   
           WHERE name = 'Industry Class')  
  AND party_id = acv.cparty_id)) IndustryDetails,  

-- Collateral   #40#
     (select name from BDOLFFN_MultipleName(acv.contract_id,0)) Collateral,  
    
-- BorrowerType  #41#
  (SELECT field_value  
       FROM party_cfv  
       WHERE party_cfd_id = (SELECT party_cfd_id  
           FROM party_cfd   
           WHERE name = 'Borrower Type')  
  AND party_id = acv.cparty_id )BorrowerType,  
    
-- Nationality  #42#
    (SELECT field_value   
    FROM party_cfv   
    WHERE party_id = acv.cparty_id   
    AND party_cfd_id = (SELECT party_cfd_id   
         FROM party_cfd   
         WHERE name = 'Nationality')) Nationality,   

-- AssetSize  #43#
    (SELECT field_value   
  FROM party_cfv   
  WHERE party_cfd_id = (SELECT party_cfd_id   
         FROM party_cfd   
         WHERE name like 'Asset Size')   
  AND party_id = acv.cparty_id) AssetSize,  
    
-- PaymentFrequency  #44#
  acv.installment_freq_value PaymentFrequency,   

-- BU  #45#
     acv.business_unit BU,  

-- ArrearsAdvance  #46#
  (SELECT Value from lookupset   
   WHERE lookupset_id = (SELECT installment_timing   
          FROM contract   
          WHERE contract_id = acv.contract_id)) ArrearsAdvance,  
            
-- OrigPrincipal  #47#
 acv.amt_financed OrigPrincipal,
    
-- Principal  #48#
     0 Principal,  
  
-- UDIBal #49#
  (Select CASE WHEN acv.Contract_State <> 11160 
		  THEN UDI_Balance_ToDate 
		  ELSE 0 
		  END
		  from dbo.BDOLFFN_GetOBlastmonth(acv.contract_id,@cutoffdate)) UDIBal,    

-- AIR  #50#
   (select sum(amount)* -1 
	from gl_entry 
	where narration like '%Accrual%' 
	and flow_type in(1003,1043)
	and gl_tag_id = 8
	and contract_id = acv.contract_id
	and post_dt between @FirstDayOfMonth and @LastDayOfMonth) AIR, 
      
-- GDRVComparison  #51#
   null GDRVComparison,  
     
-- PVRate  #52#
   acv.interest_rate PVRate,  
     
-- PrincipalPrevMonth   #53#
  0 PrincipalPrevMonth,     
    
-- ITLDate  #54#
   (SELECT TOP 1 field_value   
    FROM credit_info_cfv civ  
    inner join credit_info ci ON ci.credit_info_id = civ.credit_info_id  
          WHERE civ.credit_info_cfd_id = (SELECT TOP 1 credit_info_cfd_id   
           FROM credit_info_cfd   
           WHERE name = 'Date of ITL Tagging')  
    AND ci.party_id = (SELECT top 1 cparty_id 
					   FROM contract 
					   WHERE contract_id = acv.contract_id)) ITLDate,       
     
-- EndorsedRMUDate  #55#
   (SELECT TOP 1 field_value   
    FROM credit_info_cfv civ  
    inner join credit_info ci ON ci.credit_info_id = civ.credit_info_id  
          WHERE civ.credit_info_cfd_id = (SELECT TOP 1 credit_info_cfd_id   
           FROM credit_info_cfd   
           WHERE name = 'Date of Endorsed to RMU')  
    AND ci.contract_id = acv.contract_id) EndorsedRMUDate,     
     
-- RMUDate  #56#
   (SELECT TOP 1 field_value   
    FROM credit_info_cfv civ  
    inner join credit_info ci ON ci.credit_info_id = civ.credit_info_id  
          WHERE civ.credit_info_cfd_id = (SELECT TOP 1 credit_info_cfd_id   
           FROM credit_info_cfd   
           WHERE name = 'Date of RMU Tagging')  
    AND ci.contract_id = acv.contract_id) RMUDate,       

-- Penalty  #57#
  (SELECT CASE WHEN acv.contract_state <> 11160 
		  THEN sum(amount)  
		  ELSE 0
		  END
   FROM gl_entry  
   WHERE contract_id = acv.contract_id   
   AND gl_account_id in (SELECT gl_account_id  
         FROM gl_account  
         WHERE name = 'INTEREST AND PAST DUE CHARGES')   
         AND post_dt between @FirstDayOfMonth AND @LastDayOfMonth) Penalty,  
      
-- LastPrincipalPay  #58#
    (Select top 1 amt_matched_principal 
   FROM flow 
   where contract_id = acv.contract_id 
   AND is_cash = 1 
   and flow_type in(1003,1043)
   and amt_matched_principal > 0
   ORDER BY calc_dt desc) LastPrincipalPay,  

-- LastPrincipalPayDate #59#
    (Select top 1 calc_dt 
   FROM flow 
   where contract_id = acv.contract_id 
   AND is_cash = 1 
   and flow_type in(1003,1043) 
   and amt_matched_principal > 0
   ORDER BY calc_dt desc) LastPrincipalPayDate,
   

-- LastInterestPay  #60#
  (Select top 1 amt_matched_interest 
   FROM flow 
   where contract_id = acv.contract_id 
   AND is_cash = 1 
   and flow_type in(1003,1043)
   and amt_matched_interest > 0
   ORDER BY calc_dt desc) LastInterestPay,
  

-- LastInterestPayDate #61#
  (Select top 1 calc_dt 
   FROM flow 
   where contract_id = acv.contract_id 
   AND is_cash = 1 
   and flow_type in(1003,1043)
   and amt_matched_interest > 0
   ORDER BY calc_dt desc) LastInterestPayDate,
  
-- PaidInterestMonth    #62#
   (SELECT CASE WHEN acv.contract_state <> 11160 
		   THEN SUM(amt_matched_interest)   
		   ELSE 0
		   END
    FROM flow   
    WHERE contract_id = acv.contract_id   
    AND is_cash = 1   
    AND flow_type in(1003,1043)  
    AND status = (SELECT lookupset_id   
         FROM lookupset   
         WHERE value = 'Processed' and set_name = 'FlowStatus' )    
         AND expected_dt between @FirstDayOfMonth and @LastDayOfMonth) PaidInterestMonth,  

-- IncomeLastMonth   #63#
    (select CASE WHEN sum(amount) < 0 
		  THEN SUM(amount) * -1 
		  ELSE sum(amount)
		  END
   from gl_entry 
   where narration like '%Accrual%' 
   and flow_type in(1003,1043)
   and gl_tag_id = 2 -- Unearned Income
   and contract_id = acv.contract_id
  and post_dt between DATEADD(MONTH,-1,@FirstDayOfMonth) and @LastDayOfLastMonth) IncomeLastMonth,

-- IncomeThisMonth  #64#
   (select CASE WHEN sum(amount) < 0 
		  THEN SUM(amount) * -1 
		  ELSE sum(amount)
		  END
   from gl_entry 
   where narration like '%Accrual%' 
   and flow_type in(1003,1043)
   and gl_tag_id = 2 -- Unearned Income
   and contract_id = acv.contract_id
  and post_dt between @FirstDayOfMonth and @cutoffdate) IncomeThisMonth,  

-- GLCode  #65#
   null GLCode,    

-- GLDesc  #66#
   null GLDesc,    
     
-- OriginatingBranch  #67#
  CASE WHEN ISNULL((select p.name from party p inner join (  
   select c.contract_id,c.cparty_id,ci.branch_id from contract c  
   Left join contracti ci  
   on c.contract_id = ci.contract_id  
        where ci.image_no = 1  
         and c.contract_id = acv.contract_id) pbu  
   on pbu.branch_id = p.party_id),'') = ''
   THEN  acv.branch_name
   ELSE (select p.name from party p inner join (  
   select c.contract_id,c.cparty_id,ci.branch_id from contract c  
   Left join contracti ci  
   on c.contract_id = ci.contract_id  
        where ci.image_no = 1  
         and c.contract_id = acv.contract_id) pbu  
   on pbu.branch_id = p.party_id)
   END OriginatingBranch,  

-- CostCenter  #68#
    (SELECT code   
    FROM party   
    WHERE party_id = (select branch_id   
          from axvw_contract_view   
          where contract_id = acv.contract_id)) CostCenter,  

-- BranchPerCostCenter  #69#
   acv.branch_name BranchPerCostCenter,  
     
-- Nationality  #70#
   (SELECT field_value   
    FROM party_cfv   
    WHERE party_id = acv.cparty_id   
    AND party_cfd_id = (SELECT party_cfd_id   
         FROM party_cfd   
         WHERE name = 'Nationality')) Nationality,       

-- TaxID  #71#
   (SELECT tax_no   
   FROM party   
   WHERE party_id = acv.cparty_id) TaxID,  
     
-- Currency  #72#
   acv.ccy Currency,  
     
-- BorrowerType Entity  #73#
   null BorrowerTypeEntity,  
     
-- Dealer  #74#
  (select DISTINCT name from BDOLFFN_MultipleName(acv.contract_id,1)) Dealer,  
      
-- SupRef  #75#
  (select DISTINCT SupRef from BDOLFFN_MultipleName(acv.contract_id,1)) Dealer,   
     
-- SupplierTIN  #76#
  (select DISTINCT TIN from BDOLFFN_MultipleName(acv.contract_id,1)) SupplierTIN, 
      
-- ClientCode  #77#
   (SELECT CASE WHEN reference = ''
		   THEN cast(party_no as nvarchar(40))
		   ELSE reference
		   END   
    FROM party   
    WHERE party_id = acv.cparty_id)ClientCode,  
      
-- TypeOfLease  #78#
   (SELECT TOP 1 asset_type   
    FROM axvw_asset_hdr_view_base   
    WHERE current_contract_id = acv.contract_id) TypeOfLease,  
      
-- ProductType  #79#
   acv.product ProductType, 
    
-- LastIntRate   #80#
   CASE WHEN acv.Contract_State <> 11160 
   THEN acv.interest_rate
   ELSE 0
   END LastIntRate,  
 
-- Penalty Rate   #81#
   cd.overdue_rate PenaltyRate, 

-- asset Cost  #82#
   (SELECT sum(cost)  
    FROM asset   
    WHERE contract_id = acv.contract_id)AssetCost,  
    
-- Tax Exemption  #83#
   case when acv.is_tax_exempt = 17802   
   then 'True'  
   else 'False'  
   end TaxExemption,  
   
-- Trade As  #84#
  pt.trading_as,

-- Input VAT #85#
  (select ISNULL(sum(amount),0) * -1
   from asset_custom_flow 
   where custom_flow_hdr_id = 9
   and contract_id = acv.contract_id) InputVAT  
 
-- ICBS Collateral Code #86#   
,  (SELECT top 1 a.ICBS_Collateral_Code 
  FROM dbo.BDOLF_AAFAssetType_ICBSCollateral a
   INNER JOIN asset_hdr b ON b.asset_type_id = a.AAF_Asset_Type_ID 
   where current_contract_id  =acv.contract_id or original_contract_id  =acv.contract_id)   AS Asset_Type

--  Asset Value #87#            
,  isnull((select (Sum((case when Amount = '' then 0.0 else cast(Amount as decimal(20,2)) end) ))
    from (select CASE WHEN c.current_contract_id = 0
				      THEN c.original_contract_id
				      ELSE c.current_contract_id
				      END current_contract_id, a.name, b.field_value,b.asset_hdr_id, b.seq_no from asset_hdr_cfd a 
    inner join asset_hdr_cfv b on b.asset_hdr_cfd_id = a.asset_hdr_cfd_id
    inner join asset_hdr c on c.asset_hdr_id = b.asset_hdr_id 
    where a.owner_id = 1 and a.name in('Date','Amount')) as s
    pivot (MAX(field_value) 
           FOR [name] in([Date],Amount)
           ) as pvt where current_contract_id = acv.contract_id
                          ),0)   as Asset_Value 

--  Approved Amount #88#
,    isnull((select amt_limit 
           from credit_line 
           where credit_line_id in(Select top 1 credit_line_id 
                                   from credit_line_takedown 
                                   where contract_id = acv.contract_id
                                   and   party_id = acv.cparty_id)),0)as ApprovedAmount
 
-- CP Number #89#                 
,  isnull((select name
           from credit_line 
           where credit_line_id in(Select top 1 credit_line_id 
                                   from credit_line_takedown 
                                   where contract_id = acv.contract_id
                                   and   party_id = acv.cparty_id )),'') as CP_Number
-- Control Unit #90#             
 , (SELECT field_value      
     FROM party_cfv      
     WHERE party_id = acv.cparty_id     
     AND party_cfd_id = (SELECT party_cfd_id     
          FROM party_cfd     
          WHERE name = 'Control Unit')) Control_Unit          

FROM axvw_contract_view acv  
LEFT OUTER JOIN party_cfv pc ON pc.party_id = acv.cparty_id and pc.party_cfd_id = 27  
LEFT OUTER JOIN axvw_party_view apv ON apv.party_id = acv.cparty_id  
LEFT OUTER JOIN axvw_asset aa ON aa.contract_id = acv.contract_id  
LEFT OUTER JOIN BDOLFVW_OB b ON b.contract_id = acv.contract_id  
LEFT OUTER JOIN purchase_invoice p ON p.contract_id = acv.contract_id   
LEFT OUTER JOIN contract_det cd ON cd.contract_id = acv.contract_id  
LEFT OUTER JOIN party pt ON pt.party_id = acv.cparty_id   
where acv.Product not in(select Name from product where owner_id = 34) 
and acv.contract_state in(11130,11140,11145,11160,11180,11175,11158)
and acv.calc_dt <= @cutoffdate 
and acv.contract_id in (8622)
 
declare @acctno int, @origERV decimal(20,2), @repriceamort decimal(20,2),  
@amortafterlastreprice decimal(20,2), @nxtratereviewdt date, @lastmonthUDI decimal(20,2),  
@pastduedate date, @freqexpectedreprice varchar(max), @valuedate date, @GD varchar(max), @Stat varchar(max), @FacilityCode varchar(max),  
@origprincipal decimal(20,2), @origudi decimal(20,2),@repricedate datetime , @bu varchar(50), @UDIBal decimal(20,2), @OriginatingBranch varchar(100),
@TypeOfLease varchar(max) 
  

declare tmpAgingCursor CURSOR FOR   
select acctno,origERV, repriceamort,   
       amortafterlastreprice, nxtratereviewdt,   
       lastmonthUDI, pastduedate, freqexpectedreprice, valuedate,  
       origGD,stat,FacilityCode, origprincipal, orgiudibal,RepriceDate,bu,UDIBal,
       OriginatingBranch, TypeOfLease  from @tempAgingTable  
  

OPEN tmpAgingCursor  

  
FETCH NEXT FROM tmpAgingCursor  
into @acctno, @origERV , @repriceamort,  
@amortafterlastreprice, @nxtratereviewdt, @lastmonthUDI,  
@pastduedate, @freqexpectedreprice, @valuedate, @GD, @stat,@FacilityCode, @origprincipal,  
@origudi,@repricedate,@bu, @UDIBal, @OriginatingBranch, @TypeOfLease  
  
while @@FETCH_STATUS = 0  
BEGIN  

-- reprice amotization  #25# 
 declare @segment_no int  
 declare @sched_id int  
 declare @amtseg decimal(20,2)  
   

 SELECT @sched_id = max(asset_price_schedule_id)   
 FROM asset_price_schedule   
 WHERE contract_id =@acctno  
   
 SELECT @segment_no = MAX(segment_no)   
 FROM asset_price_segment   
 WHERE asset_price_schedule_id =@sched_id  
 AND calc_dt < @cutoffdate  
    
 SELECT @amtseg = amt_segment   
 FROM asset_price_segment   
 WHERE asset_price_schedule_id = @sched_id   
 AND segment_no = @segment_no  
   
 if @repricedate = '' or @repricedate = null  or @stat = 'Written Off' 
  begin  
  UPDATE @tempAgingTable   
   SET repriceamort = 0 ,  
   nxtratereviewdt = null  
   WHERE acctno = @acctno  
  end  
 else if @amtseg > 0 and @repricedate <> ''  
  BEGIN  
   UPDATE @tempAgingTable   
  SET repriceamort = @amtseg   
   WHERE acctno = @acctno  
  END  
 Else  
  BEGIN  
   UPDATE @tempAgingTable   
   SET repriceamort = 0   
   WHERE acctno = @acctno  
  END  

-- next review date  #27#
 declare @nxtdate as date  
  IF @freqexpectedreprice = 'Annual' and @repricedate <> ''  
   BEGIN  
    SET @nxtdate = DATEADD(month,12,@repricedate)  
   END  
  ELSE IF @freqexpectedreprice  = 'Semi Annual' and @repricedate <> ''  
   BEGIN  
    SET @nxtdate = DATEADD(month,6,@repricedate)  
   END  
  ELSE IF @freqexpectedreprice  = 'Quarterly' and @repricedate <> ''  
   BEGIN  
    SET @nxtdate = DATEADD(month,3,@repricedate)  
   END  
  ELSE IF @freqexpectedreprice  = 'Monthly' and @repricedate <> ''  
   BEGIN  
    SET @nxtdate = DATEADD(month,1,@repricedate)  
   END  
  ELSE IF @freqexpectedreprice  = 'None' and @repricedate <> ''  
   BEGIN     
    SET @nxtdate = null  
   END  
  set @repricedate = ''  

  if (@stat <> 'Written Off')
  BEGIN 
	UPDATE @tempAgingTable   
	SET nxtratereviewdt = @nxtdate   
	WHERE acctno = @acctno  
  END
  
   declare @amtsegment decimal(20,2) 
   set @amtsegment = 0

    if (@stat <> 'Written Off')
    BEGIN
		(SELECT TOP 1 @amtsegment = amt_segment   
		FROM asset_price_segment   
		WHERE asset_price_schedule_id = (SELECT MAX(asset_price_schedule_id)   
										 FROM asset_price_schedule   
										 WHERE contract_id = @acctno)   
		AND segment_no = (SELECT COUNT(*) -1   
						  FROM asset_price_segment   
						  WHERE asset_price_schedule_id = (SELECT max(asset_price_schedule_id)   
														   FROM asset_price_schedule   
														   WHERE contract_id = @acctno)))  
	END
   
   UPDATE @tempAgingTable   
   SET amortafterlastreprice = @amtsegment   
   WHERE acctno = @acctno  
   
 -- original ERV   #16#
 declare @RV decimal(20,2)  
 set @RV = 0  
 SELECT @RV = sum(residual_value)   
 FROM axvw_asset   
 WHERE contract_id = @acctno  
   
 UPDATE @tempAgingTable   
 SET origERV = @RV   
 WHERE acctno = @acctno  
   
 -- last months UDI  #30#
 declare @LMonthUDI decimal(20,2) 
 set @LMonthUDI = 0
  
 if (@stat <> 'Written Off')
 BEGIN
	SELECT @LMonthUDI = UDI_Lastmonth   
	FROM dbo.BDOLFFN_GetOBlastmonth(@acctno,@cutoffdate)  
 END

 UPDATE @tempAgingTable   
 SET lastmonthUDI = @LMonthUDI   
 WHERE acctno = @acctno  
   
 -- GDRV Comparison  #51#
 if @GD > @RV   
  BEGIN  
   UPDATE @tempAgingTable   
   SET GDRVComparison = 'GD>RV'   
   WHERE acctno = @acctno  
  END  
 else if @RV > @GD   
  BEGIN  
   UPDATE @tempAgingTable   
   SET GDRVComparison = 'RV>GD'   
   WHERE acctno = @acctno  
  END  
 else  
  BEGIN  
   UPDATE @tempAgingTable   
   SET GDRVComparison = 'RV=GD'   
   WHERE acctno = @acctno  
  END  

    

 -- OB  #12#
  declare @OBValue decimal(20,2)  
  SET @OBValue = 0 
  IF(@stat <> 'Written Off')
  BEGIN
	  SELECT @OBValue = OB_to_date   
      FROM BDOLFFN_GetContractBalance(@acctno,@cutoffdate)  
  END
    
  UPDATE @tempAgingTable   
  SET OB = @OBValue   
  WHERE acctno = @acctno 

 -- total OB last month(MonthlyOB) #13#
   declare @MOValue decimal(20,2)  
  SET @OBValue = 0 
  IF(@stat <> 'Written Off')
  BEGIN
	  SELECT @MOValue = monthly_ob   
      FROM BDOLFFN_GetContractBalance(@acctno,@cutoffdate)  
  END
  
  UPDATE @tempAgingTable   
  SET monthlyOB = @MOValue
  WHERE acctno = @acctno  
    
 -- Additional Earned Interest  #15#
  Declare @TotalEarnedInterest decimal(20,2)  
  
  set @TotalEarnedInterest = 0
  if(@stat <> 'Written Off')  
  BEGIN
	select @TotalEarnedInterest = SUM(amount)
	from gl_entry 
    where narration like '%Accrual%' 
    and flow_type in(1003,1043)
    and gl_tag_id = 2 -- Unearned Income
    and contract_id = @acctno
    and post_dt between @FirstDayOfMonth and @cutoffdate
	
	IF(@TotalEarnedInterest < 0)
	BEGIN
		SET @TotalEarnedInterest = @TotalEarnedInterest * -1
	END
  END
    

  UPDATE @tempAgingTable   
  SET addearnedint = @TotalEarnedInterest   
  WHERE acctno = @acctno  


/* =========================================================================
	Current Status	#07#
   ========================================================================= */ 
    -- get the value for the ITL of the contract  
     declare @forITL nvarchar(20)       

    select @forITL=isnull(cicfv.field_value,0) from contract c  
    inner join party p   
       on p.party_id = c.cparty_id  
       inner join credit_info ci  
       on ci.party_id = p.party_id  
       inner join credit_info_cfv cicfv  
       on cicfv.credit_info_id = ci.credit_info_id  
       where cicfv.credit_info_cfd_id = (select credit_info_cfd_id  
                 from credit_info_cfd  
                 where name = 'ITL')  
       and c.contract_id = @acctno  
         

        if (@forITL = '')
        BEGIN
			set @forITL = 0
        END
		
       -- get the status if ROPA  
       declare @forROPA bit  
       declare @forROPAEff datetime  
         
       select @forROPA=field_value from contract_cfv   
       where contract_cfd_id = 147   
       and contract_id = @acctno  
         
       select @forROPAEff=field_value from contract_cfv   
       where contract_cfd_id = 148   
       and contract_id = @acctno  
         
       -- get the status for overdue 
      declare @forPD int  
      declare @lastallocationdt datetime
      declare @expectedflowdt datetime
      declare @Suspension varchar(200)
 
       select @forPD = COUNT(*) from axvw_overdue_view   
       where contract_id = @acctno 
       and collection_state = (select lookupset_id   
                               from lookupset   
                               where set_name = 'CollectionState'  
                               and value = 'Overdue') 
       
       select @Suspension = suspension_state_value 
       from axvw_contract_view 
       where contract_id = @acctno
       
    -- get Written Off effectivity  
    declare @writtenoffdt datetime  
      
    select @writtenoffdt=calc_dt   
    from contract_write_off   
    where contract_id = @acctno  
        

       declare @curStat nvarchar(30)  
       set @curStat = 'Current'     
       -- current  
       if isnull(@forITL,0) = 0 and @forROPA = 0 and @Stat <> 'Written Off'  and  @Suspension <> 'Suspended' 
       begin 
			SET @curStat = 'Current'   
       end  
	   
	-- ITL  
       else if isnull(@forITL,0) = 1
		begin  
			SET @curStat = 'Litigation'   
		end  

    -- ROPA  
		else if (isnull(@forITL,0) = 0 and (@forROPA = 1 and @forROPAEff <= @cutoffdate) and @Stat <> 'Written Off') or  
				(isnull(@forITL,0) = 1 and (@forROPA = 1 and @forROPAEff <= @cutoffdate) and @Stat <> 'Written Off')  
		begin  
				SET @curStat = 'ROPA'     
		end  
		
    -- Written Off   
		else if (isnull(@forITL,0) = 0 and @forROPA = 0 and @Stat = 'Written Off' and @writtenoffdt <= @cutoffdate ) or  
				(isnull(@forITL,0) = 1 and @forROPA = 0 and @Stat = 'Written Off' and @writtenoffdt <= @cutoffdate )  
		begin  
			SET @curStat = 'Written Off'      
		end 

    

    -- Past Due  
		--else if ((isnull(@forITL,0) = 0 and @forROPA = 0 and @Stat <> 'Written Off') and @forPD > 0) and 
		else if @Suspension = 'Suspended'
		begin  
			IF (@bu = 'BDOLF')
			BEGIN
				SET @curStat = 'Past Due'   
			END
		ELSE
			BEGIN
				SET @curStat = 'Current'
			END
		end 

   
   --UPDATE @tempAgingTable   
   --SET CurrentStat = @curStat  
   --WHERE acctno = @acctno  

   UPDATE @tempAgingTable   
   SET CurrentStat = @curStat  + case when dbo.bdolffn_isnpl(@acctno,0) = 1 then '- NPL' else '' end
   WHERE acctno = @acctno  

  /* ========================================================================= */ 
  -- GL  #65#
  declare @GLC varchar(max)  
  declare @GLN varchar(max)  
  declare @ctr int
  
  SET @GLC = '-'
  SET @GLN = '-'  

  if @curStat = 'Current' and (@FacilityCode = 'IPP-Daily' or 
							   @FacilityCode = 'IPP-Monthly')  
   begin  
    set @GLN = 'INSTALLMENT PAPERS PURCHASED'  
   end  
  else if @curStat = 'Past Due' and (@FacilityCode = 'IPP-Daily' or 
									 @FacilityCode = 'IPP-Monthly')  
   begin  
    set @GLN = 'PAST DUE RECEIVABLES - IPP'  
   end 
  else if @curStat ='Current' and(@FacilityCode = 'BDO Officers Car Lease (DL)' or 
								  @FacilityCode = 'Finance Lease - Direct Lease' or 
								  @FacilityCode like '%DL%' or 
								  @FacilityCode like '%Direct Lease%' or 
								  @FacilityCode like '%D.L.%')  
   begin  
    set @GLN = 'LCR-FM-DIRECT'     
   end   
  else if @curStat = 'Past Due' and(@FacilityCode = 'BDO Officers Car Lease (DL)' or 
						            @FacilityCode = 'Finance Lease - Direct Lease'or 
					             @FacilityCode like '%DL%' or 
						            @FacilityCode like '%Direct Lease%' or 
						            @FacilityCode like '%D.L.%')  
   begin  
    set @GLN = 'PAST DUE -DIRECT LEASE'      
   end   
  else if @curStat = 'Current' and(@FacilityCode = 'BDO Officers Car Lease (SLB)' or 
								   @FacilityCode = 'Finance Lease - Sale&LeaseBack' or 
								   @FacilityCode like '%SLB%' or 
								   @FacilityCode like '%Sale&LeaseBack%' or 
								   @FacilityCode like '%SL%' or 
								   @FacilityCode like '%S.L.B.%' or 
							   @FacilityCode like '%S.L.%')  
   begin  
    set @GLN = 'LCR-FM SALE/LEASEBACK'       
   end  
  else if @curStat = 'Past Due' and(@FacilityCode = 'BDO Officers Car Lease (SLB)' or 
									@FacilityCode = 'Finance Lease - Sale&LeaseBack'or 
									@FacilityCode like '%SLB%' or 
									@FacilityCode like '%Sale&LeaseBack%' or 
									@FacilityCode like '%SL%' or 
									@FacilityCode like '%S.L.B.%' or 
									@FacilityCode like '%S.L.%')  
   begin  
    set @GLN = 'PAST DUE -SALE/LEASEBACK'       
   end   
  else if @curStat = 'Litigation' and (@FacilityCode = 'BDO Officers Car Lease (DL)' or 
								@FacilityCode = 'Finance Lease - Direct Lease' or  
								@FacilityCode = 'BDO Officers Car Lease (SLB)' or 
								@FacilityCode = 'Finance Lease - Sale&LeaseBack' or 
								@FacilityCode like '%SLB%' or 
								@FacilityCode like '%Sale&LeaseBack%' or 
								@FacilityCode like '%SL%' or 
								@FacilityCode like '%DL%' or 
								@FacilityCode like '%S.L.%' or 
								@FacilityCode like '%S.L.B.%' or 
								@FacilityCode like '%D.L.%')  
   begin  
    set @GLN = 'ITEMS IN LITIGATION-LCR'      
   end             
  else if @curStat = 'Past Due' and (@FacilityCode = 'Finance Lease - Restructured')  
   begin  
    set @GLN = 'PD - RESTRUCTURED - LCR'       
   end   
  else if @curStat = 'Litigation' and (@FacilityCode = 'Finance Lease - Restructured')  
   begin  
    set @GLN = 'ITL - RESTRUCTURED LCR'     
   end   
     
  select @GLC = code from gl_account where name = @GLN  
    

   UPDATE @tempAgingTable   
   SET GLCode = @GLC,  
    GLDesc = @GLN  
   WHERE acctno = @acctno   
     
  -- Principal  #48#
  declare @PPaidAmount decimal(20,2)  
  
	  SELECT @PPaidAmount = total_principal   
      FROM BDOLFFN_GetContractBalance(@acctno,@cutoffdate)  
    

   UPDATE @tempAgingTable   
   SET Principal = @PPaidAmount
   WHERE acctno = @acctno   
    
  -- principal previous month  #53#
  declare @totalP decimal(20,2)  
  declare @totalPaidP decimal (20,2)  
    
  SET @totalP = 0
  SET @TotalPaidP = 0
  
  if (@stat <> '')
  BEGIN
  	  SELECT @totalPaidP = total_principal_previous   
      FROM BDOLFFN_GetContractBalance(@acctno,@cutoffdate)  
   END

   UPDATE @tempAgingTable   
   SET PrincipalPrevMonth = @totalPaidP  
   WHERE acctno = @acctno   
    
 -- Originating Branch #67#
 declare @OrigBranch varchar(100)
 IF(@OriginatingBranch = '')
 BEGIN
	select @OrigBranch = p.name from party p 
	inner join  contract c   
	on c.cparty_id = p.party_id  
	WHERE c.contract_id = @acctno
 END

    UPDATE @tempAgingTable   
   SET OriginatingBranch = @OriginatingBranch
   WHERE acctno = @acctno   

 
 FETCH NEXT FROM tmpAgingCursor  
 INTO @acctno, @origERV , @repriceamort,  
@amortafterlastreprice, @nxtratereviewdt, @lastmonthUDI,  
@pastduedate, @freqexpectedreprice, @valuedate,@GD, @stat,@FacilityCode,  
@origprincipal, @origudi,@repricedate, @bu, @UDIBal, @OriginatingBranch,
@TypeOfLease
END   

  
CLOSE tmpAgingCursor  
DEALLOCATE tmpAgingCursor  

  

update @tempAgingTable set repricedate = null,repriceamort = 0,amortafterlastreprice = 0, nxtratereviewdt = null  
where repricedate = ''  

SELECT *
FROM @tempAgingTable


END
--exec BDOLFSP_PortfolioInterface  



GO


