/*
-- =============================================
AUTHOR:				Cherrie Garcia
VERSION:			1.0.0.1
CREATE DATE:		March 19,2018
UPDATE DATE:		March 19,2018
P2P DATE:
UPDATE DETAILS:		-- 1.0.0.1 - (CVG)	- Report Details, User Role Access
-- =============================================
*/
ALTER PROCEDURE BDOLFSP_AAFAccessMatrixReport

AS
BEGIN
select *
--a.NAME,
--a.[GROUP],
--a.[FILE NAME]
 from
(
SELECT DISTINCT
	RF.NAME [NAME],
	RF.report_fmt_id,
	RF.description [DESCRIPTION],
	RG.name [TASK GROUP],
	RF.report_file_path [FILE NAME],
	AX.ext_name [CREATED BY USER],
	AH.audit_dt [DATE CREATED],
	(CASE WHEN AX_ACCESS.owner_id !=0
		 THEN (SELECT name FROM  ax_user WHERE ax_user_id= AX_ACCESS.owner_id)
		 ELSE CASE WHEN  AX_ACCESS.owner_id =0
		  THEN (SELECT name FROM  ax_user WHERE ax_user_id= AX_ACCESS.ax_user_id)
		 ELSE 'ALL USERS'
		 END END)  [GROUP],
    (CASE WHEN  convert(date, AH.audit_dt)in (SELECT distinct TOP 1  CONVERT(date,audit_dt) as latest 
												FROM audit_hdr WHERE  tbl_name= 'report_fmt' AND  CHANGE_TYPE=1
												 and audit_dt <= getdate()ORDER BY latest DESC) 
		 THEN '*' ELSE ''
		 END )  [NEW REPORT]
FROM report_fmt RF
	LEFT JOIN audit_hdr ah on RF.report_fmt_id = ah.tbl_id
	LEFT JOIN report_task_grp RG ON  rf.report_task_grp_id = rg.report_task_grp_id
	LEFT JOIN ax_user AX ON ah.user_id = ax.ax_user_id -- FOR USER NAME OF CREATOR
	LEFT JOIN report_fmt_user r_user ON r_user.report_fmt_id = RF.report_fmt_id 
	LEFT JOIN ax_user AX_ACCESS ON r_user.user_id = AX_ACCESS.ax_user_id -- FOR USER NAME (ACCESS PERMISSION)

WHERE  
	rf.is_active !=0 
	AND AH.change_type = 1
	AND AH.tbl_name= 'report_fmt'
	
--ORDER BY RF.name
)a
--where a.[GROUP]  in ('BDOLF Admin','ALL USERS')
order by a.NAME
END
GO


--exec BDOLFSP_AAFAccessMatrixReport