
/****** Object:  UserDefinedFunction [dbo].[BDOLFFN_NPL_PDL_Tagging]    Script Date: 02/21/2018 12:01:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
-- =============================================  
Author:				CVG  
Version:			1.0.0.2
Create date:		02/13/2018 
Update date:		02/21/2018 
P2P Date:			03/12/2018
Update Details:		- 1.0.0.1(CVG): created new Function to identify if Contracts are NPL,PDL, Both NPL and PDL and Current(if none PDL/NPL)
									used in [BDOLFSP_AmortizationSchedule]	
					- 1.0.0.2(CVG): Changed the function return; same as current status of Aging Inventory				
-- =============================================  
*/


ALTER FUNCTION [dbo].[BDOLFFN_NPL_PDL_Tagging](@acctno varchar(50), @cutoffdate datetime)  
RETURNS nvarchar (max)  
BEGIN

DECLARE @ret NVARCHAR (max) 

DECLARE @forITL NVARCHAR(20)  
	     SET @forITL = '0'
	     
DECLARE @Stat NVARCHAR(max)
DECLARE @bu VARCHAR(10)
SET @bu = 'BDOLF'
	SELECT @forITL=isnull(cicfv.field_value,0) FROM contract c  
	    INNER JOIN party p   
	       ON p.party_id = c.cparty_id  
	       INNER JOIN credit_info ci  
	       ON ci.party_id = p.party_id  
	       INNER JOIN credit_info_cfv cicfv  
	       ON cicfv.credit_info_id = ci.credit_info_id  
	       WHERE cicfv.credit_info_cfd_id = (SELECT credit_info_cfd_id  
	                 FROM credit_info_cfd  
	                 WHERE name = 'ITL')  
	       and c.contract_id = @acctno  

        IF (@forITL = '')
	        BEGIN
				SET @forITL = '0'
	        END

	-- get the status if ROPA  
	       DECLARE @forROPA bit  
	       DECLARE @forROPAEff datetime  
        
			SELECT @forROPA=field_value FROM contract_cfv   
			WHERE contract_cfd_id = 147   
			and contract_id = @acctno  

			SELECT @forROPAEff=field_value FROM contract_cfv   
			WHERE contract_cfd_id = 148   
			and contract_id = @acctno  

	-- get the status for overdue 
	      DECLARE @forPD int  
	      DECLARE @lastallocationdt datetime
	      DECLARE @expectedflowdt datetime
	      DECLARE @Suspension varchar(200)
	      
	       SELECT @forPD = COUNT(*) FROM axvw_overdue_view   
	       WHERE contract_id = @acctno 
	       and collection_state = (select lookupset_id   
	                               FROM lookupset   
	                               where set_name = 'CollectionState'  
	                               and value = 'Overdue') 

	       SELECT @Suspension = suspension_state_value 
	       FROM axvw_contract_view 
	       WHERE contract_id = @acctno
		   
	-- get Written Off effectivity  
	    DECLARE @writtenoffdt datetime  
		
		SELECT @writtenoffdt=calc_dt   
	    FROM contract_write_off   
	    where contract_id = @acctno  

		DECLARE @curStat nvarchar(max)  
		SET @curStat = 'Current'     

		-- current  
	       IF isnull(@forITL,'0') = '0' and @forROPA = 0 and @Stat <> 'Written Off'  and  @Suspension <> 'Suspended' 
	       BEGIN 
			SET @curStat = 'Current'   
	       END  
    
	    -- ITL  
	       ELSE IF isnull(@forITL,'0') = '1'
			BEGIN  
				SET @curStat = 'Litigation'   

			END  

		-- ROPA  
			ELSE IF (isnull(@forITL,'0') = '0' and (@forROPA = 1 and @forROPAEff <= @cutoffdate) and @Stat <> 'Written Off') or  
			(isnull(@forITL,'0') = '1' and (@forROPA = 1 and @forROPAEff <= @cutoffdate) and @Stat <> 'Written Off')  
			BEGIN  
				SET @curStat = 'ROPA'     
			END  

	    -- Written Off   
			ELSE IF (isnull(@forITL,'0') = '0'and @forROPA = 0 and @Stat = 'Written Off' and @writtenoffdt <= @cutoffdate ) or  
			(isnull(@forITL,'0') = '1' and @forROPA = 0 and @Stat = 'Written Off' and @writtenoffdt <= @cutoffdate )  
			BEGIN  
				SET @curStat = 'Written Off'      
			END  
		
		-- Past Due  
			--else IF ((isnull(@forITL,0) = 0 and @forROPA = 0 and @Stat <> 'Written Off') and @forPD > 0) and 
			ELSE IF @Suspension = 'Suspended'
			BEGIN  
				IF (@bu = 'BDOLF')
					BEGIN
						SET @curStat = 'Past Due'   
					END
				ELSE
					BEGIN
						SET @curStat = 'Current'
					END
				END 

		
			SET @ret = @curStat  + CASE WHEN dbo.bdolffn_isnpl(@acctno,0) = 1 then ' - NPL' ELSE ' ' END

 RETURN @ret  
END

--select dbo.[BDOLFFN_NPL_PDL_Tagging](5776,'12-31-2018')

GO


