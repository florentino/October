
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*
-- =============================================
 Author:			CVG
 Version:			1.0.0.1
 Create date:		01/01/2017
 Update Date:		01/11/2018
 P2P Date:			03/12/2018
 Update Details:	- 1.0.0.1(CVG): Include all Matured OL w/ pending
-- =============================================
*/
ALTER PROCEDURE [dbo].[BDOLFSP_EndofTerm] --'2015-10-28'
	@Date DATETIME
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @ToDate DATETIME

	SET @ToDate = DATEADD(DD,1, @Date)

	SELECT	con.contract_id [Contract No]
			,par.party_no [Party No]
			,par.ext_name [Party Name] 
			,parb.ext_name [Operating Unit]
			,DATEDIFF (DAY,acv.maturity_dt,@date) [Aging]
	FROM contract con
	INNER JOIN party par ON con.cparty_id=par.party_id
	INNER JOIN party parb ON con.branch_id=parb.party_id
	LEFT JOIN axvw_contract_view acv ON con.contract_id = acv.contract_id		
	where con.contract_state = 	'11180' -- Matured
		And acv.maturity_dt <= @date
	UNION	
	SELECT	con.contract_id [Contract No]
			,par.party_no [Party No]
			,par.ext_name [Party Name] 
			,parb.ext_name [Operating Unit]
			,DATEDIFF (DAY,acv.maturity_dt,@date) [Aging]
	FROM contract con
	INNER JOIN party par ON con.cparty_id=par.party_id
	INNER JOIN party parb ON con.branch_id=parb.party_id
	LEFT JOIN axvw_contract_view acv ON con.contract_id = acv.contract_id	
	WHERE EXISTS (
					SELECT evlog.contract_id
					FROM
					(
						SELECT	CONVERT(INT, SUBSTRING(REPLACE(REPLACE(REPLACE(REPLACE(SUBSTRING(ev.description, 1, 50), 'End of Term processing:', ''), 'Contract ', ''), CHAR(10), ''), CHAR(13),''), 1,
								CHARINDEX(':', REPLACE(REPLACE(REPLACE(REPLACE(SUBSTRING(ev.description, 1, 50), 'End of Term processing:', ''), 'Contract ', ''), CHAR(10), ''), CHAR(13), ''), 1)-1)) as contract_id
						FROM event_log ev
						WHERE input_dt >= @Date 
						AND input_dt < @ToDate 
						AND event_type = 'Error' 
						AND description LIKE '%end of term%'
					) AS evlog
					WHERE con.contract_id = contract_id
				)And acv.maturity_dt <= @date
	ORDER BY con.contract_id

END




GO


-- exec [BDOLFSP_EndofTerm] '2015-10-28'