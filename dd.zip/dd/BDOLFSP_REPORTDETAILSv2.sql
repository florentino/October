
/*
-- =============================================
AUTHOR:				Cherrie Garcia
VERSION:			1.0.0.2
CREATE DATE:		March 16,2018
UPDATE DATE:		June 08,2018
P2P DATE:
UPDATE DETAILS:		-- 1.0.0.1 - (CVG)	- Report Configuration Details
					-- 1.0.0.2 - (CVG)	- Change 'Created Date' to 'Date', Added new column 'TASK'
-- =============================================
*/
ALTER PROCEDURE BDOLFSP_ReportConfigurationDetails
@StartDate datetime,
@EndDate datetime,
@reportName varchar(Max)


AS
BEGIN

set @reportName = (case when @reportName = 'All' then ''
					else @reportName end )	
	
	
	
SELECT DISTINCT
	RF.NAME [NAME],
	RF.report_fmt_id,
	RF.description [DESCRIPTION],
	RG.name [TASK GROUP],
	RTYPE.value [REPORT TYPE],
	DFORM.value [DEFAULT FORMAT],
	RF.report_file_path [FILE NAME],
	--(CASE WHEN RF.apply_watermark = '1'
	--	THEN 'Apply Watermark' ELSE CASE WHEN RF.apply_watermark = '0'
	--	THEN 'Not Allowed' END END ) [OUTPUT AS COPY SETTINGS], 
	ptype.value [PARAMETER SET TYPE],
		
	REPLACE (stuff((select ','+ ( AX_ACCESS.ext_name) as [text()]
		 from ax_user AX_ACCESS,report_fmt_user r_user
		 where r_user.report_fmt_id = RF.report_fmt_id 
		 AND r_user.user_id = AX_ACCESS.ax_user_id
		 FOR XML PATH('')),1,1,'') , '&amp;', '&') AS [ACCESS PERMISSION], -- Users' Concat
		 
	(SELECT path_value FROM system_defs_path 
		where system_defs_path_id = 7718)  [STORE REP..], -- REPORT GEN
		
	RF.sub_folder [SUB-FOLDER] ,
	rf.comments  [COMMENTS],	
	AX.ext_name [CREATED BY USER],
	AH.audit_dt [DATE],
	(CASE WHEN AH.change_type = '1'
		THEN 'Created' ELSE CASE WHEN AH.change_type = '2'
		THEN 'Updated' END END ) [TASK]

FROM report_fmt RF
	LEFT JOIN audit_hdr ah on RF.report_fmt_id = ah.tbl_id
	LEFT JOIN report_task_grp RG ON  rf.report_task_grp_id = rg.report_task_grp_id
	LEFT JOIN lookupset rtype ON  rf.template_type = rtype.lookupset_id -- FOR REPORT TYPE
	LEFT JOIN lookupset dform ON rf.default_format = dform.lookupset_id -- FOR DEFAULT FORMAT
	LEFT JOIN lookupset ptype ON RF.report_prm_type = ptype.lookupset_id -- PARAM SET TYPE
	LEFT JOIN ax_user AX ON ah.user_id = ax.ax_user_id -- FOR USER NAME OF CREATOR
	--LEFT JOIN report_fmt_user r_user ON r_user.report_fmt_id = RF.report_fmt_id 
	--LEFT JOIN ax_user AX_ACCESS ON r_user.user_id = AX_ACCESS.ax_user_id -- FOR USER NAME (ACCESS PERMISSION)
WHERE  
	rf.is_active !=0 
	AND AH.change_type in(1,2)
	AND AH.tbl_name= 'report_fmt'
	AND AH.audit_dt >= @StartDate
	AND AH.audit_dt <= @EndDate
	AND RF.name like '%'+@reportName+'%'
ORDER BY rg.name, RF.name
END
GO


--exec BDOLFSP_ReportConfigurationDetails '01-01-2014','08-31-2018', 'All'