

/****** Object:  StoredProcedure [dbo].[BDOLFSP_AmortizationSchedule]    Script Date: 02/21/2018 12:04:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*
-- =============================================  
Author:				CVG  
Version:			1.0.0.4
Create date:		01/10/2018 
Update date:		02/21/2018 
P2P Date:			03/12/2018
Update Details:		- 1.0.0.1(CVG): created new SP from existing script 
					- 1.0.0.2(CVG): added balloon payment and interest only in flow type 
					- 1.0.0.3(CVG): added Effective Rate, Client Name and NPL-PDL Tagging, changed Amort Month to word
					- 1.0.0.4(CVG): updated the function, changed the output of Computed Principal base on Type
-- =============================================  
*/

ALTER PROCEDURE  [dbo].[BDOLFSP_AmortizationSchedule]   
 @StartDate DATETIME,  
 @EndDate DATETIME  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
  
 SELECT  
	  iflow.[Business Unit],  
	  iflow.[Branch],  
	  iflow.[Product],  
	  iflow.[Client Name], 
	  iflow.[Contract No],  
	  iflow.[PDL/NPL],
	  iflow.[Type],  
	  iflow.[Amort Year],  
	  iflow.[Amort Month],  
	  iflow.[Currency],  
	  iflow.[Effective Rate],
	  iflow.[Amount],  
	  CASE WHEN  iflow.[Type]= 'Interest Only' THEN 0 ELSE  iflow.[Amount]-earn.[Interest] end [Computed Principal],  
	  earn.[Interest] [Interest in Earnings],  
	  iflow.[Principal] [Internal Flows Principal],  --not included in the report
	  iflow.[Interest] [Internal Flows Interest],   --not included in the report
	  iflow.[Interest]-earn.[Interest] [Interest Difference] --not included in the report
 FROM  
	  (SELECT  
		   pabu.ext_name [Business Unit],  
		   pabr.ext_name [Branch],  
		   pr.ext_name [Product],   
		   acv.party_ext_name [Client Name],
		   fc.contract_id [Contract No], 
		   dbo.[BDOLFFN_NPL_PDL_Tagging](fc.contract_id,@EndDate) as [PDL/NPL],
		  -- 'Installment' [Type],
		   CASE WHEN fc.flow_type=1003 THEN 'Installment' 
			ELSE CASE WHEN fc.flow_type=1043 THEN 'Interest Only' 
			ELSE CASE WHEN fc.flow_type=1027 THEN 'Balloon Payment' END END END [Type], 
		   YEAR(fc.calc_dt) [Amort Year],  
		   MONTH(fc.calc_dt)[Amort Month2],
		   CONVERT(varchar(3),fc.calc_dt,100)[Amort Month],  
		   cu.code [Currency],  
		   acv.interest_rate [Effective Rate],
		   SUM(fc.amount) [Amount],  
		   SUM(fc.amt_principal)  [Principal],  
		   SUM(fc.amt_interest) [Interest]
		  
	  FROM   
		   flow_calc fc  
		   INNER JOIN contract co on fc.contract_id=co.contract_id  
		   INNER JOIN product pr on pr.product_id=co.product_id  
		   INNER JOIN party pabu on pabu.party_id=co.business_unit_id  
		   INNER JOIN party pabr on pabr.party_id=co.branch_id  
		   INNER JOIN currency cu on cu.currency_id=co.currency_id 
		   INNER JOIN axvw_contract_view acv on acv.contract_id = fc.contract_id 
		  
	  WHERE   
		   fc.flow_schedule_type=29101 --internal flows  
		   and fc.flow_type in (1003,1027,1043) --installment, balloon payment, interest only 
		   and sign(fc.contract_id)=1  
		   and co.contract_type=2301  -- contract
		   and fc.calc_dt>=@StartDate  
		   and fc.calc_dt<=@EndDate  
		   
		  -- and co.contract_id=1 
	  GROUP BY  
		  pabu.ext_name,pabr.ext_name,pr.ext_name 
		  , fc.contract_id
		  ,year(fc.calc_dt)  
		  ,MONTH(fc.calc_dt)
		  ,convert(varchar(3),fc.calc_dt,100)
		  ,cu.code
		  ,fc.flow_type
		  ,acv.party_ext_name 
		  ,acv.interest_rate
		  --,cfd.[description] 
		  )iflow   
INNER JOIN  
	   (SELECT  
			fc.contract_id [Contract No],  
			year(fc.calc_dt) [Amort Year],  
			MONTH(fc.calc_dt)[Amort Month2],   
			sum(fc.amt_interest) [Interest]  
		FROM   
			flow_calc fc  
		INNER JOIN contract co ON fc.contract_id=co.contract_id  
		WHERE   
		   fc.flow_schedule_type=29103 --Accounting - Tax (Earnings Tab)  
		   and fc.flow_type in (1003,1027,1043) --installment, balloon payment, interest only 
		   and sign(fc.contract_id)=1  
		   and co.contract_type=2301  -- contract
		   and fc.calc_dt>=@StartDate  
		   and fc.calc_dt<=@EndDate  
		   --and co.contract_id=1  
		GROUP BY MONTH(fc.calc_dt) ,year(fc.calc_dt),fc.contract_id) earn   
	ON iflow.[Contract No]=earn.[Contract No]   
	and iflow.[Amort Year]=earn.[Amort Year]   
	and iflow.[Amort Month2]=earn.[Amort Month2]  
	ORDER BY  iflow.[Branch]

  
END  
 
--EXEC [BDOLFSP_AmortizationSchedule] '2018-01-01', '2018-12-31'

GO


