
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
-- =============================================
 Author:			CVG
 Version:			1.0.0.1
 Create date:		01/12/2018
 Update Date:		01/12/2018
 P2P Date:			03/12/2018
 Update Details:	- 1.0.0.1(CVG): created new SP from existing script, add business unit column
									and ordered by Operating Unit				
-- =============================================

*/
CREATE PROCEDURE [dbo].[BDOLFSP_PendingRestructureLPCReview]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @Date datetime
SET @Date = '1900-01-01'

   SELECT DISTINCT
		con.contract_id [Contract No.]
		,par.ext_name [Party Name]
		,par.party_no [Party No]
		,pro.ext_name [Product]
		,par2.ext_name [Operating Unit]
		,acv.business_unit [Business Unit]
	
	FROM
		contract con
		INNER JOIN party par ON con.cparty_id=par.party_id
		INNER JOIN product pro ON con.product_id=pro.product_id
		INNER JOIN party par2 ON con.branch_id=par2.party_id
		INNER JOIN contract_restructure conr ON con.contract_id=conr.contract_id
		INNER JOIN workflow wf ON con.contract_id=wf.contract_id
		INNER JOIN todo_hdr tdo ON wf.wf_todo_hdr_id=tdo.todo_hdr_id
		INNER JOIN wf_state_type wf_st ON wf.current_state_type=wf_state_type_id
		LEFT JOIN axvw_contract_view acv ON con.contract_id = acv.contract_id
	WHERE
		con.contract_state=11130 --Complete Activated
		and con.contract_type=2301 -- contract
		and SIGN(con.contract_id)=1
		and conr.complete_activated_dt=@Date
		and tdo.name like '%Contract Data%'
		and wf_st.name like '%LPC Review%'
		and wf.is_complete=0
	ORDER BY 
	 par2.ext_name
END
GO


--exec [BDOLFSP_PendingRestructureLPCReview]