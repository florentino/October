﻿using System;
using System.Configuration;
using System.Text;
using System.Drawing;
using System.Data.SqlClient;
using System.Data;
using System.Data.OleDb;
using System.Security;
using Microsoft.Win32;
using System.IO;
using System.Security.Cryptography;
using System.DirectoryServices.AccountManagement;
using Microsoft.VisualBasic;
//using Microsoft.ApplicationBlocks.Data;
using OSSData.Manager;
using Microsoft.ApplicationBlocks.Data;

namespace PDCPartyLevelPaymentv1.Utilities

{
    public class SysUtilities
    {
        public string DataSource;
        public string Database;
        public string PerSecurity;
        public string IntegSecurity;
        public string UserName;
        public string UserPassword;
        public string sKey;
        public string Server;
        public string sConnString;
        public string sHostIP;
        public string sHostName;
        public string sBranchName;
        public string sBranchCode;

        public ConnectionType DBConnectionType;

        
        private static string DS;
        private static string DB;
        private static string UserN;
        private static string UserP;
        private static string ConnString;
        //private static ConnectionType _DBConnectionType;
        private static string _sHostIP;
        private static string _sHostName;
        private static string _sBranchName;
        private static string _sBranchCode;

        private static SqlConnection objCnn = new SqlConnection();
        private static SqlConnection mstrConn = new SqlConnection();

        private DataTable dtbranch = new DataTable();

        #region New Connection
        public enum ConnectionType
        {
            MSSQLUSER, ActiveDirectory
        }

        private void NewConnection()
        {
            DB = Database;
            DS = DataSource;
            UserN = UserName;
            UserP = UserPassword;
            //_DBConnectionType = DBConnectionType;

            //ConnString = "Data Source=" + DS + ";Persist Security Info=False;" + "User ID=" + UserN + ";Password=" + UserP + ";database=" + DB;
            ConnString = "Data Source=" + DS + ";Initial Catalog=" + DB + ";"
                + "Integrated Security=SSPI";
            sConnString = ConnString;
            if (objCnn.State == ConnectionState.Open)
            {
                objCnn.Close();
            }
            objCnn.ConnectionString = ConnString;
            objCnn.Open();
        }
        
        #endregion


        public string GetConnection()
        {
            DBConfig oDBConfig = new DBConfig();
            oDBConfig.ReadXML();

            DB = oDBConfig.Database;
            DS = oDBConfig.DataSource;
            UserN = oDBConfig.UserName;
            UserP = oDBConfig.Password;
            //_DBConnectionType = DBConnectionType;

            //ConnString = "Data Source=" + DS + ";Persist Security Info=False;" + "User ID=" + UserN + ";Password=" + UserP + ";database=" + DB;
            ConnString = "Data Source=" + DS + ";Initial Catalog=" + DB + ";"
                + "Integrated Security=SSPI";
            sConnString = ConnString;
            if (objCnn.State == ConnectionState.Open)
            {
                objCnn.Close();
            }
            objCnn.ConnectionString = ConnString;
            objCnn.Open();
            return ConnString;
        }
        // public void LoadConfig()
        //{
                       
        //    oDBConfig = new DBConfig();
        //    oDBConfig.ReadXML();

        //    objOSS = new Utilities.SysUtilities();
        //    objOSS.DataSource = oDBConfig.DataSource;
        //    objOSS.IntegSecurity = oDBConfig.IntegSecurity;
        //    objOSS.PerSecurity = oDBConfig.PerSecurity;
        //    objOSS.UserName = oDBConfig.UserName;    // txtUserLogin.Text;
        //    //objOSS.UserPassword = oDBConfig.Password;     //txtpassword.Text;
        //    objOSS.Database = oDBConfig.Database;
        //    objOSS.Server = oDBConfig.Server;
        //    objOSS.UserPassword = oDBConfig.Password;
        //}
     

        #region Get Connection Info


        public class objSQLConn
        {
            public string dbName()
            {
                return DB;
            }
            public string dbSource()
            {
                return DS;
            }
            public string UserName()
            {
                return UserN;
            }
            public string Password()
            {
                return UserP;
            }

           // public ConnectionType ConnectionType()
           // {
           //     return _DBConnectionType;
           // }

            public string ConnectionString()
            {
                return ConnString;
            }

            public string HostIP()
            {
                return _sHostIP;
            }
            public string HostName()
            {
                return _sHostName;
            }
            public string BranchName()
            {
                return _sBranchName;
            }
            
        }

        #endregion
        
        #region Test Connection

        public bool Test()
        {
            try
            {
                NewConnection();
                objCnn.Open();
                if (objCnn.State.ToString() == "Open")
                {
                    //					AuditLog("OSS Login");
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
            finally
            {
                objCnn.Close();
            }
        }

        public string CheckDB()
        {

            string sResult = "";
            try
            {
                NewConnection();
                objCnn.Open();
                if (objCnn.State.ToString() == "Open")
                {
                  //AuditLog("OSS Login");
                }
            }
            catch (SqlException Err)
            {
                sResult = Err.Message.ToString();
            }

            return sResult;
        }


        //public string CheckDB(string sUserName, string sPassword,string sHost, string sHostIP,string sbranchcode)
        public string CheckDB(string sUserName, string sPassword,string sHost, string sHostIP,string sbranchcode, string log_idle)
        {
            string sResult = "";
            string sbranch = sbranchcode;
            try
            {
                NewConnection();
               

                if (objCnn.State.ToString() == "Open")
                {
                    sResult = ValidateUsernamePassword( sUserName,sPassword,"900",sHost,sHostIP,sbranch, log_idle);
                }
                else
                {
                    sResult = ValidateUsernamePassword(sUserName, sPassword, "902", sHost, sHostIP, sbranch, log_idle);

                }

            }
            catch (SqlException Err)
            {
                if (Err.Number == 18456)
                    sResult = ValidateUsernamePassword(sUserName, sPassword, "902", sHost, sHostIP, sbranch, log_idle);
                else 
                    sResult = Err.Message.ToString();

            }
            finally
            {
                objCnn.Close();
            }

            return sResult;
        }

       // j = Asc(Mid(pass, i, 1))
       // Public Function Decrypt(Uname As String, Upassword As String) As String
       // Dim UserID As String, str As String, x_pass As String, user_id As String
       // Dim i As Integer
       // str = ""
       // UserID = UCase(Uname) & Upassword & "1"     // FACEVIDAMOAm$123451
       // user_id = LCase(Uname) & Upassword & "1"   //  facevidamoAm$123451
       // For i = 1 To Len(user_id) - 1
       // str = str & Mid(user_id, Len(user_id) - i, 1)
       //Next
       //    For i = 1 To Len(UserID) - 1
       //    x_pass = x_pass & Chr((Asc(Mid(UserID, i, 1)) + Asc(Mid(str, i, 1))))
       //Next
       //Decrypt = x_pass
       //End Function
        public string DecryptPass(string Uname, string Upassword)
        {
            string UserID = Uname.ToUpper() + Upassword + "1";   //FACEVIDAMOAm$123451
            string user_id = Uname.ToLower() + Upassword;  //+"1";  //facevidamoAm$123451   lenght = 19
            int iuser_id = (user_id.Length)-1 ;                 // 19 -1
            int iUserID = (UserID.Length) - 1;                   // 19 -1
            string str = "";
            string xpass = "";
            string sMypass = "";
            string sMystr = "";

            for (int i = 0; i < user_id.Length ; i++)
            {
                str = str + user_id.Substring(iuser_id - i, 1);
            }
            for (int i = 0; i < UserID.Length - 1; i++)
            {
                xpass = xpass + UserID.Substring(i, 1);
                sMystr = sMystr + str.Substring(i, 1);
                byte Mybyte1 = Encoding.Default.GetBytes(xpass)[i];
                byte Mybyte2 = Encoding.Default.GetBytes(sMystr)[i];
                //sMypass = sMypass + Convert.ToString(Convert.ToChar(Encoding.Default.GetBytes(xpass)[i] + Encoding.Default.GetBytes(sMystr)[i]));
                sMypass = sMypass + Microsoft.VisualBasic.Strings.Chr(Microsoft.VisualBasic.Strings.AscW(xpass.Substring(i, 1)) + Microsoft.VisualBasic.Strings.AscW(sMystr.Substring(i, 1)));
            }
             return sMypass;
        }
        
        public bool Validate_Password(string UpassWord)
        {

         int  j = 0;
         int ipass = UpassWord.Length;
         string  Upass_word = UpassWord;
         bool lower = false;
         bool Upper = false;
         bool bNumeric = false;
         bool bSpecial = false;
         bool bValidate = false;

        
            for (int i = 0; i < Upass_word.Length; i++)
         {

             j = Microsoft.VisualBasic.Strings.AscW(Upass_word.Substring(i, 1));

             if (j > 96 && j < 123)
             {
                 lower = true;
             }
             if (j > 64 && j < 91)
             {
                 Upper = true;
             }
             if (j > 47 && j < 58)
             {
                 bNumeric = true;
             }
             else
             {
                 bSpecial = true;
             }

             bValidate = lower;
         }

         return bValidate;

        }

        //string ValidateUsernamePassword( string uName, string uPass,string Logstat,string sHost, string sHostIP,string sbranchID)
        string ValidateUsernamePassword( string uName, string uPass,string Logstat,string sHost, string sHostIP,string sbranchID, string log_idle)

         {
            OSSData.Security oSecurity = new OSSData.Security();

           
            string sHostName = System.Environment.MachineName;
            string sKey2 = "Test OSS";
            string sResult = "";
            string sPostingConn = ConnString;
            string sDecryptPassword = DecryptPass(uName, uPass);
            string sbranchid = sbranchID;
                         
            string sUserName = uName;

            if (sKey2 == "")
            {
                sResult = "No Audit-Trail User registered in the system!";
            }
            else
            {

                sResult = oSecurity.ValidateUserLogin(sDecryptPassword, sUserName, Logstat, sPostingConn, sHost, sHostIP, sbranchid, log_idle);
                   /* 
                 	100 = OK
	                101 = Double Login
	                102 = user-ID is lock.
	                103 = Invalid User/Password
                 */
                switch (sResult)
                {
                    case "101":
                        sResult = "User Already Login.";
                        break;
                    case "102":
                        sResult = "User ID is lock.";
                        break;
                    case "103":
                        sResult = "Invalid User ID/Password.";
                        break;
                    case "104":
                        sResult = "User ID is Disabled.";
                        break;
                    
                    //E. Oarga 2015-11-26
                    case "105":
                        sResult = "Default Password.";
                        break;

                    case "106":
                        sResult = "Expiring Password";
                        break;

                    case "107":
                        sResult = "Expired Password";
                        break;

                    case "108":
                        sResult = "Idle User";
                        break;

                    case "109":
                        sResult = "Invalid Password.";
                        break;
                    //E. Oarga 2015-12-08

                    default:
                        sResult = "";
                        break;
                }
            }

            return sResult;
        }


        
        public void LogOffNow(string sUserName, string password, string Host, string sIp, string BranchID, string log_idle)
        {
            OSSData.Security oSecurity = new OSSData.Security();
            this.UserName = sUserName;
            this.UserPassword = password;
            this.sHostName = Host;
            this.sHostIP = sIp;
            this.sBranchCode = BranchID;
            
            ValidateUsernamePassword(this.UserName.ToString(),this.UserPassword.ToString(),"901",this.sHostName.ToString(),this.sHostIP.ToString(),this.sBranchCode.ToString(), log_idle);
        }   
        #endregion

        #region Get Branch
        public DataTable GetBranchCode(string sUsername)
        {
            
            DBConfig oDBConfig = new DBConfig();
            oDBConfig.ReadXML();
            
            ConnString = null;
            //ConnString = "Data Source=" + oDBConfig.DataSource  + ";Persist Security Info=False;" + "User ID=" + oDBConfig.UserName + ";Password=" + oDBConfig.Password + ";database=" + oDBConfig.Database;
            ConnString = "Data Source=" + oDBConfig.DataSource + ";Initial Catalog=" + oDBConfig.Database + ";"
                + "Integrated Security=SSPI";
            string sConnection = ConnString;
            objCnn.ConnectionString = ConnString;
            objCnn.Open();

            string sSQL = "exec BDOLFSP_GetBranchByUser '" + sUsername + "'";
            SqlDataAdapter oCmd = new SqlDataAdapter(sSQL,objCnn);
            DataSet oDS = new DataSet();
            try
            {
                dtbranch = SqlHelper.ExecuteDataset(objCnn, CommandType.Text, sSQL).Tables[0];
                dtbranch.TableName = "FsBranch";
                objCnn.Close();
                return dtbranch;
                
            }
            catch (SqlException e)
            {
                throw e;
            }

        }
        #endregion


    }
}
