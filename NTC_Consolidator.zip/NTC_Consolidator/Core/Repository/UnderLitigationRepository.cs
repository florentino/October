﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace NTC_Consolidator.Core.Repository
{
    public class UnderLitigationRepository : IUnderLitigation, IDisposable
    {
        private NTCConn context;
        DbSet<BDOLF_Consolidator> _bjectSet;

        public UnderLitigationRepository(NTCConn context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_Consolidator>();
        }

        public IEnumerable<BDOLF_Consolidator> GetAll()
        {
            var query = from data in context.BDOLF_Consolidator.ToList()
                        select data;

            return query;
        }

        public BDOLF_Consolidator GetByAccountNo(string AccountNo)
        {
            throw new NotImplementedException();
            //var result = context.BDOLF_Consolidator.Where(a => a.AccountNo == AccountNo).ToList();
            // return result.;
        }

        public BDOLF_Consolidator GetByAccountNo(int AccountNo)
        {
            throw new NotImplementedException();
        }

        public void InsertRecord(BDOLF_Consolidator litigation)
        {
            context.Set<BDOLF_Consolidator>().Add(litigation);
            context.SaveChanges();
        }

        public void UpdateConsolidator(BDOLF_Consolidator AULitigation)
        {
            var parameter = Convert.ToDateTime(AULitigation.RecordDate);

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

            var original = context.BDOLF_Consolidator.Where(a => a.AccountNo == AULitigation.AccountNo && (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth) && (a.SYSTEM == "AAF" || a.SYSTEM == "FAMS")).FirstOrDefault();

            DeleteConsolidator(original);

            context.BDOLF_Consolidator.Add(AULitigation);

            context.SaveChanges();
        }

        public void DeleteConsolidator(BDOLF_Consolidator AULitigation)
        {
            var parameter = Convert.ToDateTime(AULitigation.RecordDate);

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

            var original = context.BDOLF_Consolidator.Where(a => a.AccountNo == AULitigation.AccountNo && (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth) && (a.SYSTEM == "AAF" || a.SYSTEM == "FAMS")).AsEnumerable().ToList(); 

            context.BDOLF_Consolidator.RemoveRange(original);

            context.SaveChanges();
        }

        public bool AccountNotExists(string AccountNo, string keyword)
        {
            var parameter = Convert.ToDateTime(keyword);

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

            var exists = context.BDOLF_Consolidator.Where(a => a.AccountNo == AccountNo && (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth) && (a.SYSTEM == "AAF" || a.SYSTEM == "FAMS")).Any();
            return exists;
        }

        public void Save()
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
        }

        public string GetDate(string keyword)
        {
            var parameter = Convert.ToDateTime(keyword);

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
            var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).OrderByDescending(a => a.RecordDate).Take(1).FirstOrDefault().RecordDate;
                        

            //var query = from d in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).OrderByDescending(a => a.RecordDate).Take(1)
            //            select d.RecordDate;

            return query.ToString();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

       
    }
}
