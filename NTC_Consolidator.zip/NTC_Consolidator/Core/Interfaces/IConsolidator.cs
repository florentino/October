﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface IConsolidator : IDisposable
    {

        IEnumerable<BDOLF_Consolidator> GetAll(string AsOfDate, string rptAsOfDate, bool isFrmRPT);
        // IEnumerable<BDOLF_Consolidator> GetAll(string fromdate, string todate);
        DataTable ExceptionReportBlankIndustryCode(string datefrm, string dateTo, string system);
        DataTable ExceptionReportZeroAssetSize(string datefrm, string dateTo, string system);
        // Array ExceptionReportZeroAssetSizeICBS(DateTime datefrm, DateTime dateTo, string system);
        DataTable ExceptionReportDosriTagging(string datefrm, string dateTo, string system);
        DataTable ExceptionReportDifferenceInTaggingOfRriskAndGL(string datefrm, string dateTo, string system);
        Array GetDailyGL(DateTime datefrm, DateTime dateTo, string system);
        DataTable ExceptionReportSummaryReportSumOfOB(DateTime datefrm, DateTime dateTo, string system, string radio);
        DataTable ExceptionReportSummaryReportSumOfUDIBalance(DateTime datefrm, DateTime dateTo, string system, string radio);
        DataTable ExceptionReportSummaryReportSumOfPVRV(DateTime datefrm, DateTime dateTo, string system, string radio);
        DataTable ExceptionReportSummaryReportSumOfPVGD(DateTime datefrm, DateTime dateTo, string system, string radio);
        DataTable ExceptionReportSummaryReportSumOfACCRUEDINTERESTRECEIVABLE(DateTime datefrm, DateTime dateTo, string system, string radio);//SUM OF CLIENT'S EQUITY
        DataTable ExceptionReportSummaryReportSumOfCLIENTEQUITY(DateTime datefrm, DateTime dateTo, string system, string radio);
        Array Consolidator(DateTime datefrm, DateTime dateTo, string system);
        Array CorrespondingGL(DateTime datefrm, DateTime dateTo, string system);
        Array DailyGL(DateTime datefrm, DateTime dateTo, string system);
        Array ExchangeRate(DateTime datefrm, DateTime dateTo, string system);
        Array MigratedAccount(DateTime datefrm, DateTime dateTo, string system);
        Array PastDue(DateTime datefrm, DateTime dateTo, string system);
        Array QualifyingCapital(DateTime datefrm, DateTime dateTo, string system);
        Array UnderLitigation(DateTime datefrm, DateTime dateTo, string system);
        Array Summary(DateTime datefrm, DateTime dateTo, string system);
        BDOLF_Consolidator GetByID(int TransID);
        BDOLF_Consolidator GetByCode(string keyword);
        void DeleteInsertConsolidator(BDOLF_Consolidator ntc, string keyword);
        void DeleteConsolidator(int AccountNo);
        void TruncateTable();
        IEnumerable<BDOLF_Consolidator> GetTopOne();
        void DeleteConsolidator(string keyword);
        void UpdateConsolidator(BDOLF_Consolidator ntc);
        void BulkInsert(object[] objdata, string keyword);
        void BulkDelete(object[] objdata);
        void BulkUpdete(object[] objdata);
        string GetDate();
        string GetDate(string AsOfDate);

        bool ConsoChecker(string keyword);
        bool isGLCodeExist(string keyword, string keyword2, string keyword3);
        void Save();
    }
}
