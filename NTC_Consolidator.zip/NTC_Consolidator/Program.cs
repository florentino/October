﻿using MetroFramework;
using NTC_Consolidator.Helper;
using NTC_Consolidator.NTC_View;
using NTC_Encrypt_Decrypt;
using System;
using System.Configuration;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Reflection;
using System.Windows.Forms;

namespace NTC_Consolidator
{

    #region Final

    //static class Program
    //{
    //    public static string NTC_UserRole = String.Empty;
    //    public static string NTC_dbuserName = String.Empty;
    //    public static string NTC_dbpassword = String.Empty;
    //    public static string NTC_ServerName = String.Empty;
    //    public static string NTC_UserloginName = String.Empty;
    //    public static string NTC_DBName = String.Empty;
    //    public static string NTC_IntegSecurity = String.Empty;
    //    public static string NTC_PerSecurity = String.Empty;
    //    public static string NTC_ProviderName = "System.Data.SqlClient";
    //    public static string NTC_ConnectionName = "NTCConn";
    //    public static string NTC_DateFrom = "";
    //    public static string NTC_ReportPath = "";
    //    /// <summary>
    //    /// The main entry point for the application.
    //    /// </summary>
    //    [STAThread]
    //    static void Main(string[] args)
    //    {
    //        //  MessageBox.Show(args[0].ToString() + ",0 " + args[1].ToString() + ", 1" + args[2].ToString() + ", 2" + args[3].ToString() + ", 3" + args[4].ToString() + ", 4" + args[5].ToString() + ", 5" + args[6].ToString() + ", 6" + args[7].ToString() + ", 7");

    //        if (args[0] == "d@shb0@rd")
    //        {
    //            try
    //            {
    //                if (IsApplicationAlreadyRunning() == true)
    //                {
    //                    MessageBox.Show("NTC Consolidator is already running", "NTC Application", MessageBoxButtons.OK, MessageBoxIcon.Stop);
    //                }
    //                else
    //                {
    //                    //< add key = "UserName" value = "/wbeXw+dWBt8pwB3bSA+JQ==" /> --> output ====>>>>>>> "u_aaf2_appid"
    //                    //< add key = "Password" value = "nDOHmTVCk5tBzGQ7gyuXtg==" /> --> output ====>>>>>>> "Dont4get"
    //                    //< add key = "UserName" value = "0B+F5qaQEI9UnQpJ1SRsrg==" /> output ====>>>>>>> "d_aaf_sql"
    //                    //< add key = "Password" value = "Tqk/GX58kyPj1jYqSZ3UTA==" /> --> output ====>>>>>>> "P@ssword2"
    //                    //< add key = "UserName" value = "7wqxLjVXpwwNBf4+a5QLcQ==" /> output ====>>>>>>> "a_user"
    //                    //< add key = "Password" value = "Y/qZm98D1z+kl5EFL4zyuw==" /> output ====>>>>>>> "Password1"

    //                    //var Test_NTC_dbuserName = CipherDecipher.Cipher_Decipher.FromOSS_Decrypt("7wqxLjVXpwwNBf4+a5QLcQ==");
    //                    //var Test_NTC_dbpassword = CipherDecipher.Cipher_Decipher.FromOSS_Decrypt("Y/qZm98D1z+kl5EFL4zyuw==");

    //                    //     "d@shb0@rd " + NTC_ServerName + " " + NTC_DBName + " " + NTC_dbuserName + " " + NTC_dbpassword + " " + NTC_UserloginName + " " + NTC_UserRole + " " + NTC_DateFrom);

    //                    NTC_ServerName = args[1].ToString();
    //                    NTC_DBName = args[2].ToString();
    //                    NTC_dbuserName = args[3].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(args[3].ToString()) : ""; // NTC_dbuserName ==> e.g:  Kulangot
    //                    NTC_dbpassword = args[4].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(args[4].ToString()) : ""; // NTC_dbuserName ==> e.g:  Kulangot
    //                    NTC_UserloginName = args[5].ToString();

    //                    // MessageBox.Show(args[6].ToString());
    //                    NTC_ReportPath = args[6].ToString(); // @"\\bdowlas07v\AAF\NTC_Reports\"; //

    //                    // MessageBox.Show(args[0].ToString() + args[1].ToString() + args[2].ToString() + args[3].ToString() + args[4].ToString() + args[5].ToString() + args[6].ToString() + args[7].ToString());
    //                    ModifyDataBaseConnection();

    //                    Application.EnableVisualStyles();
    //                    Application.SetCompatibleTextRenderingDefault(false);
    //                    Application.Run(new frmConsolidator());
    //                    //frmConsolidator frmunderLitigation = frmConsolidator.Instance();
    //                    //frmunderLitigation.ShowDialog();
    //                }
    //            }
    //            catch (Exception ex)
    //            {
    //                var ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

    //                //var Modulename = "Main: trackValue =>  " + trackValue;
    //                var Modulename = "Program";
    //                var methodName = MethodBase.GetCurrentMethod().Name;
    //                ErrorLog.GetLogFilePath(e.Error, Modulename, methodName, ErrorID, ErrList);

    //                MessageBox.Show("ERROR LogID: " + ErrorID + "\r\n\r\nAn Error occured during execution of NTC Consolidator. Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
    //            }
    //        }
    //        else
    //        {
    //            MessageBox.Show("Access is denied. User is unauthorized or has limited rights on this module", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
    //        }
    //    }


    //    static bool IsApplicationAlreadyRunning()
    //    {
    //        string proc = Process.GetCurrentProcess().ProcessName;
    //        Process[] processes = Process.GetProcessesByName(proc);
    //        return processes.Length > 1 ? true : false;
    //    }

    //    //private static void ModifyDataBaseConnection(string _providerbname, string _servername, string _dbname, string _userid, string _password, string ntc_connectionname)
    //    private static void ModifyDataBaseConnection()
    //    {
    //        // < add name = "NTCConn" connectionString = "metadata=res://*/Data.NTC_Model.csdl|res://*/Data.NTC_Model.ssdl|res://*/Data.NTC_Model.msl;provider=System.Data.SqlClient;provider connection string=&quot;data source=bdowldb10v;initial catalog=tmpNTC;user id=d_aaf_test2;password=password;MultipleActiveResultSets=True;App=EntityFramework&quot;" providerName = "System.Data.EntityClient" />

    //        // Specify the provider name, server and database.
    //        string providerName = NTC_ProviderName;
    //        string serverName = NTC_ServerName;
    //        string databaseName = NTC_DBName;
    //        string Metadata = @"res://*/Data.NTC_Model.csdl|res://*/Data.NTC_Model.ssdl|res://*/Data.NTC_Model.msl";
    //        string userId = NTC_dbuserName;
    //        string password = NTC_dbpassword;

    //        // Initialize the connection string builder for the
    //        // underlying provider.
    //        SqlConnectionStringBuilder sqlBuilder = new SqlConnectionStringBuilder();

    //        // Set the properties for the data source.
    //        sqlBuilder.DataSource = serverName;
    //        sqlBuilder.InitialCatalog = databaseName;
    //        sqlBuilder.IntegratedSecurity = false;
    //        sqlBuilder.UserID = userId;
    //        sqlBuilder.Password = password;
    //        sqlBuilder.PersistSecurityInfo = true;

    //        // Build the SqlConnection connection string.
    //        string providerString = sqlBuilder.ToString();

    //        // Initialize the EntityConnectionStringBuilder.
    //        EntityConnectionStringBuilder entityBuilder = new EntityConnectionStringBuilder();

    //        //Set the provider name.
    //        entityBuilder.Provider = providerName;

    //        // Set the provider-specific connection string.
    //        entityBuilder.ProviderConnectionString = providerString;

    //        // Set the Metadata location.
    //        entityBuilder.Metadata = Metadata;

    //        Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
    //        //config.ConnectionStrings.ConnectionStrings["NTCConn"].ConnectionString = entityBuilder.ToString();
    //        config.ConnectionStrings.ConnectionStrings[NTC_ConnectionName].ConnectionString = entityBuilder.ToString();
    //        config.Save(ConfigurationSaveMode.Modified, true);
    //        ConfigurationManager.RefreshSection("connectionStrings");

    //        //using (EntityConnection conn = new EntityConnection(entityBuilder.ToString()))
    //        //{
    //        //    conn.Open();
    //        //    MessageBox.Show("Just testing the connection.");
    //        //    conn.Close();
    //        //}
    //    }
    //}

    #endregion


    #region For Testing

    static class Program
    {
        public static string NTC_UserRole = String.Empty;
        public static string NTC_dbuserName = String.Empty;
        public static string NTC_dbpassword = String.Empty;
        public static string NTC_ServerName = String.Empty;
        public static string NTC_UserloginName = String.Empty;
        public static string NTC_DBName = String.Empty;
        public static string NTC_IntegSecurity = String.Empty;
        public static string NTC_PerSecurity = String.Empty;
        public static string NTC_ProviderName = "System.Data.SqlClient";
        public static string NTC_ConnectionName = "NTCConn";
        public static string NTC_DateFrom = "";
        public static string NTC_ReportPath = "";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                //if (IsApplicationAlreadyRunning() == true)
                //{
                //    MessageBox.Show("NTC Consolidator is already running", "NTC Application", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //}
                //else
                //{
                NTC_ServerName = "BDOWLDB10V";
                NTC_DBName = "tmpNTC";
                NTC_dbuserName = "d_aaf_test2";
                NTC_dbpassword = "password";
                NTC_UserloginName = "c161007003";
                //NTC_DateFrom = "07/01/2018";
                NTC_ReportPath = @"\\bdowlas07v\AAF\NTC_Reports\";
                //Uncomment this part if the connection is encrypted

                ////UserName = data[0].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[0].ToString()) : ""; // NTC_userId ==> e.g:  Mangkanor
                ////Password = data[1].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[1].ToString()) : ""; // NTC_password ==> e.g:  Kulangot
                ////DbServer = data[2].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[2].ToString()) : ""; // NTC_ServerName ==> e.g:  BDOWLDB13V
                ////Role = data[3].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[3].ToString()) : ""; // NTC_Role ==> e.g:  BackFighter
                ////DBName = data[4].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[4].ToString()) : ""; // NTC_DBName ==> e.g:  dbAAF_SalesRec
                ////ProviderName = data[5].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[5].ToString()) : ""; // NTC_DBName ==> e.g:  NTCConnNTC_ProviderName
                ////ConnectionName = data[6].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[6].ToString()) : ""; // NTC_DBName ==> e.g:  NTCConn
                //                      0             1                  2                    3                       4                      5                      6
                // trackValue = "d@shb0@rd " + NTC_ServerName + " " + NTC_DBName + " " + NTC_dbuserName + " " + NTC_dbpassword + " " + NTC_UserloginName + " " + NTC_UserRole;

                //trackValue = NTC_ServerName + " " + NTC_DBName + " " + NTC_dbuserName + " " + NTC_dbpassword + " " + NTC_UserloginName;// + " " + args[6].ToString();


               // ModifyDataBaseConnection();

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmConsolidator());
                // }
            }
            catch (Exception ex)
            {
                var ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                //var Modulename = "Main: trackValue =>  " + trackValue;
                var Modulename = "Main";
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID, null);

                MessageBox.Show("ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.InnerException.Message.ToString() + "\r\n\r\nAn Error occured during execution of NTC Consolidator. Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

        }


        static bool IsApplicationAlreadyRunning()
        {
            string proc = Process.GetCurrentProcess().ProcessName;
            Process[] processes = Process.GetProcessesByName(proc);
            return processes.Length > 1 ? true : false;
        }

        //private static void ModifyDataBaseConnection(string _providerbname, string _servername, string _dbname, string _userid, string _password, string ntc_connectionname)
        public static void ModifyDataBaseConnection(string NTC_ProviderName, string NTC_ServerName, string NTC_DBName )
        {
            // < add name = "NTCConn" connectionString = "metadata=res://*/Data.NTC_Model.csdl|res://*/Data.NTC_Model.ssdl|res://*/Data.NTC_Model.msl;provider=System.Data.SqlClient;provider connection string=&quot;data source=bdowldb10v;initial catalog=tmpNTC;user id=d_aaf_test2;password=password;MultipleActiveResultSets=True;App=EntityFramework&quot;" providerName = "System.Data.EntityClient" />

            // Specify the provider name, server and database.
            string providerName = NTC_ProviderName;
            string serverName = NTC_ServerName;
            string databaseName = NTC_DBName;
            string Metadata = @"res://*/Data.NTC_Model.csdl|res://*/Data.NTC_Model.ssdl|res://*/Data.NTC_Model.msl";
            string userId = NTC_dbuserName;
            string password = NTC_dbpassword;

            // Initialize the connection string builder for the
            // underlying provider.
            SqlConnectionStringBuilder sqlBuilder = new SqlConnectionStringBuilder();

            // Set the properties for the data source.
            sqlBuilder.DataSource = serverName;
            sqlBuilder.InitialCatalog = databaseName;
            sqlBuilder.IntegratedSecurity = false;
            sqlBuilder.UserID = userId;
            sqlBuilder.PersistSecurityInfo = true;
            sqlBuilder.Password = password;

            // Build the SqlConnection connection string.
            string providerString = sqlBuilder.ToString();

            // Initialize the EntityConnectionStringBuilder.
            EntityConnectionStringBuilder entityBuilder = new EntityConnectionStringBuilder();

            //Set the provider name.
            entityBuilder.Provider = providerName;

            // Set the provider-specific connection string.
            entityBuilder.ProviderConnectionString = providerString;

            // Set the Metadata location.
            entityBuilder.Metadata = Metadata;

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            //config.ConnectionStrings.ConnectionStrings["NTCConn"].ConnectionString = entityBuilder.ToString();
            config.ConnectionStrings.ConnectionStrings[NTC_ConnectionName].ConnectionString = entityBuilder.ToString();
            config.Save(ConfigurationSaveMode.Modified, true);
            ConfigurationManager.RefreshSection("connectionStrings");

            //using (EntityConnection conn = new EntityConnection(entityBuilder.ToString()))
            //{
            //    conn.Open();
            //    MessageBox.Show("Just testing the connection.");
            //    conn.Close();
            //}
        }
    }

    #endregion

}


