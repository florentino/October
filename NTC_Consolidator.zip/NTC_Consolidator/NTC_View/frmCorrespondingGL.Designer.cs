﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmCorrespondingGL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCorrespondingGL));
            this.lblErrGLName = new MetroFramework.Controls.MetroLabel();
            this.lblErrGLCode = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.txtGLCode = new MetroFramework.Controls.MetroTextBox();
            this.btnSubmit = new MetroFramework.Controls.MetroButton();
            this.txtGLName = new MetroFramework.Controls.MetroTextBox();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.dgvGL = new MetroFramework.Controls.MetroGrid();
            this.cntxMenu = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.editRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertNewRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSearch = new MetroFramework.Controls.MetroButton();
            this.txtSearch = new MetroFramework.Controls.MetroTextBox();
            this.txtProductDesc = new MetroFramework.Controls.MetroTextBox();
            this.lblErrProductDesc = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.lblErrSystemTagging = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.cmbSysTagging = new MetroFramework.Controls.MetroComboBox();
            this.btnExport = new MetroFramework.Controls.MetroButton();
            this.lblBusy = new MetroFramework.Controls.MetroLabel();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.SaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.cmbStatus = new MetroFramework.Controls.MetroComboBox();
            this.lblErrStatus = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.lnkBulkInsert = new System.Windows.Forms.LinkLabel();
            this.pnlDialog = new System.Windows.Forms.Panel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.btnBrowse = new MetroFramework.Controls.MetroButton();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtFilePath = new MetroFramework.Controls.MetroTextBox();
            this.pnlWaitInfo = new System.Windows.Forms.Panel();
            this.lblWaitStatus1 = new MetroFramework.Controls.MetroLabel();
            this.lblWaitFilePath = new MetroFramework.Controls.MetroLabel();
            this.lblWaitStatus = new MetroFramework.Controls.MetroLabel();
            this.lblWaitInfo = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.btnClose = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGL)).BeginInit();
            this.cntxMenu.SuspendLayout();
            this.pnlDialog.SuspendLayout();
            this.pnlWaitInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblErrGLName
            // 
            this.lblErrGLName.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrGLName.ForeColor = System.Drawing.Color.Red;
            this.lblErrGLName.Location = new System.Drawing.Point(312, 246);
            this.lblErrGLName.Name = "lblErrGLName";
            this.lblErrGLName.Size = new System.Drawing.Size(278, 19);
            this.lblErrGLName.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrGLName.TabIndex = 27;
            this.lblErrGLName.UseStyleColors = true;
            // 
            // lblErrGLCode
            // 
            this.lblErrGLCode.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrGLCode.ForeColor = System.Drawing.Color.Red;
            this.lblErrGLCode.Location = new System.Drawing.Point(312, 197);
            this.lblErrGLCode.Name = "lblErrGLCode";
            this.lblErrGLCode.Size = new System.Drawing.Size(278, 19);
            this.lblErrGLCode.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrGLCode.TabIndex = 26;
            this.lblErrGLCode.UseStyleColors = true;
            this.lblErrGLCode.Click += new System.EventHandler(this.lblErrGLCode_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(31, 220);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(64, 19);
            this.metroLabel3.TabIndex = 24;
            this.metroLabel3.Text = "GL Name";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(31, 171);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(60, 19);
            this.metroLabel2.TabIndex = 23;
            this.metroLabel2.Text = "GL Code";
            // 
            // txtGLCode
            // 
            this.txtGLCode.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtGLCode.CustomButton.Image = null;
            this.txtGLCode.CustomButton.Location = new System.Drawing.Point(256, 1);
            this.txtGLCode.CustomButton.Name = "";
            this.txtGLCode.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtGLCode.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGLCode.CustomButton.TabIndex = 1;
            this.txtGLCode.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtGLCode.CustomButton.UseSelectable = true;
            this.txtGLCode.CustomButton.Visible = false;
            this.txtGLCode.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtGLCode.Lines = new string[0];
            this.txtGLCode.Location = new System.Drawing.Point(31, 193);
            this.txtGLCode.MaxLength = 32767;
            this.txtGLCode.Name = "txtGLCode";
            this.txtGLCode.PasswordChar = '\0';
            this.txtGLCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGLCode.SelectedText = "";
            this.txtGLCode.SelectionLength = 0;
            this.txtGLCode.SelectionStart = 0;
            this.txtGLCode.Size = new System.Drawing.Size(278, 23);
            this.txtGLCode.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGLCode.TabIndex = 6;
            this.txtGLCode.UseSelectable = true;
            this.txtGLCode.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtGLCode.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtGLCode.TextChanged += new System.EventHandler(this.txtGLCode_TextChanged);
            // 
            // btnSubmit
            // 
            this.btnSubmit.AutoSize = true;
            this.btnSubmit.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSubmit.ForeColor = System.Drawing.Color.White;
            this.btnSubmit.Highlight = true;
            this.btnSubmit.Location = new System.Drawing.Point(608, 651);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(68, 23);
            this.btnSubmit.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnSubmit.TabIndex = 3;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseCustomBackColor = true;
            this.btnSubmit.UseCustomForeColor = true;
            this.btnSubmit.UseSelectable = true;
            this.btnSubmit.UseStyleColors = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtGLName
            // 
            this.txtGLName.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtGLName.CustomButton.Image = null;
            this.txtGLName.CustomButton.Location = new System.Drawing.Point(256, 1);
            this.txtGLName.CustomButton.Name = "";
            this.txtGLName.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtGLName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGLName.CustomButton.TabIndex = 1;
            this.txtGLName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtGLName.CustomButton.UseSelectable = true;
            this.txtGLName.CustomButton.Visible = false;
            this.txtGLName.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtGLName.Lines = new string[0];
            this.txtGLName.Location = new System.Drawing.Point(31, 242);
            this.txtGLName.MaxLength = 32767;
            this.txtGLName.Name = "txtGLName";
            this.txtGLName.PasswordChar = '\0';
            this.txtGLName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGLName.SelectedText = "";
            this.txtGLName.SelectionLength = 0;
            this.txtGLName.SelectionStart = 0;
            this.txtGLName.Size = new System.Drawing.Size(278, 23);
            this.txtGLName.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGLName.TabIndex = 7;
            this.txtGLName.UseSelectable = true;
            this.txtGLName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtGLName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroPanel1.Controls.Add(this.dgvGL);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(31, 374);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(646, 248);
            this.metroPanel1.TabIndex = 30;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // dgvGL
            // 
            this.dgvGL.AllowUserToAddRows = false;
            this.dgvGL.AllowUserToDeleteRows = false;
            this.dgvGL.AllowUserToResizeRows = false;
            this.dgvGL.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGL.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvGL.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvGL.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvGL.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvGL.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvGL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGL.ContextMenuStrip = this.cntxMenu;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvGL.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvGL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvGL.EnableHeadersVisualStyles = false;
            this.dgvGL.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvGL.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvGL.Location = new System.Drawing.Point(0, 0);
            this.dgvGL.Name = "dgvGL";
            this.dgvGL.ReadOnly = true;
            this.dgvGL.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvGL.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvGL.RowHeadersVisible = false;
            this.dgvGL.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvGL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGL.Size = new System.Drawing.Size(644, 246);
            this.dgvGL.TabIndex = 10;
            this.dgvGL.Theme = MetroFramework.MetroThemeStyle.Light;
            this.dgvGL.UseCustomBackColor = true;
            this.dgvGL.UseCustomForeColor = true;
            this.dgvGL.UseStyleColors = true;
            this.dgvGL.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGL_CellClick);
            this.dgvGL.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGL_CellLeave);
            this.dgvGL.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvGL_CellMouseDown);
            // 
            // cntxMenu
            // 
            this.cntxMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editRecordToolStripMenuItem,
            this.deleteRecordToolStripMenuItem,
            this.insertNewRecordToolStripMenuItem});
            this.cntxMenu.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.cntxMenu.Name = "cntxMenu";
            this.cntxMenu.Size = new System.Drawing.Size(165, 70);
            // 
            // editRecordToolStripMenuItem
            // 
            this.editRecordToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("editRecordToolStripMenuItem.Image")));
            this.editRecordToolStripMenuItem.Name = "editRecordToolStripMenuItem";
            this.editRecordToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.editRecordToolStripMenuItem.Text = "Edit Record";
            this.editRecordToolStripMenuItem.Click += new System.EventHandler(this.editRecordToolStripMenuItem_Click);
            // 
            // deleteRecordToolStripMenuItem
            // 
            this.deleteRecordToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("deleteRecordToolStripMenuItem.Image")));
            this.deleteRecordToolStripMenuItem.Name = "deleteRecordToolStripMenuItem";
            this.deleteRecordToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.deleteRecordToolStripMenuItem.Text = "Delete Record";
            this.deleteRecordToolStripMenuItem.Click += new System.EventHandler(this.deleteRecordToolStripMenuItem_Click);
            // 
            // insertNewRecordToolStripMenuItem
            // 
            this.insertNewRecordToolStripMenuItem.Name = "insertNewRecordToolStripMenuItem";
            this.insertNewRecordToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.insertNewRecordToolStripMenuItem.Text = "Insert New Record";
            this.insertNewRecordToolStripMenuItem.Click += new System.EventHandler(this.insertNewRecordToolStripMenuItem_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackgroundImage = global::NTC_Consolidator.Properties.Resources.sync;
            this.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearch.Location = new System.Drawing.Point(645, 343);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(32, 29);
            this.btnSearch.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnSearch.TabIndex = 2;
            this.btnSearch.UseCustomBackColor = true;
            this.btnSearch.UseCustomForeColor = true;
            this.btnSearch.UseSelectable = true;
            this.btnSearch.UseStyleColors = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            // 
            // 
            // 
            this.txtSearch.CustomButton.AutoEllipsis = true;
            this.txtSearch.CustomButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.txtSearch.CustomButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txtSearch.CustomButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.CustomButton.Image = null;
            this.txtSearch.CustomButton.Location = new System.Drawing.Point(212, 1);
            this.txtSearch.CustomButton.Name = "";
            this.txtSearch.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txtSearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSearch.CustomButton.TabIndex = 1;
            this.txtSearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSearch.CustomButton.UseSelectable = true;
            this.txtSearch.CustomButton.Visible = false;
            this.txtSearch.DisplayIcon = true;
            this.txtSearch.Lines = new string[0];
            this.txtSearch.Location = new System.Drawing.Point(406, 343);
            this.txtSearch.MaxLength = 32767;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.PasswordChar = '\0';
            this.txtSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSearch.SelectedText = "";
            this.txtSearch.SelectionLength = 0;
            this.txtSearch.SelectionStart = 0;
            this.txtSearch.Size = new System.Drawing.Size(240, 29);
            this.txtSearch.TabIndex = 1;
            this.txtSearch.UseSelectable = true;
            this.txtSearch.WaterMark = "Enter Keyword";
            this.txtSearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // txtProductDesc
            // 
            this.txtProductDesc.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtProductDesc.CustomButton.Image = null;
            this.txtProductDesc.CustomButton.Location = new System.Drawing.Point(256, 1);
            this.txtProductDesc.CustomButton.Name = "";
            this.txtProductDesc.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtProductDesc.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtProductDesc.CustomButton.TabIndex = 1;
            this.txtProductDesc.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtProductDesc.CustomButton.UseSelectable = true;
            this.txtProductDesc.CustomButton.Visible = false;
            this.txtProductDesc.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtProductDesc.Lines = new string[0];
            this.txtProductDesc.Location = new System.Drawing.Point(31, 290);
            this.txtProductDesc.MaxLength = 32767;
            this.txtProductDesc.Name = "txtProductDesc";
            this.txtProductDesc.PasswordChar = '\0';
            this.txtProductDesc.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtProductDesc.SelectedText = "";
            this.txtProductDesc.SelectionLength = 0;
            this.txtProductDesc.SelectionStart = 0;
            this.txtProductDesc.Size = new System.Drawing.Size(278, 23);
            this.txtProductDesc.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtProductDesc.TabIndex = 8;
            this.txtProductDesc.UseSelectable = true;
            this.txtProductDesc.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtProductDesc.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lblErrProductDesc
            // 
            this.lblErrProductDesc.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrProductDesc.ForeColor = System.Drawing.Color.Red;
            this.lblErrProductDesc.Location = new System.Drawing.Point(312, 294);
            this.lblErrProductDesc.Name = "lblErrProductDesc";
            this.lblErrProductDesc.Size = new System.Drawing.Size(278, 19);
            this.lblErrProductDesc.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrProductDesc.TabIndex = 33;
            this.lblErrProductDesc.UseStyleColors = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(31, 268);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(124, 19);
            this.metroLabel4.TabIndex = 32;
            this.metroLabel4.Text = "Product Description";
            // 
            // lblErrSystemTagging
            // 
            this.lblErrSystemTagging.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrSystemTagging.ForeColor = System.Drawing.Color.Red;
            this.lblErrSystemTagging.Location = new System.Drawing.Point(312, 93);
            this.lblErrSystemTagging.Name = "lblErrSystemTagging";
            this.lblErrSystemTagging.Size = new System.Drawing.Size(278, 19);
            this.lblErrSystemTagging.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrSystemTagging.TabIndex = 36;
            this.lblErrSystemTagging.UseStyleColors = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(31, 60);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(50, 19);
            this.metroLabel5.TabIndex = 35;
            this.metroLabel5.Text = "System";
            // 
            // cmbSysTagging
            // 
            this.cmbSysTagging.BackColor = System.Drawing.Color.White;
            this.cmbSysTagging.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSysTagging.FormattingEnabled = true;
            this.cmbSysTagging.ItemHeight = 23;
            this.cmbSysTagging.Items.AddRange(new object[] {
            "ICBS",
            "AAF",
            "FAMS"});
            this.cmbSysTagging.Location = new System.Drawing.Point(32, 83);
            this.cmbSysTagging.Name = "cmbSysTagging";
            this.cmbSysTagging.Size = new System.Drawing.Size(274, 29);
            this.cmbSysTagging.TabIndex = 5;
            this.cmbSysTagging.UseSelectable = true;
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnExport.ForeColor = System.Drawing.Color.White;
            this.btnExport.Highlight = true;
            this.btnExport.Location = new System.Drawing.Point(352, 651);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(95, 23);
            this.btnExport.TabIndex = 4;
            this.btnExport.Text = "Export To Excel";
            this.btnExport.UseCustomBackColor = true;
            this.btnExport.UseCustomForeColor = true;
            this.btnExport.UseSelectable = true;
            this.btnExport.UseStyleColors = true;
            this.btnExport.Visible = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // lblBusy
            // 
            this.lblBusy.ForeColor = System.Drawing.Color.Red;
            this.lblBusy.Location = new System.Drawing.Point(32, 624);
            this.lblBusy.Name = "lblBusy";
            this.lblBusy.Size = new System.Drawing.Size(270, 21);
            this.lblBusy.TabIndex = 39;
            this.lblBusy.Text = "[busy status]";
            this.lblBusy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBusy.UseCustomForeColor = true;
            this.lblBusy.Visible = false;
            // 
            // backgroundWorker1
            // 
            this.backgroundWorker1.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker1_DoWork);
            this.backgroundWorker1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker1_RunWorkerCompleted);
            // 
            // cmbStatus
            // 
            this.cmbStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.IntegralHeight = false;
            this.cmbStatus.ItemHeight = 23;
            this.cmbStatus.Items.AddRange(new object[] {
            "Current",
            "Pending",
            "Complete",
            "Rejected"});
            this.cmbStatus.Location = new System.Drawing.Point(31, 139);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(274, 29);
            this.cmbStatus.TabIndex = 9;
            this.cmbStatus.UseSelectable = true;
            // 
            // lblErrStatus
            // 
            this.lblErrStatus.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrStatus.ForeColor = System.Drawing.Color.Red;
            this.lblErrStatus.Location = new System.Drawing.Point(311, 149);
            this.lblErrStatus.Name = "lblErrStatus";
            this.lblErrStatus.Size = new System.Drawing.Size(278, 19);
            this.lblErrStatus.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrStatus.TabIndex = 42;
            this.lblErrStatus.UseStyleColors = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(30, 116);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(43, 19);
            this.metroLabel6.TabIndex = 41;
            this.metroLabel6.Text = "Status";
            // 
            // lnkBulkInsert
            // 
            this.lnkBulkInsert.AutoSize = true;
            this.lnkBulkInsert.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkBulkInsert.Location = new System.Drawing.Point(32, 359);
            this.lnkBulkInsert.Name = "lnkBulkInsert";
            this.lnkBulkInsert.Size = new System.Drawing.Size(64, 13);
            this.lnkBulkInsert.TabIndex = 43;
            this.lnkBulkInsert.TabStop = true;
            this.lnkBulkInsert.Text = "Batch Insert";
            this.lnkBulkInsert.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkBulkInsert_LinkClicked);
            // 
            // pnlDialog
            // 
            this.pnlDialog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlDialog.Controls.Add(this.metroLabel7);
            this.pnlDialog.Controls.Add(this.btnBrowse);
            this.pnlDialog.Controls.Add(this.metroLabel1);
            this.pnlDialog.Controls.Add(this.txtFilePath);
            this.pnlDialog.Location = new System.Drawing.Point(777, 139);
            this.pnlDialog.Name = "pnlDialog";
            this.pnlDialog.Size = new System.Drawing.Size(390, 111);
            this.pnlDialog.TabIndex = 44;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.metroLabel7.Location = new System.Drawing.Point(367, 2);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(18, 19);
            this.metroLabel7.TabIndex = 57;
            this.metroLabel7.Text = "X";
            this.metroLabel7.UseCustomBackColor = true;
            this.metroLabel7.UseCustomForeColor = true;
            this.metroLabel7.UseStyleColors = true;
            this.metroLabel7.Click += new System.EventHandler(this.metroLabel7_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnBrowse.Location = new System.Drawing.Point(300, 50);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 54;
            this.btnBrowse.Text = "Bowse...";
            this.btnBrowse.UseCustomBackColor = true;
            this.btnBrowse.UseCustomForeColor = true;
            this.btnBrowse.UseSelectable = true;
            this.btnBrowse.UseStyleColors = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(8, 52);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(78, 19);
            this.metroLabel1.TabIndex = 56;
            this.metroLabel1.Text = "Browse File:";
            // 
            // txtFilePath
            // 
            // 
            // 
            // 
            this.txtFilePath.CustomButton.Image = null;
            this.txtFilePath.CustomButton.Location = new System.Drawing.Point(192, 1);
            this.txtFilePath.CustomButton.Name = "";
            this.txtFilePath.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtFilePath.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtFilePath.CustomButton.TabIndex = 1;
            this.txtFilePath.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtFilePath.CustomButton.UseSelectable = true;
            this.txtFilePath.CustomButton.Visible = false;
            this.txtFilePath.Lines = new string[0];
            this.txtFilePath.Location = new System.Drawing.Point(87, 50);
            this.txtFilePath.MaxLength = 32767;
            this.txtFilePath.Name = "txtFilePath";
            this.txtFilePath.PasswordChar = '\0';
            this.txtFilePath.ReadOnly = true;
            this.txtFilePath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtFilePath.SelectedText = "";
            this.txtFilePath.SelectionLength = 0;
            this.txtFilePath.SelectionStart = 0;
            this.txtFilePath.Size = new System.Drawing.Size(214, 23);
            this.txtFilePath.TabIndex = 55;
            this.txtFilePath.UseSelectable = true;
            this.txtFilePath.WaterMark = "Source File";
            this.txtFilePath.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtFilePath.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // pnlWaitInfo
            // 
            this.pnlWaitInfo.BackColor = System.Drawing.Color.Transparent;
            this.pnlWaitInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus1);
            this.pnlWaitInfo.Controls.Add(this.lblWaitFilePath);
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus);
            this.pnlWaitInfo.Controls.Add(this.lblWaitInfo);
            this.pnlWaitInfo.Controls.Add(this.pictureBox1);
            this.pnlWaitInfo.Location = new System.Drawing.Point(777, 279);
            this.pnlWaitInfo.Name = "pnlWaitInfo";
            this.pnlWaitInfo.Size = new System.Drawing.Size(326, 117);
            this.pnlWaitInfo.TabIndex = 84;
            // 
            // lblWaitStatus1
            // 
            this.lblWaitStatus1.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus1.Location = new System.Drawing.Point(3, 156);
            this.lblWaitStatus1.Name = "lblWaitStatus1";
            this.lblWaitStatus1.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus1.TabIndex = 4;
            this.lblWaitStatus1.Text = "Total Numbers of Records:";
            this.lblWaitStatus1.Visible = false;
            // 
            // lblWaitFilePath
            // 
            this.lblWaitFilePath.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitFilePath.Location = new System.Drawing.Point(3, 175);
            this.lblWaitFilePath.Name = "lblWaitFilePath";
            this.lblWaitFilePath.Size = new System.Drawing.Size(322, 19);
            this.lblWaitFilePath.TabIndex = 3;
            this.lblWaitFilePath.Text = "File Path:";
            this.lblWaitFilePath.Visible = false;
            // 
            // lblWaitStatus
            // 
            this.lblWaitStatus.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus.Location = new System.Drawing.Point(3, 91);
            this.lblWaitStatus.Name = "lblWaitStatus";
            this.lblWaitStatus.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus.TabIndex = 2;
            this.lblWaitStatus.Text = "Status: ";
            // 
            // lblWaitInfo
            // 
            this.lblWaitInfo.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitInfo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblWaitInfo.Location = new System.Drawing.Point(3, 60);
            this.lblWaitInfo.Name = "lblWaitInfo";
            this.lblWaitInfo.Size = new System.Drawing.Size(318, 23);
            this.lblWaitInfo.TabIndex = 1;
            this.lblWaitInfo.Text = "Reading ICBS Raw File, Please Wait...";
            this.lblWaitInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::NTC_Consolidator.Properties.Resources.lg_discuss_ellipsis_preloader;
            this.pictureBox1.Location = new System.Drawing.Point(3, -14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(318, 94);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.Location = new System.Drawing.Point(128, 359);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(131, 13);
            this.linkLabel1.TabIndex = 85;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Download Excel Template";
            this.linkLabel1.Visible = false;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // btnClose
            // 
            this.btnClose.AutoSize = true;
            this.btnClose.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Highlight = true;
            this.btnClose.Location = new System.Drawing.Point(536, 651);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(68, 23);
            this.btnClose.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnClose.TabIndex = 86;
            this.btnClose.Text = "&Close";
            this.btnClose.UseCustomBackColor = true;
            this.btnClose.UseCustomForeColor = true;
            this.btnClose.UseSelectable = true;
            this.btnClose.UseStyleColors = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmCorrespondingGL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(709, 697);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.pnlWaitInfo);
            this.Controls.Add(this.pnlDialog);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.lnkBulkInsert);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.lblErrStatus);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.lblBusy);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.cmbSysTagging);
            this.Controls.Add(this.lblErrSystemTagging);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.txtProductDesc);
            this.Controls.Add(this.lblErrProductDesc);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.txtGLName);
            this.Controls.Add(this.lblErrGLName);
            this.Controls.Add(this.lblErrGLCode);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtGLCode);
            this.Controls.Add(this.btnSubmit);
            this.MaximizeBox = false;
            this.Name = "frmCorrespondingGL";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "Corresponding GL";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmCorrespondingGL_FormClosed);
            this.Load += new System.EventHandler(this.frmCorrespomdingGL_Load);
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGL)).EndInit();
            this.cntxMenu.ResumeLayout(false);
            this.pnlDialog.ResumeLayout(false);
            this.pnlDialog.PerformLayout();
            this.pnlWaitInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblErrGLName;
        private MetroFramework.Controls.MetroLabel lblErrGLCode;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox txtGLCode;
        private MetroFramework.Controls.MetroButton btnSubmit;
        private MetroFramework.Controls.MetroTextBox txtGLName;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroGrid dgvGL;
        private MetroFramework.Controls.MetroButton btnSearch;
        private MetroFramework.Controls.MetroTextBox txtSearch;
        private MetroFramework.Controls.MetroTextBox txtProductDesc;
        private MetroFramework.Controls.MetroLabel lblErrProductDesc;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel lblErrSystemTagging;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroComboBox cmbSysTagging;
        private MetroFramework.Controls.MetroButton btnExport;
        private MetroFramework.Controls.MetroLabel lblBusy;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.SaveFileDialog SaveFileDialog;
        private MetroFramework.Controls.MetroContextMenu cntxMenu;
        private System.Windows.Forms.ToolStripMenuItem editRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteRecordToolStripMenuItem;
        private MetroFramework.Controls.MetroComboBox cmbStatus;
        private MetroFramework.Controls.MetroLabel lblErrStatus;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private System.Windows.Forms.ToolStripMenuItem insertNewRecordToolStripMenuItem;
        private System.Windows.Forms.LinkLabel lnkBulkInsert;
        private System.Windows.Forms.Panel pnlDialog;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroButton btnBrowse;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtFilePath;
        private System.Windows.Forms.Panel pnlWaitInfo;
        private MetroFramework.Controls.MetroLabel lblWaitStatus1;
        private MetroFramework.Controls.MetroLabel lblWaitFilePath;
        private MetroFramework.Controls.MetroLabel lblWaitStatus;
        private MetroFramework.Controls.MetroLabel lblWaitInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private MetroFramework.Controls.MetroButton btnClose;
    }
}