﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmPastDue : MetroFramework.Forms.MetroForm
    {
        private static frmPastDue frmpastDue = null;
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtPastDueAccount;
        string pastDueAccountFileName = "";
        string ErrorID = "";
        NumberStyles styles;
        DateTime dateparam;
        string[] progressArray = new string[5];
        bool isNoData = false;
        private IPastDueAccount pastDueAccountRepository;
        Dictionary<string, string> ErrList = new Dictionary<string, string>();
        public static frmPastDue Instance()
        {
            if (frmpastDue == null)
            {
                frmpastDue = new frmPastDue();
            }
            return frmpastDue;
        }


        public frmPastDue()
        {
            InitializeComponent();
            this.pastDueAccountRepository = new PastDueAccountRepository(new NTCConn());

            pnlWaitInfo.Location = new Point(
           this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            //  pnlSummary.Location = new Point(
            // this.ClientSize.Width / 2 - pnlSummary.Size.Width / 2,
            // this.ClientSize.Height / 2 - pnlSummary.Size.Height / 2);
            //  pnlSummary.Visible = false;

            //  pnlInsertUpdate.Location = new Point(
            //this.ClientSize.Width / 2 - pnlInsertUpdate.Size.Width / 2,
            //this.ClientSize.Height / 2 - pnlInsertUpdate.Size.Height / 2);
            //  pnlInsertUpdate.Visible = false;
            lblBusy.Text = "";

        }

        private void frmPastDue_Load(object sender, EventArgs e)
        {
            dtPastDueAccount = new DataTable();
            btnExecute.Enabled = dtPastDueAccount.Rows.Count > 0 ? true : false;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Please wait, While loading excel file.";
            lblWaitStatus.Text = "Status: Processing...";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlWaitInfo.Visible = true;

                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }
        }

        #region Retrieving records
        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (isNoData)
                {
                    isNoData = false;
                    MetroMessageBox.Show(this, "\r\n\r\nPast Due excel files contains no data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                //if (_InValidDate)
                //{
                //    MetroMessageBox.Show(this, "\r\nInvalid date was detected by the system, Please check all the date format.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //}
                //else
                //{
                //    MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //}
                return;
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                lblWaitStatus.Text = "Status: Error Encountered while processing";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("External table is not in the expected format"))
                {
                    MetroMessageBox.Show(this, "\r\nPlease save first the file with the extension name of \".xls\".\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                    var Modulename = this.GetType().FullName;
                    var methodName = MethodBase.GetCurrentMethod().Name;
                    ErrorLog.GetLogFilePath(e.Error, Modulename, methodName, ErrorID, ErrList);

                    MetroMessageBox.Show(this, "ERROR LogID: " +  ErrorID + "\r\nError Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while reading the files, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else
            {
                pastDueAccountFileName = Path.GetFileName(txtFilePath.Text);

                //dtPastDueAccount.DefaultView.RowFilter = "SYSTEM = 'FAMS' AND statuspersystem = 'PAST DUE'";
                DataView dv = dtPastDueAccount.DefaultView;
                dv.Sort = "SYSTEM asc";
                DataTable sortedDT = dv.ToTable();

                dgvPastDueAccount.DataSource = sortedDT;

                lblInfo.Text = "Total Records: " + string.Format("{0:n0}", dtPastDueAccount.Rows.Count);

                pnlWaitInfo.Visible = false;
                btnExecute.Enabled = dtPastDueAccount.Rows.Count > 0 ? true : false;
            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string connString = "";

                if (Path.GetExtension(txtFilePath.Text) == ".xls")
                    connString = string.Format("Provider = Microsoft.Jet.OLEDB.4.0;Data Source={0};" + "Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);

                if (Path.GetExtension(txtFilePath.Text) == ".xlsx")
                {
                    // connString = string.Format("Provider = Microsoft.ACE.OLEDB.12.0;Data Source={0};" + "Extended Properties='Excel 12.0 Xml;HDR=NO;IMEX=1;'", txtFilePath.Text);

                    MetroMessageBox.Show(this, "\r\nPlease change the file format from XLSX to XLS.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                // string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();


                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM[" + worksheetname + "] WHERE [F1] <> ''", conn);


                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);



                    if (dtold.Rows.Count <= 0)
                    {
                        if (retrieveWorker.IsBusy)
                        {
                            isNoData = true;
                            e.Cancel = true;
                            retrieveWorker.CancelAsync();
                        }
                    }
                    else
                    {
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);

                        progressArray[0] = (1 * 100 / dtold.Rows.Count).ToString(); // percent
                        progressArray[1] = "Loading records, Please wait..."; //header text
                        progressArray[2] = "Status: In-progress"; //Status
                        progressArray[3] = "";// i.ToString(); //column
                        progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                        retrieveWorker.ReportProgress(1 * 100 / dtold.Rows.Count, progressArray); // wla lng, just to show the loading information

                        foreach (DataColumn dc in dtold.Columns)
                        {
                            var name = dtold.Rows[0][dc].ToString().Trim().ToUpper();
                           // var newname = Regex.Replace(name, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToUpper();
                            dc.ColumnName = name;
                        }



                        //var NewHeader = Regex.Replace(headercolumn, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToLower();

                        //dtIcbs.Columns.Add(NewHeader);

                        dtold.Rows.RemoveAt(0);

                        dtPastDueAccount = dtold;


                        var invalidExcel = false;
                        var requiredColumns = new HashSet<string>
                        {
                           #region Column Name For NTC
                            "SYSTEM",
                            "ACCOUNT NO",
                            "CLIENT NAME",
                            "AO",
                            "FACILITY CODE",
                            "STATUS PER SYSTEM",
                            "VALUE DATE",
                            "FIRST DUE DATE",
                            "MATURITY DATE",
                            "TOTAL LOAN",
                            "OB",
                            "MONTHLY OB",
                            "UDI BALANCE",
                            "CLIENTS EQUITY",
                            "ACCRUED INTEREST RECEIVABLE",
                            "ORIG ERV",
                            "PVRV",
                            "PVGD",
                            "ORIG GD",
                            "TOTAL LOAN PORTFOLIO",
                            "NTC",
                            "ORIGINAL RATE",
                            "CURRENT RATE",
                            "TERM IN MONTHS",
                            "REMAINING TERM IN MONTHS",
                            "ORIGINAL AMORTIZATION AAF",
                            "PAYMENT SCHEDULE AMORTIZATION AAF",
                            "REPRICED DATE",
                            "AAFICBSRATE TYPE",
                            "REPRICED AMORTIZATION",
                            "PAST DUE DATE ITLDATE EXTRACTED PER AAFICBS",
                            "PER FAMS AAF ICBS INDUSTRY CODE",
                            "INDUSTRY HEADER",
                            "INDUSTRY DETAIL",
                            "COLLATERAL",
                            "PER FAMS AAF ICBS ASSET SIZE",
                            "PER FAMS AAF ICBS ASSET SIZE IN WORDS",
                            "ICBS GLCODE",
                            "ICBS GLNAME",
                            "COST CENTER",
                            "BRANCH NAME OF COST CENTER PER SYSTEM",
                            "STATUS PER GL",
                            "ORIGINATING BRANCH BOOKED",
                            "NATIONALITY PER ICBS",
                            "NEXT RATE REVIEW DATE EXTRACTED PER FAMS AAF ICBS",
                            "TAX ID",
                            "LOAN PURPOSE CODE",
                            "MATURITY TYPE CODE",
                            "BANK RELATIONSHIP",
                            "SYNDICATED LOAN IND",
                            "CUSTOMER TYPE DESCRIPTION",
                            "REL CODE",
                            "REE CODE",
                            "REE ADDTL INFO",
                            "ACCT REF",
                            "RPT",
                            "ASSET COST",
                            "LEASE TYPE",
                            "PROVISIONING",
                            "MATRIX",
                            "REMARKS",
                            "ICBS COLLATERAL CODE",
                            "ASSET VALUE",
                            "APPROVED AMOUNT",
                            "CP NUMBER",
                            "LAST PRINCIPAL PAY",
                            "PRINCIPAL PAY DATE",
                            "LAST INTEREST PAY",
                            "LAST INTEREST PAY DATE",
                            "PREVIOUS MONTHS NPL TAGGING BY RISK",
                            "SPECIFIC REQUIRED PROVISIONS",
                            "GENERAL REQUIRED PROVISIONS"

	#endregion
                        };
                        for (int i = 0; i < dtold.Columns.Count; i++)
                        {
                            string colname = dtold.Columns[i].ColumnName;
                            if (!requiredColumns.Contains(colname.Trim()))
                            {
                                invalidExcel = true;
                                //Console.WriteLine("Unknown column [{0}]", colname);
                            }
                        }
                        if (invalidExcel)
                        {
                            throw new Exception("does not belong to table");
                        }


                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Save PastDue
        private void btnExecute_Click(object sender, EventArgs e)
        {


            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Saving records, Please wait...";
            lblWaitStatus.Text = "Status: In-progress...";

            //Get Date
            dateparam = pastDueAccountRepository.GetDate();

            if (pastDueAccountRepository.GetRecord())
            {
                saveWorker = new BackgroundWorker();
                saveWorker.WorkerReportsProgress = true;
                saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
                saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
                saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
                saveWorker.WorkerSupportsCancellation = true;
                saveWorker.RunWorkerAsync();
            }
            else
            {
                MetroMessageBox.Show(this, "\r\n\r\nPlease consolidate the record first, before you procceed this proccess.", "Invalid Process", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                var iCount = 1;
                foreach (DataRow dritem in dtPastDueAccount.Rows)
                {
                    BDOLF_Consolidator data = new BDOLF_Consolidator();

                    // var _System = dritem["SYSTEM"].ToString();

                    //if (dritem["SYSTEM"].ToString().Trim() == "FAMS" && dritem["STATUSPERSYSTEM"].ToString().Trim() == "PAST DUE")
                    //{
                    #region Data
                    progressArray[0] = (iCount * 100 / dtPastDueAccount.Rows.Count).ToString(); // percent
                    progressArray[1] = "Saving records, Please wait..."; //header text
                    progressArray[2] = "Status: In-progress"; //Status
                    progressArray[3] = "";// i.ToString(); //column
                    progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                    data.RawFiles = pastDueAccountFileName.ToString();
                    data.isConsolidated = true;
                    data.isDeleted = false;
                    data.UserName = frmConsolidator.UserName;
                    data.TransDate = DateTime.Today;
                    data.RecordDate = dateparam; // Convert.ToDateTime(dritem["VALUEDATE"] == null ? "" : dritem["VALUEDATE"]);
                    data.SYSTEM = dritem["SYSTEM"] == null ? "" : dritem["SYSTEM"].ToString();
                    data.AccountNo = dritem["Account No"] == null ? "" : dritem["Account No"].ToString();
                    data.ClientName = dritem["Client Name"] == null ? "" : dritem["Client Name"].ToString();
                    data.AO = dritem["AO"] == null ? "" : dritem["AO"].ToString();
                    data.FacilityCode = dritem["Facility Code"] == null ? "" : dritem["Facility Code"].ToString();
                    data.StatusPerSystem = dritem["Status Per System"] == null ? "" : dritem["Status Per System"].ToString();
                    data.ValueDate = dritem["Value Date"].ToString() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["Value Date"]);

                    data.FirstDueDate = dritem["First Due Date"].ToString() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["First Due Date"]);

                    // data.FirstDueDate = Convert.ToDateTime(dritem["FIRSTDUEDATE"] == null ? "" : dritem["FIRSTDUEDATE"]);
                    data.MaturityDate = dritem["Maturity Date"].ToString() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["Maturity Date"]);
                    data.TotalLoan = dritem["Total Loan"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Total Loan"]);
                    data.OB = dritem["OB"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["OB"]);
                    data.MonthlyOB = dritem["Monthly OB"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Monthly OB"]);
                    data.UDIBalance = dritem["UDI Balance"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["UDI Balance"]);
                    data.ClientsEquity = dritem["Clients Equity"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Clients Equity"]);
                    data.AccruedInterestReceivable = dritem["Accrued Interest Receivable"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Accrued Interest Receivable"]);
                    data.OrigERV = dritem["Orig ERV"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Orig ERV"]);
                    data.PVRV = dritem["PVRV"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["PVRV"]);
                    data.OrigGD = dritem["Orig GD"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Orig GD"]);
                    data.PVGD = dritem["PVGD"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["PVGD"]);
                    data.TotalLoanPortfolio = dritem["Total Loan Portfolio"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Total Loan Portfolio"]);
                    data.NTC = dritem["NTC"] == null ? "" : dritem["NTC"].ToString();
                    data.OriginalRate = dritem["Original Rate"].ToString();
                    data.CurrentRate = dritem["Current Rate"].ToString();
                    data.TermInMonths = dritem["Term in months"].ToString() == "" ? 0 : Convert.ToInt32(dritem["Term in months"]);
                    data.RemainingTermInMonths = dritem["Remaining Term in months"].ToString() == "" ? 0 : Convert.ToInt32(dritem["Remaining Term in months"]);
                    data.OriginalAmortizationAAF = dritem["Original Amortization AAF"].ToString();
                    data.PaymentScheduleAmortizationAAF = dritem["Payment Schedule Amortization AAF"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Payment Schedule Amortization AAF"]);
                    data.RepricedDate = dritem["Repriced Date"].ToString() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["Repriced Date"]);
                    data.AAFICBSRateType = dritem["AAFICBSRate Type"] == null ? "" : dritem["AAFICBSRate Type"].ToString();
                    data.RepricedAmortization = dritem["Repriced Amortization"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Repriced Amortization"]);
                    data.PastDueDateITLDateExtractedPerAAFICBS = dritem["Past Due Date ITLDate Extracted Per AAFICBS"].ToString();
                    data.PerFaMSAAFICBSIndustryCode = dritem["Per FaMS AAF ICBS Industry Code"] == null ? "" : dritem["Per FaMS AAF ICBS Industry Code"].ToString();
                    data.IndustryHeader = dritem["Industry Header"] == null ? "" : dritem["Industry Header"].ToString();
                    data.IndustryDetail = dritem["Industry Detail"] == null ? "" : dritem["Industry Detail"].ToString();
                    data.Collateral = dritem["COLLATERAL"] == null ? "" : dritem["COLLATERAL"].ToString();
                    data.PerFaMSAAFICBSAssetSize = dritem["Per FaMS AAF ICBS Asset Size"] == null ? "" : dritem["Per FaMS AAF ICBS Asset Size"].ToString();
                    data.PerFaMSAAFICBSAssetSizeInWords = dritem["Per FaMS AAF ICBS Asset Size In Words"] == null ? "" : dritem["Per FaMS AAF ICBS Asset Size In Words"].ToString();
                    data.ICBSGLCode = dritem["ICBS GLCode"] == null ? "" : dritem["ICBS GLCode"].ToString();
                    data.ICBSGLName = dritem["ICBS GLName"] == null ? "" : dritem["ICBS GLName"].ToString();
                    data.CostCenter = dritem["Cost Center"] == null ? "" : dritem["Cost Center"].ToString();
                    data.BranchNameOfCostCenterPerSystem = dritem["Branch Name Of Cost Center Per System"] == null ? "" : dritem["Branch Name Of Cost Center Per System"].ToString();
                    data.StatusPerGL = dritem["Status Per GL"] == null ? "" : dritem["Status Per GL"].ToString();
                    data.OriginatingBranchBooked = dritem["Originating Branch Booked"] == null ? "" : dritem["Originating Branch Booked"].ToString();
                    data.NationalityPerICBS = dritem["Nationality Per ICBS"] == null ? "" : dritem["Nationality Per ICBS"].ToString();
                    data.NextRateReviewDateExtractedPerFaMSAAFICBS = dritem["Next Rate Review Date Extracted Per FaMS AAF ICBS"].ToString() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["NEXTRATEREVIEWDATEEXTRACTEDPERFAMSAAFICBS"]);
                    data.TaxID = dritem["TAX ID"] == null ? "" : dritem["TAX ID"].ToString();
                    data.LoanPurposeCode = dritem["Loan Purpose Code"] == null ? "" : dritem["Loan Purpose Code"].ToString();
                    data.MaturityTypeCode = dritem["Maturity Type Code"] == null ? "" : dritem["Maturity Type Code"].ToString();
                    data.BankRelationship = dritem["Bank Relationship"] == null ? "" : dritem["Bank Relationship"].ToString();
                    data.SyndicatedLoanInd = dritem["Syndicated Loan Ind"] == null ? "" : dritem["Syndicated Loan Ind"].ToString();
                    data.CustomerTypeDescription = dritem["Customer Type Description"] == null ? "" : dritem["Customer Type Description"].ToString();
                    data.RELCode = dritem["REL Code"] == null ? "" : dritem["REL Code"].ToString();
                    data.REECode = dritem["REE Code"] == null ? "" : dritem["REE Code"].ToString();
                    data.REEAddtlInfo = dritem["REE Addtl Info"] == null ? "" : dritem["REE Addtl Info"].ToString();
                    data.AcctRef = dritem["Acct Ref"] == null ? "" : dritem["Acct Ref"].ToString();
                    data.RPT = dritem["RPT"] == null ? "" : dritem["RPT"].ToString();
                    data.ASSETCOST = dritem["ASSET COST"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["ASSET COST"]);
                    data.LeaseType = dritem["Lease Type"] == null ? "" : dritem["Lease Type"].ToString();
                    data.Provisioning = dritem["PROVISIONING"] == null ? "" : dritem["PROVISIONING"].ToString();
                    data.Matrix = dritem["MATRIX"] == null ? "" : dritem["MATRIX"].ToString();
                    data.Remarks = dritem["REMARKS"] == null ? "" : dritem["REMARKS"].ToString();
                    data.ICBSCollateralCode = dritem["ICBS Collateral Code"] == null ? "" : dritem["ICBS Collateral Code"].ToString();
                    data.AssetValue = dritem["Asset Value"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Asset Value"]);
                    data.ApprovedAmount = dritem["Approved Amount"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Approved Amount"]);
                    data.CPNumber = dritem["CP Number"] == null ? "" : dritem["CP Number"].ToString();
                    data.LastInterestPay = dritem["Last Principal Pay"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Last Principal Pay"]);
                    data.PrincipalPayDate = dritem["Principal Pay Date"].ToString() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["Principal Pay Date"]);
                    data.LastInterestPay = dritem["Last Interest Pay"].ToString() == "" ? 0M : Convert.ToDecimal(dritem["Last Interest Pay"]);
                    data.LastInterestPayDate = Convert.ToDateTime("01/01/1900");
                    data.PreviousMonthsNPLTaggingByRisk = dritem["Previous Months NPL Tagging By Risk"].ToString() == "" ? "" : dritem["Previous Months NPL Tagging By Risk"].ToString();
                    data.SpecificRequiredProvisions = dritem["Specific Required Provisions"].ToString() == "" ? "" : dritem["Specific Required Provisions"].ToString();
                    data.GeneralRequiredProvisions = dritem["General Required Provisions"].ToString() == "" ? "" : dritem["General Required Provisions"].ToString();
                    data.Reason = "";
                    #endregion

                    pastDueAccountRepository.InsertRecord(data);

                    saveWorker.ReportProgress(iCount++ * 100 / dtPastDueAccount.Rows.Count, progressArray); // wla lng
                    //}
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";


                lblWaitStatus.Text = "Status: Error Encountered while processing";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                    var Modulename = this.GetType().FullName;
                    var methodName = MethodBase.GetCurrentMethod().Name;
                    ErrorLog.GetLogFilePath(e.Error, Modulename, methodName, ErrorID, ErrList);

                    MetroMessageBox.Show(this, "ERROR LogID: " +  ErrorID + "\r\nError Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while saving the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "DONE";
                lblWaitStatus.Text = "Status: Success";

                MetroMessageBox.Show(this, "\r\nPast Due Account was successfully appended.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitStatus.Text = labelsreports[2].ToString();
            lblWaitInfo.Text = labelsreports[1].ToString();
        }
        #endregion

        private void frmPastDue_FormClosing(object sender, FormClosingEventArgs e)
        {
            //frmConsolidator frmreload = new frmConsolidator();
            //frmreload.GetConsolidator();

            frmPastDue.frmpastDue = null;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                var retVal = DownloadExcelTemplate.DownloadTemplate("Past Due Account");

                if (retVal == 1)
                {
                    MetroMessageBox.Show(this, "\r\nPast Due excel Template was successfully downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                var Modulename = this.GetType().FullName;
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID, ErrList);

                MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while downloading the template, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
