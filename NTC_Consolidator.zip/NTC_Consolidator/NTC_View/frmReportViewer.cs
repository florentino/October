﻿using MetroFramework;
using Microsoft.Reporting.WinForms;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmReportViewer : MetroFramework.Forms.MetroForm
    {
        private ICorrespondingGLRepository correspondingGLRepository;
        private IConsolidator consolidatorRepository;
        private IFilePathRepository filePathRepository;
        private IExchangeRate exchangeRate;
        string ErrorID = "";
        List<ReportParameter> parameters = new List<ReportParameter>();

        Array iResult;
        DataTable dtResult = new DataTable();
        string selectedMonth = "";
        string selectedMonthinText = "";
        double totalOB = 0.0;
        double totalGMYBal = 0.0;
        string radioSelected = "";
        double totalUDIBal = 0.0;
        double totalGMYBALUDI = 0.0;
        double totalPVRV = 0.0;
        double totalGMYBALPVRV = 0.0;
        double totalPVGD = 0.0;
        double totalGMYBALPVGD = 0.0;
        double totalGMYACCRUEDINTERESTRECEIVABLE = 0.0;
        double totalACCRUEDINTERESTRECEIVABLE = 0.0;
        double totalGMYCLIENTSEQUITY = 0.0;
        double totalCLIENTSEQUITY = 0.0;
        double ntcGrandTotalGYMBal = 0.0;
        double ntcGrandTotalSum = 0.0;
        double ntcGrandTotalDiff = 0.0;

        double totalDiffOB = 0.0;
        double totalDiffUDI = 0.0;
        double totalDiffPVRV = 0.0;
        double totalDiffPVGD = 0.0;
        double totalDiffACCR = 0.0;
        double totalDiffEQ = 0.0;

        bool isDaily = false;
        bool isMonthly = false;
        bool isYearly = false;

        DataTable dtSource = new DataTable();
        DataTable dtexceptionalReport;
        DataTable dtSumOfOB;
        DataTable dtSumOfUDIBalance;
        DataTable dtSumOfPVRV;
        DataTable dtSumOfPVGD;
        DataTable dtSumOfACCRUEDINTERESTRECEIVABLE;
        DataTable dtSumOfCLIENTEQUITY;

        private static frmReportViewer frmrptviewer = null;
        private string ExportFilename = "";
        private string rptDataSetName = "";
        private string filename = "";
        private string fileDestination = "";
        private string[] rptDataSetNameForSummary = new string[6];

        private string rdlcFile = "";
        private string sheetname = "";
        private string pathfile = "";
        bool IsBusy = false;
        private BackgroundWorker summaryWorker;
        private BackgroundWorker summaryExportWorker;

        string NTC_DateTime;

        public static frmReportViewer Instance()
        {
            if (frmrptviewer == null)
            {
                frmrptviewer = new frmReportViewer();
            }
            return frmrptviewer;
        }

        public frmReportViewer()
        {
            InitializeComponent();
            this.consolidatorRepository = new ConsolidatorRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
            this.filePathRepository = new FilePathRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
            this.exchangeRate = new ExchangeRateRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
            this.correspondingGLRepository = new CorrespondingGLRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));

            pnlWaitInfo.Location = new Point(this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2, this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;
        }

        private void frmReportViewer_Load(object sender, EventArgs e)
        {
            NTC_DateTime = consolidatorRepository.GetDate("AsOfDate"); //

            this.reportViewer1.LocalReport.DataSources.Clear();
            //  rdlcFile = Program.NTC_ReportPath.ToString() + "NTCConsolidatorReport.rdlc";

            InitializedReport();

            rYearly.Checked = true;
            pnlRadio.Enabled = true;
            this.reportViewer1.RefreshReport();
            var firstDayOfMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            cmbDateFrom.Text = firstDayOfMonth.ToShortDateString();
            btnExecute.Enabled = false;
            lblBusy.Text = "";
            btnExport.Enabled = false;
            cmbMonthName.Enabled = false;
            //string[] names = DateTimeFormatInfo.CurrentInfo.MonthNames;

            //// cmbMonthName.DataSource = names.ToList();

            ////cmbMonthName.DataBindings();


            //for (int i = 0; i < names.Length; i++)
            //{
            //    //cmbMonthName
            //    cmbMonthName.Items.Add(names[i]);
            //}


            var items = new[] {
                 new { Value ="0", Text = ""},
                new { Value ="1", Text = "January"},
                new { Value ="2", Text = "February"},
                new { Value ="3", Text = "March"},
                new { Value ="4", Text = "April"},
                new { Value ="5", Text = "May"},
                new { Value ="6", Text = "June"},
                new { Value ="7", Text = "July"},
                new { Value ="8", Text = "August"},
                new { Value ="9", Text = "September"},
                new { Value ="10", Text = "October"},
                new { Value ="11", Text = "November"},
                new { Value ="12", Text = "December"}
            };
            cmbMonthName.DataSource = items;
            cmbMonthName.DisplayMember = "Text";
            cmbMonthName.ValueMember = "Value";


            //var months = DateTimeFormatInfo.InvariantInfo.MonthNames;

            //var sortedMonths = months.Select(x => new { Name = x, Sort = DateTime.ParseExact(x, "MMMM", CultureInfo.InvariantCulture) }).OrderBy(x => x.Sort.Month).Select(x => x.Name).ToArray();

            //cmbMonthName.Items.AddRange(sortedMonths);
            // cmbMonthName.DataBindings();
            //cmbMonthName.DataTextField = "Month";
            //cmbMonthName.DataValueField = "Value";
            //cmbMonthName.DataBind();

        }

        private void InitializedReport()
        {
            pathfile = Program.NTC_ReportPath.ToString() + "NoRecordsFound.rdlc";

            this.reportViewer1.ProcessingMode = ProcessingMode.Local;
            this.reportViewer1.LocalReport.ReportPath = pathfile;

            this.reportViewer1.RefreshReport();
        }


        // public void LoadDataToRDLC(string rptDataSetName, string filename, DataTable dtSource, string fileDestination, string fileFormat, string rdlcFile, string sheetname)
        public void LoadDataToRDLC(string rptDataSetName, DataTable dtSource, string rdlcFile, string sheetname, List<ReportParameter> rParams)
        {
            this.reportViewer1.LocalReport.DataSources.Clear();

            //pathfile = "NTC_Consolidator.Report." + rdlcFile;
            pathfile = rdlcFile;
            //  MessageBox.Show(pathfile);
            ReportDataSource dSource = new ReportDataSource();
            dSource.Name = rptDataSetName;
            dSource.Value = dtSource;

            this.reportViewer1.LocalReport.DisplayName = sheetname;
            this.reportViewer1.ProcessingMode = ProcessingMode.Local;
            this.reportViewer1.LocalReport.DataSources.Add(dSource);
            this.reportViewer1.LocalReport.ReportPath = pathfile;
            this.reportViewer1.LocalReport.SetParameters(rParams);
            this.reportViewer1.RefreshReport();
        }

        public void LoadDataToRDLCForSummary(string rdlcFile, string sheetname, List<ReportParameter> rParams)
        {
            try
            {
                this.reportViewer1.LocalReport.DataSources.Clear();

                pathfile = rdlcFile;

                rptDataSetNameForSummary[0] = "dssummary";
                rptDataSetNameForSummary[1] = "dsSumOfUDIBalance";
                rptDataSetNameForSummary[2] = "dsSumOfPVRV";
                rptDataSetNameForSummary[3] = "dsSumOfPVGD";
                rptDataSetNameForSummary[4] = "dsSumOfAccIntReceievables";
                rptDataSetNameForSummary[5] = "dsSumOfClientEquity";

                ReportDataSource dSOB = new ReportDataSource(rptDataSetNameForSummary[0].ToString(), dtSumOfOB);
                ReportDataSource dSUDIBalance = new ReportDataSource(rptDataSetNameForSummary[1], dtSumOfUDIBalance);
                ReportDataSource dSPVRV = new ReportDataSource(rptDataSetNameForSummary[2], dtSumOfPVRV);
                ReportDataSource dSPVGD = new ReportDataSource(rptDataSetNameForSummary[3], dtSumOfPVGD);
                ReportDataSource dSACCRUEDINTERESTRECEIVABLE = new ReportDataSource(rptDataSetNameForSummary[4], dtSumOfACCRUEDINTERESTRECEIVABLE);
                ReportDataSource dSCLIENTEQUITY = new ReportDataSource(rptDataSetNameForSummary[5], dtSumOfCLIENTEQUITY);


                this.reportViewer1.LocalReport.DisplayName = sheetname;
                this.reportViewer1.ProcessingMode = ProcessingMode.Local;
                this.reportViewer1.LocalReport.DataSources.Add(dSOB);
                this.reportViewer1.LocalReport.DataSources.Add(dSUDIBalance);
                this.reportViewer1.LocalReport.DataSources.Add(dSPVRV);
                this.reportViewer1.LocalReport.DataSources.Add(dSPVGD);
                this.reportViewer1.LocalReport.DataSources.Add(dSACCRUEDINTERESTRECEIVABLE);
                this.reportViewer1.LocalReport.DataSources.Add(dSCLIENTEQUITY);
                this.reportViewer1.LocalReport.ReportPath = pathfile;
                this.reportViewer1.LocalReport.SetParameters(rParams);
                this.reportViewer1.RefreshReport();
            }
            catch (Exception ex)
            {

                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                InitializedReport();
                throw;
            }
        }


        //private void GenerateExcel(string fileDestination, string ExportFilename, string fileFormat)
        //{
        //    Warning[] warnings;
        //    string[] streamids;
        //    string mimeType;
        //    string encoding;
        //    string extension;
        //    byte[] bytes = this.reportViewer1.LocalReport.Render(fileFormat.ToUpper(), "", out mimeType, out encoding, out extension, out streamids, out warnings);
        //    FileStream fs = new FileStream(fileDestination, FileMode.Create);
        //    fs.Write(bytes, 0, bytes.Length);
        //    fs.Close();
        //}

        private DataTable GetBlankIndustryCode()
        {
            dtexceptionalReport = new DataTable();
            dtexceptionalReport.Columns.Add(new DataColumn("SYSTEM"));
            dtexceptionalReport.Columns.Add(new DataColumn("AccountNo"));
            dtexceptionalReport.Columns.Add(new DataColumn("ClientName"));
            dtexceptionalReport.Columns.Add(new DataColumn("AO"));
            dtexceptionalReport.Columns.Add(new DataColumn("PerFaMSAAFICBSIndustryCode"));
            dtexceptionalReport.Columns.Add(new DataColumn("IndustryHeader"));
            dtexceptionalReport.Columns.Add(new DataColumn("IndustryDetail"));

            DataRow dr = null;
            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {
                    //var item = objVal.ObjectToData();

                    dr = dtexceptionalReport.NewRow();
                    dr["AccountNo"] = item["AccountNo"];
                    dr["ClientName"] = item["ClientName"];
                    dr["AO"] = item["AO"];
                    dr["PerFaMSAAFICBSIndustryCode"] = item["PerFaMSAAFICBSIndustryCode"];
                    dr["IndustryHeader"] = item["IndustryHeader"];
                    dr["IndustryDetail"] = item["IndustryDetail"];

                    dtexceptionalReport.Rows.Add(dr);
                }
            }
            return dtexceptionalReport;
        }

        private DataTable GetInvalidDosriTagging()
        {
            dtexceptionalReport = new DataTable();
            dtexceptionalReport.Columns.Add(new DataColumn("AccountNo"));
            dtexceptionalReport.Columns.Add(new DataColumn("ClientName"));
            dtexceptionalReport.Columns.Add(new DataColumn("AO"));
            dtexceptionalReport.Columns.Add(new DataColumn("RPT"));

            DataRow dr = null;
            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {
                    //var item = objVal.ObjectToData();

                    dr = dtexceptionalReport.NewRow();
                    dr["AccountNo"] = item["AccountNo"];
                    dr["ClientName"] = item["ClientName"];
                    dr["AO"] = item["AO"];
                    dr["RPT"] = item["RPT"];

                    dtexceptionalReport.Rows.Add(dr);
                }
            }
            return dtexceptionalReport;
        }

        //private DataTable GetICBSZeroAsset()
        //{
        //    dtexceptionalReport = new DataTable();
        //    dtexceptionalReport.Columns.Add(new DataColumn("PNNUMBER"));
        //    dtexceptionalReport.Columns.Add(new DataColumn("CUSTOMERNAME"));
        //    dtexceptionalReport.Columns.Add(new DataColumn("OFFICERAOCODE"));
        //    dtexceptionalReport.Columns.Add(new DataColumn("SIZEOFFIRM"));

        //    DataRow dr = null;

        //    foreach (var objVal in iResult)
        //    {
        //        var item = objVal.ObjectToData();

        //        dr = dtexceptionalReport.NewRow();
        //        dr["PNNUMBER"] = item.Rows[0]["AccountNo"];
        //        dr["CUSTOMERNAME"] = item.Rows[0]["ClientName"];
        //        dr["OFFICERAOCODE"] = item.Rows[0]["AO"];
        //        dr["SIZEOFFIRM"] = item.Rows[0]["PerFaMSAAFICBSAssetSize"];

        //        dtexceptionalReport.Rows.Add(dr);
        //    }
        //    return dtexceptionalReport;
        //}

        private DataTable GetZeroAsset()
        {
            dtexceptionalReport = new DataTable();
            dtexceptionalReport.Columns.Add(new DataColumn("AccountNo"));
            dtexceptionalReport.Columns.Add(new DataColumn("ClientName"));
            dtexceptionalReport.Columns.Add(new DataColumn("AO"));
            dtexceptionalReport.Columns.Add(new DataColumn("PerFaMSAAFICBSAssetSize"));
            //dtexceptionalReport.Columns.Add(new DataColumn("PerFaMSAAFICBSAssetSizeInWords"));

            DataRow dr = null;

            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {
                    // var item = objVal.ObjectToData();

                    dr = dtexceptionalReport.NewRow();
                    dr["AccountNo"] = item["AccountNo"].ToString();
                    dr["ClientName"] = item["ClientName"].ToString();
                    dr["AO"] = item["AO"].ToString();
                    dr["PerFaMSAAFICBSAssetSize"] = item["PerFaMSAAFICBSAssetSize"].ToString();

                    dtexceptionalReport.Rows.Add(dr);
                }
            }
            return dtexceptionalReport;
        }

        private DataTable GetDiffRiskAndGL()
        {
            dtexceptionalReport = new DataTable();
            dtexceptionalReport.Columns.Add(new DataColumn("System"));
            dtexceptionalReport.Columns.Add(new DataColumn("AccountNo"));
            dtexceptionalReport.Columns.Add(new DataColumn("ClientName"));
            dtexceptionalReport.Columns.Add(new DataColumn("TaggingPerSystem"));
            dtexceptionalReport.Columns.Add(new DataColumn("TaggingByRisk"));

            DataRow dr = null;
            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {
                    //  var item = objVal.ObjectToData();

                    dr = dtexceptionalReport.NewRow();
                    dr["System"] = item["SYSTEM"];
                    dr["AccountNo"] = item["AccountNo"];
                    dr["ClientName"] = item["ClientName"];
                    dr["TaggingPerSystem"] = item["StatusPerSystem"];
                    dr["TaggingByRisk"] = item["PreviousMonthsNPLTaggingByRisk"];

                    dtexceptionalReport.Rows.Add(dr);
                }
            }
            return dtexceptionalReport;
        }

        private DataTable GetSumOfOB()
        {
            dtSumOfOB = new DataTable();
            dtSumOfOB.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfOB.Columns.Add(new DataColumn("AccountNo"));
            dtSumOfOB.Columns.Add(new DataColumn("GMACT"));
            dtSumOfOB.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfOB.Columns.Add(new DataColumn("GMBAL"));
            //dtSumOfOB.Columns.Add(new DataColumn("GMCBAL"));
            //dtSumOfOB.Columns.Add(new DataColumn("GMEMO"));
            dtSumOfOB.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfOB.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfOB.Columns.Add(new DataColumn("OB"));
            dtSumOfOB.Columns.Add(new DataColumn("DIFFERENCE"));
            dtSumOfOB.Columns.Add(new DataColumn("Total"));


            DataRow dr = null;

            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {
                    // var item = objVal.ObjectToData();

                    // var ob = item.Rows[0]["OB"].ToString().Length > 0 ? Convert.ToDouble(item.Rows[0]["OB"]) : 0;

                    dr = dtSumOfOB.NewRow();
                    dr["SYSTEM"] = item["SYSTEM"].ToString();
                    dr["AccountNo"] = "";//item["AccountNo"];
                    dr["Total"] = 0;
                    dr["GMACT"] = item["ICBSGLCODE"];
                    //dr["GMCBAL"] = item["GMCBAL"];
                    //dr["GMEMO"] = item["GMEMO"];
                    //dr["GMBAL"] = item["GMYBAL"];
                    dr["GMNAME"] = item["ICBSGLName"];
                    dr["ICBSGLCODE"] = item["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item["ICBSGLName"];
                    dr["OB"] = Convert.ToDouble(item["OB"]);
                    dr["DIFFERENCE"] = Convert.ToDouble(item["Diff"]);

                    ntcGrandTotalSum += Convert.ToDouble(item["OB"]);
                    totalOB += Convert.ToDouble(item["OB"]);
                    totalDiffOB += Convert.ToDouble(item["Diff"]);

                    #region Old
                    if (radioSelected == "Year End")
                    {
                        dr["GMBAL"] = item["GMYBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMYBAL"]);
                        totalGMYBal += Convert.ToDouble(item["GMYBAL"]);

                    }
                    else if (radioSelected == "Month End")
                    {
                        dr["GMBAL"] = item["GMEMO"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMEMO"]);
                        totalGMYBal += Convert.ToDouble(item["GMEMO"]);
                    }
                    else if (radioSelected == "Daily")
                    {
                        dr["GMBAL"] = item["GMCBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMCBAL"]);
                        totalGMYBal += Convert.ToDouble(item["GMCBAL"]);
                    }

                    #endregion
                    dtSumOfOB.Rows.Add(dr);
                }
            }

            return dtSumOfOB;
        }

        private DataTable GetSumOfUDIBalance()
        {
            dtSumOfUDIBalance = new DataTable();
            dtSumOfUDIBalance.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("GMACT"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("GMBAL"));
            //dtSumOfUDIBalance.Columns.Add(new DataColumn("GMYBAL"));
            //dtSumOfUDIBalance.Columns.Add(new DataColumn("GMCBAL"));
            //dtSumOfUDIBalance.Columns.Add(new DataColumn("GMEMO"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("UDIBalance"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("DIFFERENCE"));

            DataRow dr = null;
            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {

                    dr = dtSumOfUDIBalance.NewRow();

                    dr["SYSTEM"] = item["SYSTEM"];
                    dr["GMACT"] = item["ICBSGLCODE"];
                    dr["GMNAME"] = item["ICBSGLName"];
                    dr["ICBSGLCODE"] = item["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item["ICBSGLName"];
                    dr["UDIBalance"] = Convert.ToDouble(item["UDIBalance"]);
                    dr["DIFFERENCE"] = Convert.ToDouble(item["Diff"]);

                    ntcGrandTotalSum += Convert.ToDouble(item["UDIBalance"]);

                    //dr["GMCBAL"] = item["GMCBAL"];
                    //dr["GMEMO"] = item["GMEMO"];
                    //dr["GMYBAL"] = item["GMYBAL"];

                    ntcGrandTotalSum += Convert.ToDouble(item["UDIBalance"]);
                    totalUDIBal += Convert.ToDouble(item["UDIBalance"]);
                    totalDiffUDI += Convert.ToDouble(item["Diff"]);

                    #region Old
                    if (radioSelected == "Year End")
                    {
                        dr["GMBAL"] = item["GMYBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMYBAL"]);
                        totalGMYBALUDI += Convert.ToDouble(item["GMYBAL"]);
                    }
                    else if (radioSelected == "Month End")
                    {
                        dr["GMBAL"] = item["GMEMO"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMEMO"]);
                        totalGMYBALUDI += Convert.ToDouble(item["GMEMO"]);
                    }
                    else if (radioSelected == "Daily")
                    {
                        dr["GMBAL"] = item["GMCBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMCBAL"]);
                        totalGMYBALUDI += Convert.ToDouble(item["GMCBAL"]);
                    }
                    #endregion

                    dtSumOfUDIBalance.Rows.Add(dr);
                }
            }

            return dtSumOfUDIBalance;
        }

        private DataTable GetSumOfPVRV()
        {
            dtSumOfPVRV = new DataTable();
            dtSumOfPVRV.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfPVRV.Columns.Add(new DataColumn("GMACT"));
            dtSumOfPVRV.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfPVRV.Columns.Add(new DataColumn("GMBAL"));
            //dtSumOfPVRV.Columns.Add(new DataColumn("GMYBAL"));
            //dtSumOfPVRV.Columns.Add(new DataColumn("GMCBAL"));
            //dtSumOfPVRV.Columns.Add(new DataColumn("GMEMO"));
            dtSumOfPVRV.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfPVRV.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfPVRV.Columns.Add(new DataColumn("FACILITYCODE"));
            dtSumOfPVRV.Columns.Add(new DataColumn("PVRV"));
            dtSumOfPVRV.Columns.Add(new DataColumn("DIFFERENCE"));

            DataRow dr = null;
            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {

                    dr = dtSumOfPVRV.NewRow();
                    dr["SYSTEM"] = item["SYSTEM"];
                    dr["GMACT"] = item["ICBSGLCODE"];
                    dr["GMNAME"] = item["ICBSGLName"];
                    dr["ICBSGLCODE"] = item["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item["ICBSGLName"];
                    dr["FACILITYCODE"] = item["FacilityCode"];
                    dr["PVRV"] = Convert.ToDouble(item["PVRV"]);
                    dr["DIFFERENCE"] = Convert.ToDouble(item["Diff"]);
                    //dr["GMCBAL"] = item["GMCBAL"];
                    //dr["GMEMO"] = item["GMEMO"];
                    //dr["GMYBAL"] = item["GMYBAL"];

                    ntcGrandTotalSum += Convert.ToDouble(item["PVRV"]);

                    totalPVRV += Convert.ToDouble(item["PVRV"]);
                    totalDiffPVRV += Convert.ToDouble(item["Diff"]);

                    #region Old
                    if (radioSelected == "Year End")
                    {
                        dr["GMBAL"] = item["GMYBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMYBAL"]);
                        totalGMYBALPVRV += Convert.ToDouble(item["GMYBAL"]);
                    }
                    else if (radioSelected == "Month End")
                    {
                        dr["GMBAL"] = item["GMEMO"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMEMO"]);
                        totalGMYBALPVRV += Convert.ToDouble(item["GMEMO"]);
                    }
                    else if (radioSelected == "Daily")
                    {
                        dr["GMBAL"] = item["GMCBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMCBAL"]);
                        totalGMYBALPVRV += Convert.ToDouble(item["GMCBAL"]);
                    }
                    #endregion

                    dtSumOfPVRV.Rows.Add(dr);
                }
            }


            return dtSumOfPVRV;
        }

        private DataTable GetSumOfPVGD()
        {
            dtSumOfPVGD = new DataTable();
            dtSumOfPVGD.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfPVGD.Columns.Add(new DataColumn("GMACT"));
            dtSumOfPVGD.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfPVGD.Columns.Add(new DataColumn("GMBAL"));
            //dtSumOfPVGD.Columns.Add(new DataColumn("GMYBAL"));
            //dtSumOfPVGD.Columns.Add(new DataColumn("GMCBAL"));
            //dtSumOfPVGD.Columns.Add(new DataColumn("GMEMO"));
            dtSumOfPVGD.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfPVGD.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfPVGD.Columns.Add(new DataColumn("FACILITYCODE"));
            dtSumOfPVGD.Columns.Add(new DataColumn("PVGD"));
            dtSumOfPVGD.Columns.Add(new DataColumn("DIFFERENCE"));

            DataRow dr = null;
            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {

                    dr = dtSumOfPVGD.NewRow();
                    dr["SYSTEM"] = item["SYSTEM"];
                    dr["GMACT"] = item["ICBSGLCODE"];
                    dr["GMNAME"] = item["ICBSGLName"];
                    dr["ICBSGLCODE"] = item["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item["ICBSGLName"];
                    dr["FACILITYCODE"] = item["FacilityCode"];
                    dr["PVGD"] = Convert.ToDouble(item["PVGD"]);
                    dr["DIFFERENCE"] = Convert.ToDouble(item["Diff"]);
                    //dr["GMCBAL"] = item["GMCBAL"];
                    //dr["GMEMO"] = item["GMEMO"];
                    //dr["GMYBAL"] = item["GMYBAL"];

                    ntcGrandTotalSum += Convert.ToDouble(item["PVGD"]);
                    totalPVGD += Convert.ToDouble(item["PVGD"]);
                    totalDiffPVGD += Convert.ToDouble(item["Diff"]);

                    #region Old
                    if (radioSelected == "Year End")
                    {
                        dr["GMBAL"] = item["GMYBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMYBAL"]);
                        totalGMYBALPVGD += Convert.ToDouble(item["GMYBAL"]);
                    }
                    else if (radioSelected == "Month End")
                    {
                        dr["GMBAL"] = item["GMEMO"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMEMO"]);
                        totalGMYBALPVGD += Convert.ToDouble(item["GMEMO"]);
                    }
                    else if (radioSelected == "Daily")
                    {
                        dr["GMBAL"] = item["GMCBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMCBAL"]);
                        totalGMYBALPVGD += Convert.ToDouble(item["GMCBAL"]);
                    }
                    #endregion

                    dtSumOfPVGD.Rows.Add(dr);
                }
            }

            return dtSumOfPVGD;
        }

        private DataTable GetSumOfACCRUEDINTERESTRECEIVABLE()
        {
            dtSumOfACCRUEDINTERESTRECEIVABLE = new DataTable();
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("GMACT"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("GMBAL"));
            //dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("GMYBAL"));
            //dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("GMCBAL"));
            //dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("GMEMO"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("AccruedInterestReceivable"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("DIFFERENCE"));

            DataRow dr = null;
            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {

                    dr = dtSumOfACCRUEDINTERESTRECEIVABLE.NewRow();
                    dr["SYSTEM"] = item["SYSTEM"];
                    dr["GMACT"] = item["ICBSGLCODE"];
                    dr["GMNAME"] = item["ICBSGLName"];
                    dr["ICBSGLCODE"] = item["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item["ICBSGLName"];
                    dr["AccruedInterestReceivable"] = Convert.ToDouble(item["AccruedInterestReceivable"]);
                    dr["DIFFERENCE"] = Convert.ToDouble(item["Diff"]);
                    //dr["GMCBAL"] = item["GMCBAL"];
                    //dr["GMEMO"] = item["GMEMO"];
                    //dr["GMYBAL"] = item["GMYBAL"];

                    ntcGrandTotalSum += Convert.ToDouble(item["AccruedInterestReceivable"]);
                    totalACCRUEDINTERESTRECEIVABLE += Convert.ToDouble(item["AccruedInterestReceivable"]);
                    totalDiffACCR += Convert.ToDouble(item["Diff"]);

                    #region Old
                    if (radioSelected == "Year End")
                    {
                        dr["GMBAL"] = item["GMYBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMYBAL"]);
                        totalGMYACCRUEDINTERESTRECEIVABLE += Convert.ToDouble(item["GMYBAL"]);
                    }
                    else if (radioSelected == "Month End")
                    {
                        dr["GMBAL"] = item["GMEMO"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMEMO"]);
                        totalGMYACCRUEDINTERESTRECEIVABLE += Convert.ToDouble(item["GMEMO"]);
                    }
                    else if (radioSelected == "Daily")
                    {
                        dr["GMBAL"] = item["GMCBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMCBAL"]);
                        totalGMYACCRUEDINTERESTRECEIVABLE += Convert.ToDouble(item["GMCBAL"]);
                    }
                    #endregion

                    dtSumOfACCRUEDINTERESTRECEIVABLE.Rows.Add(dr);
                }
            }

            return dtSumOfACCRUEDINTERESTRECEIVABLE;
        }

        private DataTable GetSumOfCLIENTEQUITY()
        {
            dtSumOfCLIENTEQUITY = new DataTable();
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("GMACT"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("GMBAL"));
            //dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("GMYBAL"));
            //dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("GMCBAL"));
            //dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("GMEMO"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("ClientsEquity"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("DIFFERENCE"));

            DataRow dr = null;
            if (dtResult.Rows.Count > 0)
            {
                foreach (DataRow item in dtResult.Rows)
                {
                    dr = dtSumOfCLIENTEQUITY.NewRow();
                    dr["SYSTEM"] = item["SYSTEM"];
                    dr["GMACT"] = item["ICBSGLCODE"];
                    dr["GMNAME"] = item["ICBSGLName"];
                    dr["ICBSGLCODE"] = item["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item["ICBSGLName"];
                    dr["ClientsEquity"] = Convert.ToDouble(item["ClientsEquity"]);
                    dr["DIFFERENCE"] = Convert.ToDouble(item["Diff"]);
                    //dr["GMCBAL"] = item["GMCBAL"];
                    //dr["GMEMO"] = item["GMEMO"];
                    //dr["GMYBAL"] = item["GMYBAL"];

                    ntcGrandTotalSum += Convert.ToDouble(item["ClientsEquity"]);
                    totalCLIENTSEQUITY += Convert.ToDouble(item["ClientsEquity"]);
                    totalDiffEQ += Convert.ToDouble(item["Diff"]);

                    #region Old
                    if (radioSelected == "Year End")
                    {
                        dr["GMBAL"] = item["GMYBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMYBAL"]);
                        totalGMYCLIENTSEQUITY += Convert.ToDouble(item["GMYBAL"]);
                    }
                    else if (radioSelected == "Month End")
                    {
                        dr["GMBAL"] = item["GMEMO"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMEMO"]);
                        totalGMYCLIENTSEQUITY += Convert.ToDouble(item["GMEMO"]);
                    }
                    else if (radioSelected == "Daily")
                    {
                        dr["GMBAL"] = item["GMCBAL"];
                        ntcGrandTotalGYMBal += Convert.ToDouble(item["GMCBAL"]);
                        totalGMYCLIENTSEQUITY += Convert.ToDouble(item["GMCBAL"]);
                    }
                    #endregion

                    dtSumOfCLIENTEQUITY.Rows.Add(dr);
                }
            }

            return dtSumOfCLIENTEQUITY;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            ClearAmount();

            if (txtRptName.Text == "Summary Report")
            {

                DialogResult diag = MetroMessageBox.Show(this, "\r\nYou're about to proccess NTC Summary Report for \"" + radioSelected + "\"\r\nAre you sure you want to continue proccess?", "Summary Report", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (diag == DialogResult.No)
                {
                    return;
                }
            }

            if (!IsBusy)
            {
                isYearly = true;
                pnlWaitInfo.Visible = true;
                lblWaitInfo.Text = "Fetching records, Please wait...";
                lblWaitStatus.Text = "Status: In-progress...";
                dtexceptionalReport = new DataTable();

                ntcGrandTotalGYMBal = 0.0;
                ntcGrandTotalSum = 0.0;
                ntcGrandTotalDiff = 0.0;

                summaryWorker = new BackgroundWorker();
                summaryWorker.WorkerReportsProgress = true;
                summaryWorker.DoWork += new DoWorkEventHandler(summaryWorker_DoWork);
                summaryWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(summaryWorker_RunWorkerCompleted);
                summaryWorker.ProgressChanged += new ProgressChangedEventHandler(summaryWorker_ProgressChanged);
                summaryWorker.WorkerSupportsCancellation = true;
                summaryWorker.RunWorkerAsync();
            }
            else
            {
                lblBusy.Text = "Busy processing, Please wait...";
            }
        }

        private void ClearAmount()
        {
            totalOB = 0.0;
            totalGMYBal = 0.0;
            totalUDIBal = 0.0;
            totalGMYBALUDI = 0.0;
            totalPVRV = 0.0;
            totalGMYBALPVRV = 0.0;
            totalPVGD = 0.0;
            totalGMYBALPVGD = 0.0;
            totalGMYACCRUEDINTERESTRECEIVABLE = 0.0;
            totalACCRUEDINTERESTRECEIVABLE = 0.0;
            totalGMYCLIENTSEQUITY = 0.0;
            totalCLIENTSEQUITY = 0.0;
            ntcGrandTotalGYMBal = 0.0;
            ntcGrandTotalSum = 0.0;
            ntcGrandTotalDiff = 0.0;
            totalDiffOB = 0.0;
            totalDiffUDI = 0.0;
            totalDiffPVRV = 0.0;
            totalDiffPVGD = 0.0;
            totalDiffACCR = 0.0;
            totalDiffEQ = 0.0;
        }

        private void DisplayData(List<ReportParameter> _parameters, string _rptDataSetName, string[] _rptDataSetNameForSummary)
        {
            if (filename == "NTC Summary Report")
            {
                LoadDataToRDLCForSummary(rdlcFile, sheetname, _parameters);
            }
            else
            {
                LoadDataToRDLC(rptDataSetName, dtexceptionalReport, rdlcFile, sheetname, _parameters);
            }
        }

        private void summaryWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            IsBusy = true;
            parameters = new List<ReportParameter>();
            try
            {
                var firstDayOfMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
                // cmbDateFrom.Text = firstDayOfMonth.ToShortDateString();
                var parameter = DateTime.Today;
                var frmdate = firstDayOfMonth.ToShortDateString();
                var todate = DateTime.Today.ToShortDateString();

                switch (txtRptName.Text.Trim().ToLower())
                {
                    #region NTCReport
                    case "consolidator":

                        if (selectedMonth == "0" || selectedMonth == "")
                        {
                            if (summaryWorker.IsBusy)
                            {
                                e.Cancel = true;
                                summaryWorker.CancelAsync();
                                return;
                            }
                        }

                        parameters.Add(new ReportParameter("paramDateFrom", selectedMonthinText));

                        dtexceptionalReport = consolidatorRepository.GetAll("", selectedMonth, true).ToDataTable();
                        rptDataSetName = "dsConsolidator";
                        filename = "NTC Consolidated File";
                        rdlcFile = Program.NTC_ReportPath.ToString() + "NTCConsolidatorReport.rdlc";
                        // MessageBox.Show(rdlcFile);
                        sheetname = "NTC Consolidated Report";

                        //dtexceptionalReport = ToDataTableFromArray(iResult);
                        break;
                    //case "corresponding gl":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsCorrespondingGL";
                    //    filename = "NTC Corresponding GL";
                    //    rdlcFile = "CorrespondingGL.rdlc";
                    //    sheetname = "NTC Corresponding GL";
                    //    break;
                    //case "daily gl":
                    //    // iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsDailyGL";
                    //    filename = "NTC Daily GL";
                    //    rdlcFile = "DailyGL.rdlc";
                    //    sheetname = "NTC Corresponding GL";
                    //    break;
                    //case "exchange rate":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsExchangeRate";
                    //    filename = "NTC Exchange Rate";
                    //    rdlcFile = "ExchangeRate.rdlc";
                    //    sheetname = "NTC Exchange Rate";
                    //    break;
                    //case "migrated account":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsMigratedAccount";
                    //    filename = "NTC Migrated Account";
                    //    rdlcFile = "MigratedAccount.rdlc";
                    //    sheetname = "NTC Migrated Account";
                    //    break;
                    //case "past due":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsPastDue";
                    //    filename = "NTC Past Due";
                    //    rdlcFile = "PastDue.rdlc";
                    //    sheetname = "NTC Past Due";
                    //    break;
                    //case "qualifying capital":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsQualifyingCapital";
                    //    filename = "NTC Qualifying Capital";
                    //    rdlcFile = "QualifyingCapitalReport.rdlc";
                    //    sheetname = "NTC Qualifying Capital";
                    //    break;
                    //case "under litigation":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsUnderLitigation";
                    //    filename = "NTC Under Litigation";
                    //    rdlcFile = "UnderLitigation.rdlc";
                    //    sheetname = "NTC Under Litigation";
                    //    break;
                    #endregion

                    #region Exceptional Report
                    #region ICBS
                    case "icbs - blank industry code":

                        
                        todate = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month)).ToShortDateString();


                        parameters.Add(new ReportParameter("paramDateFrom", frmdate));
                        parameters.Add(new ReportParameter("paramDateTo", todate));
                        dtResult = new DataTable();
                        dtResult = consolidatorRepository.ExceptionReportBlankIndustryCode(Convert.ToDateTime(frmdate).ToShortDateString(), Convert.ToDateTime(todate).ToShortDateString(), "ICBS");
                        GetBlankIndustryCode();
                        rptDataSetName = "dsicbsblankindustrycode";
                        filename = "NTC ICBS - Blank Industry Code";
                        rdlcFile = Program.NTC_ReportPath + "Icbsblankindustrycode.rdlc";
                        sheetname = "ICBS - Blank Industry Code";
                        break;
                    case "icbs - zero asset size":
                        
                        todate = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month)).ToShortDateString();

                        parameters.Add(new ReportParameter("paramDateFrom", frmdate));
                        parameters.Add(new ReportParameter("paramDateTo", todate));
                        dtResult = new DataTable();
                        dtResult = consolidatorRepository.ExceptionReportZeroAssetSize(Convert.ToDateTime(frmdate).ToShortDateString(), Convert.ToDateTime(todate).ToShortDateString(), "ICBS");
                        //GetICBSZeroAsset();
                        GetZeroAsset();
                        rptDataSetName = "dsicbszeroassetsize";
                        filename = "NTC ICBS - zero asset size";
                        rdlcFile = Program.NTC_ReportPath + "Icbszeroassetsize.rdlc";
                        sheetname = "ICBS - zero asset size";
                        break;
                    case "icbs - dosri tagging":
                        todate = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month)).ToShortDateString();
                        parameters.Add(new ReportParameter("paramDateFrom", frmdate));
                        parameters.Add(new ReportParameter("paramDateTo", todate));
                        dtResult = new DataTable();
                        dtResult = consolidatorRepository.ExceptionReportDosriTagging(Convert.ToDateTime(frmdate).ToShortDateString(), Convert.ToDateTime(todate).ToShortDateString(), "ICBS");
                        GetInvalidDosriTagging();
                        rptDataSetName = "dsicbsdosritagging";
                        filename = "NTC ICBS - dosri tagging";
                        rdlcFile = Program.NTC_ReportPath + "Icbsdosritagging.rdlc";
                        sheetname = "ICBS - Dosri Tagging";
                        break;
                    #endregion
                    #region AAF
                    case "aaf - blank industry code":
                        todate = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month)).ToShortDateString();
                        parameters.Add(new ReportParameter("paramDateFrom", frmdate));
                        parameters.Add(new ReportParameter("paramDateTo", todate));
                        dtResult = new DataTable();
                        dtResult = consolidatorRepository.ExceptionReportBlankIndustryCode(Convert.ToDateTime(frmdate).ToShortDateString(), Convert.ToDateTime(todate).ToShortDateString(), "AAF");
                        GetBlankIndustryCode();
                        filename = "NTC AAF - blank industry code";
                        rdlcFile = Program.NTC_ReportPath + "Aafblankindustrycode.rdlc";
                        sheetname = "AAF - blank industry code";
                        rptDataSetName = "dsBlankIndustryCode";
                        break;
                    case "aaf - zero asset size":
                        todate = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month)).ToShortDateString();
                        parameters.Add(new ReportParameter("paramDateFrom", frmdate));
                        parameters.Add(new ReportParameter("paramDateTo", todate));
                        dtResult = new DataTable();
                        dtResult = consolidatorRepository.ExceptionReportZeroAssetSize(Convert.ToDateTime(frmdate).ToShortDateString(), Convert.ToDateTime(todate).ToShortDateString(), "AAF");
                        GetZeroAsset();
                        rptDataSetName = "dsaafzeroassetsize";
                        filename = "NTC AAF - zero asset size";
                        rdlcFile = Program.NTC_ReportPath + "Aafzeroassetsize.rdlc";
                        sheetname = "AAF - zero asset size";
                        break;
                    //case "aaf - dosri tagging":
                    //    parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                    //    parameters.Add(new ReportParameter("paramDateTo", cmbDateTo.Text));
                    //    iResult = consolidatorRepository.ExceptionReportDosriTagging(frmdate, todate, "AAF");
                    //    GetInvalidDosriTagging();
                    //    rptDataSetName = "dsInvalidDosriTagging";
                    //    filename = "NTC AAF - dosri tagging";
                    //    rdlcFile = rdlcFile = Program.NTC_ReportPath +  "Aafdosritagging.rdlc";
                    //    sheetname = "AAF - dosri tagging";
                    //    break; 
                    #endregion
                    case "difference in tagging of risk and gl":
                        todate = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month)).ToShortDateString();
                        parameters.Add(new ReportParameter("paramDateFrom", frmdate));
                        parameters.Add(new ReportParameter("paramDateTo", todate));
                        dtResult = new DataTable();
                        dtResult = consolidatorRepository.ExceptionReportDifferenceInTaggingOfRriskAndGL(Convert.ToDateTime(frmdate).ToShortDateString(), Convert.ToDateTime(todate).ToShortDateString(), "AAF");
                        GetDiffRiskAndGL();
                        rptDataSetName = "dsdifferenceintaggingofriskandgl";
                        filename = "NTC Difference in tagging of risk and gl";
                        rdlcFile = Program.NTC_ReportPath + "Differenceintaggingofriskandgl.rdlc";
                        sheetname = "Difference In Tagging of Risk and GL";
                        break;
                    case "summary report":
                        frmdate = firstDayOfMonth.ToShortDateString();
                        todate = DateTime.Today.ToShortDateString();
                        var gmbal = "";
                        if (radioSelected == "Daily")
                        {
                            frmdate = DateTime.Today.ToShortDateString();
                            todate = DateTime.Now.ToShortDateString();
                            gmbal = "GMCBal";
                        }
                        else if (radioSelected == "Month End")
                        {
                            //frmdate = DateTime.Now.ToShortDateString();
                            //todate = DateTime.Today.ToShortDateString();

                          
                            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

                            int year = DateTime.Now.Year;
                            int month = DateTime.Now.Month;
                            int day = DateTime.Now.Day;
                            gmbal = "GMEMO";
                            frmdate = new DateTime(year, month, 1).ToShortDateString();
                            todate = lastDayOfMonth.ToShortDateString();
                        }
                        else if (radioSelected == "Year End")
                        {
                            int year = DateTime.Now.Year;
                            // int month = DateTime.Now.Month;
                            // int day = DateTime.Now.Day;
                            gmbal = "GMYBal";
                            frmdate = new DateTime(year, 1, 1).ToShortDateString();
                            todate = new DateTime(year, 12, 31).ToShortDateString();
                        }


                       
                        parameters.Add(new ReportParameter("paramDateFrom", frmdate));
                        parameters.Add(new ReportParameter("paramDateTo", todate));
                        //iResult = null;
                        dtResult = consolidatorRepository.ExceptionReportSummaryReportSumOfOB(Convert.ToDateTime(frmdate), Convert.ToDateTime(todate), "AAF", radioSelected);
                        GetSumOfOB();
                        parameters.Add(new ReportParameter("totalGMYBal", totalGMYBal.ToString()));
                        parameters.Add(new ReportParameter("totalOB", totalOB.ToString()));
                        parameters.Add(new ReportParameter("totalDiffOB", totalDiffOB.ToString()));
                        dtResult = consolidatorRepository.ExceptionReportSummaryReportSumOfUDIBalance(Convert.ToDateTime(frmdate), Convert.ToDateTime(todate), "AAF", radioSelected);
                        GetSumOfUDIBalance();
                        parameters.Add(new ReportParameter("totalUDIBal", totalUDIBal.ToString()));
                        parameters.Add(new ReportParameter("totalGMYBALUDI", totalGMYBALUDI.ToString()));
                        parameters.Add(new ReportParameter("totalDiffUDI", totalDiffUDI.ToString()));
                        //iResult = null;
                        dtResult = consolidatorRepository.ExceptionReportSummaryReportSumOfPVRV(Convert.ToDateTime(frmdate), Convert.ToDateTime(todate), "AAF", radioSelected);
                        GetSumOfPVRV();
                        parameters.Add(new ReportParameter("totalPVRV", totalPVRV.ToString()));
                        parameters.Add(new ReportParameter("totalGMYBALPVRV", totalGMYBALPVRV.ToString()));
                        parameters.Add(new ReportParameter("totalDiffPVRV", totalDiffPVRV.ToString()));
                        //iResult = null;
                        dtResult = consolidatorRepository.ExceptionReportSummaryReportSumOfPVGD(Convert.ToDateTime(frmdate), Convert.ToDateTime(todate), "AAF", radioSelected);
                        GetSumOfPVGD();
                        parameters.Add(new ReportParameter("totalPVGD", totalPVGD.ToString()));
                        parameters.Add(new ReportParameter("totalGMYBALPVGD", totalGMYBALPVGD.ToString()));
                        parameters.Add(new ReportParameter("totalDiffPVGD", totalDiffPVGD.ToString()));
                        //iResult = null;
                        dtResult = consolidatorRepository.ExceptionReportSummaryReportSumOfACCRUEDINTERESTRECEIVABLE(Convert.ToDateTime(frmdate), Convert.ToDateTime(todate), "AAF", radioSelected);
                        GetSumOfACCRUEDINTERESTRECEIVABLE();
                        parameters.Add(new ReportParameter("totalGMYACCRUEDINTERESTRECEIVABLE", totalGMYACCRUEDINTERESTRECEIVABLE.ToString()));
                        parameters.Add(new ReportParameter("totalACCRUEDINTERESTRECEIVABLE", totalACCRUEDINTERESTRECEIVABLE.ToString()));
                        parameters.Add(new ReportParameter("totalDiffACCR", totalDiffACCR.ToString()));
                        //iResult = null;
                        dtResult = consolidatorRepository.ExceptionReportSummaryReportSumOfCLIENTEQUITY(Convert.ToDateTime(frmdate), Convert.ToDateTime(todate), "FAMS", radioSelected);
                        GetSumOfCLIENTEQUITY();
                        parameters.Add(new ReportParameter("totalGMYCLIENTSEQUITY", totalGMYCLIENTSEQUITY.ToString()));
                        parameters.Add(new ReportParameter("totalCLIENTSEQUITY", totalCLIENTSEQUITY.ToString()));
                        parameters.Add(new ReportParameter("totalDiffEQ", totalDiffEQ.ToString()));

                        ntcGrandTotalGYMBal = totalGMYBal + totalGMYBALUDI + totalGMYBALPVRV + totalGMYBALPVRV + totalGMYACCRUEDINTERESTRECEIVABLE + totalGMYCLIENTSEQUITY;
                        ntcGrandTotalSum = totalCLIENTSEQUITY + totalACCRUEDINTERESTRECEIVABLE + totalPVGD + totalPVRV + totalUDIBal + totalOB;
                        ntcGrandTotalDiff = ntcGrandTotalGYMBal - ntcGrandTotalSum;

                        parameters.Add(new ReportParameter("ntcGrandTotalGYMBal", ntcGrandTotalGYMBal.ToString()));
                        parameters.Add(new ReportParameter("ntcGrandTotalSum", ntcGrandTotalSum.ToString()));
                        parameters.Add(new ReportParameter("ntcGrandTotalDiff", ntcGrandTotalDiff.ToString()));
                        parameters.Add(new ReportParameter("ntcGrandTotalDiff", ntcGrandTotalDiff.ToString()));
                        parameters.Add(new ReportParameter("SelectedRadio", gmbal));

                        rptDataSetNameForSummary[0] = "dssummary";
                        rptDataSetNameForSummary[1] = "dsSumOfUDIBalance";
                        rptDataSetNameForSummary[2] = "dsSumOfPVRV";
                        rptDataSetNameForSummary[3] = "dsSumOfPVGD";
                        rptDataSetNameForSummary[4] = "dsSumOfAccIntReceievables";
                        rptDataSetNameForSummary[5] = "dsSumOfClientEquity";
                        filename = "NTC Summary Report";
                        rdlcFile = Program.NTC_ReportPath + "SummaryReport.rdlc";
                        sheetname = "Summary Report";
                        break;
                        #endregion
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void summaryWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Fetching Data from server, Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void summaryWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

            IsBusy = false;
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                MetroMessageBox.Show(this, "\r\nInvalid Month Name, Please select Month Name in the Dropdown Box.", "Invalid Month Name", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                lblWaitStatus.Text = "Status: Error Encountered while processing";
                ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                var Modulename = this.GetType().FullName;
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(e.Error, Modulename, methodName, ErrorID);

                MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while loading the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
                DisplayData(parameters, rptDataSetName, rptDataSetNameForSummary);
                lblBusy.Text = "";
                btnExport.Enabled = true;
                pnlWaitInfo.Visible = false;
            }
        }

        private void frmReportViewer_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmReportViewer.frmrptviewer = null;
        }

        private void miniToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void consolidatorToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(consolidatorToolStripMenuItem.Text);
        }

        private void correspondingGLToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(correspondingGLToolStripMenuItem.Text);
        }

        private void rptHover(string rptname)
        {
            txtRptName.Text = rptname;
        }

        private void dailyGLToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(dailyGLToolStripMenuItem.Text);
        }

        private void exchangeRateToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(exchangeRateToolStripMenuItem.Text);
        }

        private void migratedAccountToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(migratedAccountToolStripMenuItem.Text);
        }

        private void pastDueToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(pastDueToolStripMenuItem.Text);
        }

        private void qualifyingCapitalToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(qualifyingCapitalToolStripMenuItem.Text);
        }

        private void underLitigationToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(underLitigationToolStripMenuItem.Text);
        }

        private void summaryReportToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(summaryReportToolStripMenuItem.Text);
        }

        private void aAFBlankIndustryCodeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(aAFBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void aAFDOSRITAGGINGToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(aAFDOSRITAGGINGToolStripMenuItem.Text);
        }

        private void aAFZeroAssetSizeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(aAFZeroAssetSizeToolStripMenuItem.Text);
        }

        private void iCBSBlankIndustryCodeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(iCBSBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void iCBSDOSRITaggingToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(iCBSDOSRITaggingToolStripMenuItem.Text);
        }

        private void iCBSZeroAssetSizeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(iCBSZeroAssetSizeToolStripMenuItem.Text);
        }

        private void differenceInTaggingOfRiskAndGLToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(differenceInTaggingOfRiskAndGLToolStripMenuItem.Text);
        }

        private void consolidatorToolStripMenuItem_MouseMove(object sender, MouseEventArgs e)
        {
            rptHover(consolidatorToolStripMenuItem.Text);
        }

        private void correspondingGLToolStripMenuItem_MouseMove(object sender, MouseEventArgs e)
        {
            rptHover(correspondingGLToolStripMenuItem.Text);
        }

        private void consolidatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //panel1.Enabled = false;
            rptHover(consolidatorToolStripMenuItem.Text);
        }

        private void correspondingGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(correspondingGLToolStripMenuItem.Text);
        }

        private void dailyGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(dailyGLToolStripMenuItem.Text);
        }

        private void exchangeRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //   panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(exchangeRateToolStripMenuItem.Text);
        }

        private void migratedAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //   panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(migratedAccountToolStripMenuItem.Text);
        }

        private void pastDueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //   panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(pastDueToolStripMenuItem.Text);
        }

        private void qualifyingCapitalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(qualifyingCapitalToolStripMenuItem.Text);
        }

        private void underLitigationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(underLitigationToolStripMenuItem.Text);
        }

        private void summaryReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //   panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(summaryReportToolStripMenuItem.Text);
        }

        private void aAFBlankIndustryCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //   panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(aAFBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void aAFDOSRITAGGINGToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(aAFDOSRITAGGINGToolStripMenuItem.Text);
        }

        private void aAFZeroAssetSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(aAFZeroAssetSizeToolStripMenuItem.Text);
        }

        private void iCBSBlankIndustryCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(iCBSBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void iCBSDOSRITaggingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(iCBSDOSRITaggingToolStripMenuItem.Text);
        }

        private void iCBSZeroAssetSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(iCBSZeroAssetSizeToolStripMenuItem.Text);
        }

        private void differenceInTaggingOfRiskAndGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  panel1.Enabled = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(differenceInTaggingOfRiskAndGLToolStripMenuItem.Text);
        }

        private void txtRptName_TextChanged(object sender, EventArgs e)
        {
            //  var asdas = txtRptName.Text.ToLower();
            InitializedReport();
            btnExport.Enabled = false;

            if (txtRptName.Text == "Summary Report")
            {
                rDaily.Checked = true;
                pnlRadio.Enabled = true;
                pnlRadio.Visible = true;
                panel1.Visible = false;
                lblMonth.Visible = false;
                cmbMonthName.Visible = false;
                pnlRadio.BringToFront();
            }
            else if (txtRptName.Text.ToLower() == "consolidator")
            {
                pnlRadio.SendToBack();
                pnlRadio.Visible = false;
                panel1.Visible = false;
                pnlMonth.Visible = true;
                cmbMonthName.Visible = true;
                lblMonth.Visible = true;
                cmbMonthName.Enabled = txtRptName.Text.ToLower() == "consolidator" ? true : false;
            }
            else
            {
                rDaily.Checked = false;
                pnlRadio.Enabled = false;
                pnlRadio.Visible = false;
                panel1.Visible = false;
                lblMonth.Visible = false;
                cmbMonthName.Visible = false;
                pnlRadio.SendToBack();
                pnlMonth.Visible = false;
                cmbMonthName.Visible = txtRptName.Text.ToLower() == "consolidator" ? true : false;
            }

            btnExecute.Enabled = txtRptName.Text.Length > 0 ? true : false;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (!IsBusy)
            {

                SaveFileDialog diag = new SaveFileDialog();
                diag.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
                diag.FilterIndex = 0;
                diag.RestoreDirectory = true;
                diag.Title = "Export NTC Consolidator To Excel File";

                if (!string.IsNullOrEmpty(txtRptName.Text.Trim()))
                {
                    if (diag.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            pnlWaitInfo.Visible = true;
                            lblWaitInfo.Text = "Exporting Data, Please wait...";
                            lblWaitStatus.Text = "Status: In-progress...";
                            ExportFilename = diag.FileName;
                            fileDestination = Path.GetFullPath(diag.FileName);

                            summaryExportWorker = new BackgroundWorker();
                            summaryExportWorker.WorkerReportsProgress = true;
                            summaryExportWorker.DoWork += new DoWorkEventHandler(summaryExportWorker_DoWork);
                            summaryExportWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(summaryExportWorker_RunWorkerCompleted);
                            summaryExportWorker.ProgressChanged += new ProgressChangedEventHandler(summaryExportWorker_ProgressChanged);
                            summaryExportWorker.WorkerSupportsCancellation = true;
                            summaryExportWorker.RunWorkerAsync();

                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
            }
            else
            {
                lblBusy.Text = "Busy processing, Please wait...";
            }
        }

        private void summaryExportWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Exporting Data, Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void summaryExportWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            IsBusy = false;
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                lblWaitStatus.Text = "Status: Error Encountered while processing";
                ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                var Modulename = this.GetType().FullName;
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(e.Error, Modulename, methodName, ErrorID);

                MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while exporting the files, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
            else
            {

                lblBusy.Text = "";
                pnlWaitInfo.Visible = false;
                MetroMessageBox.Show(this, "\r\n" + Path.GetFileName(ExportFilename) + " was successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void summaryExportWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            IsBusy = true;

            try
            {
                Warning[] warnings;
                string[] streamids;
                string mimeType;
                string encoding;
                string extension;
                byte[] bytes = this.reportViewer1.LocalReport.Render("EXCEL", "", out mimeType, out encoding, out extension, out streamids, out warnings);
                FileStream fs = new FileStream(fileDestination, FileMode.Create);
                fs.Write(bytes, 0, bytes.Length);
                fs.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void exceptionalReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
        }

        private void rDaily_CheckedChanged(object sender, EventArgs e)
        {
            isYearly = false;
            isMonthly = false;
            isDaily = true;
            radioSelected = "Daily";
        }

        private void rMonthly_CheckedChanged(object sender, EventArgs e)
        {
            isYearly = false;
            isMonthly = true;
            isDaily = false;
            radioSelected = "Month End";
        }

        private void rYearly_CheckedChanged(object sender, EventArgs e)
        {
            isYearly = true;
            isMonthly = false;
            isDaily = false;
            radioSelected = "Year End";
        }

        private void cmbMonthName_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedMonth = cmbMonthName.SelectedIndex.ToString();
            selectedMonthinText = cmbMonthName.Text;
        }
    }

}
