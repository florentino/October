﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using NTC_Consolidator.NTC_Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmPathMaintenance : MetroFramework.Forms.MetroForm
    {
        //public static bool isCancel = false;
        private string __FilePath = "";
        private string __FileEXT = "";
        string ErrorID = "";
        private IFilePathRepository filePathRepository;
        Dictionary<string, string> ErrList = new Dictionary<string, string>();
        private static frmPathMaintenance mform = null;

        public static frmPathMaintenance Instance()
        {
            if (mform == null)
            {
                mform = new frmPathMaintenance();
            }

            return mform;
        }

        //public frmPathMaintenance(out bool _isCancel)
        //{
        //    _isCancel = isCancel;
        //}
        public frmPathMaintenance()
        {
            InitializeComponent();
            this.filePathRepository = new FilePathRepository(new NTCConn());
        }

        private void frmPathMaintenance_Load(object sender, EventArgs e)
        {

        }

        private void btnICBSBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Text Files(.txt) | *.txt| CSV Files(.csv)|*.csv";


            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                //var getFullPath = Path.GetFullPath(dlg.FileName);
                ////////__FilePath = Path.GetDirectoryName(dlg.FileName);
                ////////__FileEXT = Path.GetExtension(dlg.FileName);
                txtICBSFilePath.Text = dlg.FileName;
            }
        }

        private void btnAAFBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                //////__FilePath = Path.GetDirectoryName(dlg.FileName);
                //////__FileEXT = Path.GetExtension(dlg.FileName);
                txtAAFFilePath.Text = dlg.FileName;
            }
        }

        private void btnFAMSBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                ////////__FilePath = Path.GetDirectoryName(dlg.FileName);//dlg.FileName;
                ////////__FileEXT = Path.GetExtension(dlg.FileName);
                txtFAMSFilePath.Text = dlg.FileName;
            }
        }


        private bool IsValid(bool isPassed, FilePathMaintenance maintenance, string icbs, string aaf, string fams/*, string glcode*/)
        {
            isPassed = true;

            try
            {
                if (string.IsNullOrEmpty(icbs))
                {
                    maintenance.ICBSFilePath = "";
                }
                else
                {
                    lblErrIcbs.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrIcbs.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(aaf))
                {
                    maintenance.AAFFilePath = "";
                }
                else
                {
                    lblErrAAF.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrAAF.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(fams))
                {
                    maintenance.FAMSFilePath = "";
                }
                else
                {
                    lblErrFAMS.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrFAMS.Text = ex.Message;
                isPassed = false;
            }

            //try
            //{
            //    if (string.IsNullOrEmpty(glcode))
            //    {
            //        maintenance.GLCodeDescFilePath = "";
            //    }
            //    else
            //    {
            //        lblErrGLCodeAndDesc.Text = "";
            //    }
            //}
            //catch (ValidationException ex)
            //{
            //    lblErrGLCodeAndDesc.Text = ex.Message;
            //    isPassed = false;
            //}


            if (isPassed)
            {

            }

            return isPassed;
        }


        private void btnOK_Click(object sender, EventArgs e)
        {
            string[] file = Directory.GetFiles(Path.GetDirectoryName(txtICBSFilePath.Text), "*.txt");
            if (file.Length > 1)
            {
                //if (Directory.EnumerateFiles(Path.GetDirectoryName(txtICBSFilePath.Text), "*.txt").Any())
                //{
                var dlg = MetroMessageBox.Show(this, "\r\n" + "Multiple \".txt\" Files detected in this path: \"" + Path.GetDirectoryName(txtICBSFilePath.Text) + "\".\r\nThis will cause an error during consolidation proccess.\r\nClick OK to continue process.", "Duplicate .TXT", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (dlg == DialogResult.Cancel) return;

            }

            string[] file1 = Directory.GetFiles(Path.GetDirectoryName(txtAAFFilePath.Text), "*.xls");
            if (file.Length > 1)
            {
                // if (Directory.EnumerateFiles(Path.GetDirectoryName(txtAAFFilePath.Text), "*.xls").Any())
                //{
                var dlg = MetroMessageBox.Show(this, "\r\n" + "Multiple \".xls\" Files detected in this path: \"" + Path.GetDirectoryName(txtAAFFilePath.Text) + "\".\r\nThis will cause an error during consolidation proccess.\r\nClick OK to continue process.", "Duplicate .XLS", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (dlg == DialogResult.Cancel) return;
            }

            string[] file2 = Directory.GetFiles(Path.GetDirectoryName(txtAAFFilePath.Text), "*.xls");
            if (file.Length > 1)
            {
                // if (Directory.EnumerateFiles(Path.GetDirectoryName(txtFAMSFilePath.Text), "*.xls").Any())
                //{
                var dlg = MetroMessageBox.Show(this, "\r\n" + "Multiple \".xls\" Files detected in this path: \"" + Path.GetDirectoryName(txtFAMSFilePath.Text) + "\".\r\nThis will cause an error during consolidation proccess.\r\nClick OK to continue process.", "Duplicate .XLS", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (dlg == DialogResult.Cancel) return;
            }

            FilePathMaintenance maintenance = new FilePathMaintenance();


            var isPassed = false;
            isPassed = IsValid(isPassed, maintenance, txtICBSFilePath.Text, txtAAFFilePath.Text, txtFAMSFilePath.Text/*, txtGLCodeAndDesc.Text*/); //Check for Valid Input

            if (!isPassed) return;

            //if (txtICBSFilePath.Text == "" || txtFAMSFilePath.Text == "" || txtAAFFilePath.Text == "")
            //{
            //    MetroMessageBox.Show(this, "\r\n\r\nPath is not specified.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            //    return;
            //}

            try
            {
                filePathRepository.TruncateTable(frmConsolidator.UserName);

                for (int i = 1; i < 4; i++)
                {
                    var filePathMaintenance = new BDOLF_PathMaintenance();

                    if (i == 1)
                    {
                        filePathMaintenance.FilePath = Path.GetDirectoryName(txtICBSFilePath.Text);
                        filePathMaintenance.FileExtension = Path.GetExtension(txtICBSFilePath.Text);
                        filePathMaintenance.System = "ICBS";
                        filePathMaintenance.TextKeyword = "ICBS";
                    }
                    if (i == 2)
                    {
                        filePathMaintenance.FilePath = Path.GetDirectoryName(txtAAFFilePath.Text);
                        filePathMaintenance.FileExtension = Path.GetExtension(txtAAFFilePath.Text);
                        filePathMaintenance.System = "AAF";
                        filePathMaintenance.TextKeyword = "AAF";
                    }
                    if (i == 3)
                    {
                        filePathMaintenance.FilePath = Path.GetDirectoryName(txtFAMSFilePath.Text);
                        filePathMaintenance.FileExtension = Path.GetExtension(txtFAMSFilePath.Text);
                        filePathMaintenance.System = "FAMS";
                        filePathMaintenance.TextKeyword = "FAMS";
                    }
                    //if (i == 4)
                    //{
                    //    filePathMaintenance.FilePath = Path.GetDirectoryName(txtGLCodeAndDesc.Text);
                    //    filePathMaintenance.FileExtension = Path.GetExtension(txtGLCodeAndDesc.Text);
                    //    filePathMaintenance.System = "GLCODEDESC";
                    //    filePathMaintenance.TextKeyword = "GLCODEDESC";
                    //}

                    filePathMaintenance.UserName = frmConsolidator.UserName;
                    filePathMaintenance.DateInserted = DateTime.Now;

                    filePathRepository.InsertFilePathMaintenace(filePathMaintenance);
                    filePathRepository.Save();
                }

                // isCancel = false;
                MetroMessageBox.Show(this, "\r\n\r\nSuccessfully saved", "Raw File Path Maintenance", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
            catch (Exception ex)
            {
                ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                var Modulename = this.GetType().FullName;
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID, ErrList);

                MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while saving the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //isCancel = true;
            frmPathMaintenance.mform = null;
            this.Close();
        }

        private void frmPathMaintenance_FormClosed(object sender, FormClosedEventArgs e)
        {
            // isCancel = true;
            frmPathMaintenance.mform = null;
        }

        private void btnGLCodeDesc_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                ////////__FilePath = Path.GetDirectoryName(dlg.FileName);//dlg.FileName;
                ////////__FileEXT = Path.GetExtension(dlg.FileName);
                txtGLCodeAndDesc.Text = dlg.FileName;
            }
        }
    }
}
