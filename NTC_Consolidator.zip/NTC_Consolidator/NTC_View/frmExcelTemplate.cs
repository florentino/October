﻿using MetroFramework;
using NTC_Consolidator.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmExcelTemplate : MetroFramework.Forms.MetroForm
    {
        string ErrorID = "";
        string ModuleName = "";

        private static frmExcelTemplate mform = null;

        public static frmExcelTemplate Instance()
        {
            if (mform == null)
            {
                mform = new frmExcelTemplate();
            }

            return mform;
        }


        public frmExcelTemplate()
        {
            InitializeComponent();
        }

        private void frmExcelTemplate_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DownloadExcel("APL Account");
        }

        private void DownloadExcel(string mname)
        {
            try
            {
                var retVal = DownloadExcelTemplate.DownloadTemplate(mname);
                if (retVal == 1)
                {
                    MetroMessageBox.Show(this, "\r\n" + mname + " excel Template was successfully downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

                var Modulename = this.GetType().FullName;
                var methodName = MethodBase.GetCurrentMethod().Name;
                ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID);

                MetroMessageBox.Show(this, "ERROR LogID: " + ErrorID + "\r\nError Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while downloading the template, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DownloadExcel("GL Code And Description");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DownloadExcel("NTC Consolidator");
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DownloadExcel("Dollar Rate And Dollar Account");
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DownloadExcel("Daily GL");
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DownloadExcel("Migrated Account");
        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DownloadExcel("Past Due Account");
        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            DownloadExcel("Accounts Under Litigation");
        }

        private void frmExcelTemplate_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmExcelTemplate.mform = null;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            frmExcelTemplate.mform = null;
            this.Close();
        }
    }
}
