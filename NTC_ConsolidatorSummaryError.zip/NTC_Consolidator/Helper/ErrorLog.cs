﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace NTC_Consolidator.Helper
{
    public class ErrorLog
    {
        //Author : Florentino B. Delima
        //Date Written : September 5, 2018

        /// <summary>
        /// Logger is used for creating a customized error log files or an error can be registered as
        /// a log entry in the Windows Event Log on the administrator's machine.
        /// </summary>
        protected static string strLogFilePath = string.Empty;
        private static StreamWriter sw = null;
        static Dictionary<string, string> ErrList = new Dictionary<string, string>();
        static int ErrorCounter = 0;
        private static string ErException = "";
        /// <summary>
        /// Write Source,method,date,time,computer,error and stack trace information to the text file
        /// </summary>
        /// <param name="strPathName"></param>
        /// <param name="objException"></param>
        /// <returns>false if the problem persists</returns>
        private static bool WriteErrorLog(string retFilePath)
        {
            string strPathName = "NTC_Error_" + DateTime.Now.ToShortDateString().ToString().Replace("/", "") + "_" + DateTime.Now.ToLongTimeString().ToString().Replace("/", "") + ".txt";
            strPathName = retFilePath + strPathName.Replace(":", "");
            bool bReturn = false;

            try
            {
                using (StreamWriter file = new StreamWriter(strPathName))
                {
                    file.WriteLine("^^------------------------------ START OF LOGS HERE ( " + DateTime.Today.ToLongDateString() + " )-------------------------------------^^");
                    foreach (KeyValuePair<string, string> val in ErrList)
                    {
                        file.WriteLine(val.Key + "\t" + val.Value);
                    }
                    file.WriteLine("^^------------------------------ E N D O F L O G S -------------------------------------^^");
                }
                Process.Start("notepad.exe", strPathName);
            }
            catch (Exception ex)
            {
                ErException = ex.Message.ToString();
                bReturn = false;
            }
            return bReturn;
        }

        /// <summary>
        /// Check the log file in application directory. If it is not available, create it
        /// </summary>
        /// <returns>Log file path</returns>

        public static string GetLogFilePath()
        {
            try
            {
                // get the base directory
                string baseDir = AppDomain.CurrentDomain.BaseDirectory + AppDomain.CurrentDomain.RelativeSearchPath;
                // search the file below the current directory
                string retFilePath = baseDir + "Modules\\NTC_Consolidator\\NTC_Consolidator_Logs\\";

                // if exists, return the path
                if (File.Exists(retFilePath))
                {
                    return retFilePath;
                }
                else
                {
                    if (!CheckDirectory(retFilePath))
                        return string.Empty;

                    if (ErException == "")
                        WriteErrorLog(retFilePath);
                    else
                        throw new Exception(ErException);

                }

                return retFilePath;
            }
            catch (Exception)
            {
                throw new Exception(ErException);
            }
        }

        /// <summary>
        /// Create a directory if not exists
        /// </summary>
        /// <param name="strLogPath"></param>
        /// <returns></returns>
        private static bool CheckDirectory(string strLogPath)
        {
            try
            {
                int nFindSlashPos = strLogPath.Trim().LastIndexOf("\\");
                string strDirectoryname = strLogPath.Trim().Substring(0, nFindSlashPos);

                if (!Directory.Exists(strDirectoryname))
                    Directory.CreateDirectory(strDirectoryname);

                return true;
            }
            catch (Exception ex)
            {
                ErException = ex.Message.ToString();
                return false;
            }
        }

        public static void AddError(string _errMsg)
        {
            ErrList.Add("Err#." + ErrorCounter++ + "\t", _errMsg);
        }

        public static int CountError()
        {
            return ErrList.Count();
        }

        /// <summary>
        /// Initialize the Error Log
        /// </summary>
        public ErrorLog()
        {
            ErrList = new Dictionary<string, string>();
        }
    }
}