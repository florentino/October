﻿using MetroFramework;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using NTC_Consolidator.NTC_View;
using NTC_Encrypt_Decrypt;
using System;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Reflection;
using System.Security.AccessControl;
using System.Windows.Forms;

namespace NTC_Consolidator
{

    #region Final

    //static class Program
    //{
    //    public static string NTC_UserRole = String.Empty;
    //    public static string NTC_dbuserName = String.Empty;
    //    public static string NTC_dbpassword = String.Empty;
    //    public static string NTC_ServerName = String.Empty;
    //    public static string NTC_UserloginName = String.Empty;
    //    public static string NTC_DBName = String.Empty;
    //    public static string NTC_IntegSecurity = "SSPI";
    //    public static string NTC_PerSecurity = "False";
    //    public static string NTC_ProviderName = "System.Data.SqlClient";
    //    public static string NTC_ConnectionName = "NTCConn";
    //    public static string NTC_DateFrom = "";
    //    public static string NTC_ReportPath = "";
    //    public static string NTCNewModifiedConnectionString = "";
    //    /// <summary>
    //    /// The main entry point for the application.
    //    /// </summary>
    //    [STAThread]
    //    static void Main(string[] args)
    //    {
    //        //  MessageBox.Show(args[0].ToString() + ",0 " + args[1].ToString() + ", 1" + args[2].ToString() + ", 2" + args[3].ToString() + ", 3" + args[4].ToString() + ", 4" + args[5].ToString() + ", 5" + args[6].ToString() + ", 6" + args[7].ToString() + ", 7");

    //        if (args[0] == "d@shb0@rd")
    //        {
    //            try
    //            {

    //                    NTC_ServerName = args[1].ToString();
    //                    NTC_DBName = args[2].ToString();
    //                    NTC_dbuserName = args[3].ToString();// != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(args[3].ToString()) : ""; // NTC_dbuserName ==> e.g:  Kulangot
    //                    NTC_dbpassword = args[4].ToString();// != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(args[4].ToString()) : ""; // NTC_dbuserName ==> e.g:  Kulangot
    //                    NTC_UserloginName = args[5].ToString();

    //                    NTC_ReportPath = args[6].ToString(); // @"\\bdowlas07v\AAF\NTC_Reports\"; //
    //                                                         //MessageBox.Show(NTC_ReportPath);
    //                                                         // MessageBox.Show(args[0].ToString() + args[1].ToString() + args[2].ToString() + args[3].ToString() + args[4].ToString() + args[5].ToString() + args[6].ToString() + args[7].ToString());
    //                                                         // ModifyDataBaseConnection();

    //                    NTC_PerSecurity = args[7].ToString();
    //                    NTC_IntegSecurity = args[8].ToString();

    //                    // MessageBox.Show(NTC_ReportPath + " " + NTC_PerSecurity + " " + NTC_IntegSecurity);
    //                    Application.EnableVisualStyles();
    //                    Application.SetCompatibleTextRenderingDefault(false);
    //                    Application.Run(new frmConsolidator());
    //                    //frmConsolidator frmunderLitigation = frmConsolidator.Instance();
    //                    //frmunderLitigation.ShowDialog();

    //            }
    //            catch (Exception ex)
    //            {
    //                var ErrorID = DateTime.Today.DayOfYear.ToString("000") + DateTime.Now.ToString("Hmmssff");

    //                //var Modulename = "Main: trackValue =>  " + trackValue;
    //                var Modulename = "Program";
    //                var methodName = MethodBase.GetCurrentMethod().Name;
    //                ErrorLog.GetLogFilePath(ex, Modulename, methodName, ErrorID);
    //                //MessageBox.Show(ex.Message);
    //                MessageBox.Show("ERROR LogID: " + ErrorID + "\r\n " + ex.Message + "\r\n\r\nAn Error occured during execution of NTC Consolidator. Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
    //            }
    //        }
    //        else
    //        {
    //            MessageBox.Show("Access is denied. User is unauthorized or has limited rights on this module", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
    //        }
    //    }
    //}

    #endregion


    #region For Testing

    static class Program
    {
        public static string NTC_UserRole = String.Empty;
        public static string NTC_dbuserName = String.Empty;
        public static string NTC_dbpassword = String.Empty;
        public static string NTC_ServerName = String.Empty;
        public static string NTC_UserloginName = String.Empty;
        public static string NTC_DBName = String.Empty;
        public static string NTC_IntegSecurity = "SSPI";
        public static string NTC_PerSecurity = "False";
        public static string NTC_ProviderName = "System.Data.SqlClient";
        public static string NTC_ConnectionName = "NTCConn";
        public static string NTC_DateFrom = "";
        public static string NTC_ReportPath = "";
        public static string NTCNewModifiedConnectionString = "";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                //if (IsApplicationAlreadyRunning() == true)
                //{
                //    MessageBox.Show("NTC Consolidator is already running", "NTC Application", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //}
                //else
                //{
                NTC_ServerName = "BDOWLDB10V";
                NTC_DBName = "tmpNTC";
                NTC_dbuserName = "0B+F5qaQEI9UnQpJ1SRsrg==";//d_aaf_test2
                NTC_dbpassword = "Tqk/GX58kyPj1jYqSZ3UTA==";//password
                NTC_UserloginName = "c161007003";
                //NTC_DateFrom = "07/01/2018";
                NTC_ReportPath = @"\\bdowlas07v\AAF\NTC_Reports\";
                //Uncomment this part if the connection is encrypted
                //NTC_IntegSecurity = "SSPI";
                //NTC_PerSecurity = "";
                ////UserName = data[0].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[0].ToString()) : ""; // NTC_userId ==> e.g:  Mangkanor
                ////Password = data[1].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[1].ToString()) : ""; // NTC_password ==> e.g:  Kulangot
                ////DbServer = data[2].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[2].ToString()) : ""; // NTC_ServerName ==> e.g:  BDOWLDB13V
                ////Role = data[3].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[3].ToString()) : ""; // NTC_Role ==> e.g:  BackFighter
                ////DBName = data[4].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[4].ToString()) : ""; // NTC_DBName ==> e.g:  dbAAF_SalesRec
                ////ProviderName = data[5].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[5].ToString()) : ""; // NTC_DBName ==> e.g:  NTCConnNTC_ProviderName
                ////ConnectionName = data[6].ToString() != "" ? CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(data[6].ToString()) : ""; // NTC_DBName ==> e.g:  NTCConn
                //                      0             1                  2                    3                       4                      5                      6
                // trackValue = "d@shb0@rd " + NTC_ServerName + " " + NTC_DBName + " " + NTC_dbuserName + " " + NTC_dbpassword + " " + NTC_UserloginName + " " + NTC_UserRole;

                //trackValue = NTC_ServerName + " " + NTC_DBName + " " + NTC_dbuserName + " " + NTC_dbpassword + " " + NTC_UserloginName;// + " " + args[6].ToString();

                NTC_dbuserName = CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(NTC_dbuserName);
                NTC_dbpassword = CipherDecipher.Cipher_Decipher.FromOSS_Decrypt(NTC_dbpassword);
                NTC_PerSecurity = "False";
                NTC_IntegSecurity = "";
                // ModifyDataBaseConnection();
                // NTCConn entities = new NTCConn(BuildConnectionString(Program.NTC_ServerName, Program.NTC_DBName, Program.NTC_dbuserName, Program.NTC_dbpassword));

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmConsolidator());
                // }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Message: " + ex.InnerException.Message.ToString() + "\r\n\r\nAn Error occured during execution of NTC Consolidator. Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }

        }

        static bool IsApplicationAlreadyRunning()
        {
            string proc = Process.GetCurrentProcess().ProcessName;
            Process[] processes = Process.GetProcessesByName(proc);
            return processes.Length > 1 ? true : false;
        }



    }

    #endregion
}






