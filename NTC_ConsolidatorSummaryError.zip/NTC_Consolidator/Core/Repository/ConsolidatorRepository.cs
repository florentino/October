﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.Data;
using System.Data.Entity;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using NTC_Consolidator.NTC_Model;
using System.Transactions;
using System.Data.Entity.Core.EntityClient;
using NTC_Consolidator.Helper;

namespace NTC_Consolidator.Core.Repository
{

    public class ConsolidatorRepository : IConsolidator, IDisposable
    {
        private NTCConn context;
        DbSet<BDOLF_Consolidator> _bjectSet;


        public ConsolidatorRepository(NTCConn context)
        {
            this.context = context;

            _bjectSet = context.Set<BDOLF_Consolidator>();
        }

        public void BulkDelete(object[] objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkInsert(object[] objdata, string keyword)
        {
            var icbsData = (DataTable)objdata[0];
            var aafData = (DataTable)objdata[1];
            var famsData = (DataTable)objdata[2];

            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TimeSpan(2, 0, 0)))
            {
                NTCConn context = null;
                try
                {
                    context = new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString());
                    context.Configuration.AutoDetectChangesEnabled = false;
                    context.Configuration.ValidateOnSaveEnabled = false;

                    // context.Database.CommandTimeout = 2500;
                    int count = 0;
                    int icbscount = 0;

                    DeleteConsolidator(keyword); // Delete Insert

                    #region ICBS
                    foreach (DataRow entityToInsert in icbsData.Rows)
                    {
                        BDOLF_Consolidator item = new BDOLF_Consolidator();

                        item.AccountNo = entityToInsert["AccountNo"].ToString().Trim().Trim();
                        item.ClientName = entityToInsert["ClientName"].ToString().Trim().Trim();
                        item.AO = (entityToInsert["AO"].ToString().Trim().Trim() == "" || entityToInsert["AO"].ToString().Trim().Trim() == "--") ? "" : entityToInsert["AO"].ToString().Trim().Trim();
                        item.FacilityCode = (entityToInsert["FacilityCode"].ToString().Trim().Trim() == "" || entityToInsert["FacilityCode"].ToString().Trim().Trim() == "--") ? "" : entityToInsert["FacilityCode"].ToString().Trim().Trim();
                        item.StatusPerSystem = (entityToInsert["StatusPerSystem"].ToString().Trim().Trim() == "" || entityToInsert["StatusPerSystem"].ToString().Trim().Trim() == "--") ? "" : entityToInsert["StatusPerSystem"].ToString().Trim().Trim();
                        item.ValueDate = Convert.ToDateTime(entityToInsert["ValueDate"]);
                        item.MaturityDate = Convert.ToDateTime(entityToInsert["MaturityDate"]);
                        item.TotalLoan = entityToInsert["TotalLoan"].ToString().Trim().Trim() == "" ? 0M : Convert.ToDecimal(entityToInsert["TotalLoan"]);
                        item.OB = entityToInsert["OB"].ToString().Trim().Trim() == "" ? 0M : Convert.ToDecimal(entityToInsert["OB"]);
                        item.MonthlyOB = entityToInsert["MonthlyOB"].ToString().Trim().Trim() == "" ? 0M : Convert.ToDecimal(entityToInsert["MonthlyOB"]);
                        item.AccruedInterestReceivable = entityToInsert["AccruedInterestReceivable"].ToString().Trim().Trim() == "" ? 0M : Convert.ToDecimal(entityToInsert["AccruedInterestReceivable"]);
                        item.OriginalRate = (entityToInsert["OriginalRate"].ToString().Trim().Trim() == "" || entityToInsert["OriginalRate"].ToString().Trim().Trim() == "--" || entityToInsert["OriginalRate"].ToString().Trim().Trim() == "-") ? "" : entityToInsert["OriginalRate"].ToString().Trim().Trim();
                        item.CurrentRate = (entityToInsert["CurrentRate"].ToString().Trim().Trim() == "" || entityToInsert["CurrentRate"].ToString().Trim().Trim() == "--" || entityToInsert["CurrentRate"].ToString().Trim().Trim() == "-") ? "" : entityToInsert["CurrentRate"].ToString().Trim().Trim();
                        item.TermInMonths = entityToInsert["TermInMonths"].ToString().Trim().Trim() == "" ? 0 : Convert.ToInt32(entityToInsert["TermInMonths"]);
                        item.AAFICBSRateType = (entityToInsert["AAFICBSRateType"].ToString().Trim().Trim() == "" || entityToInsert["AAFICBSRateType"].ToString().Trim().Trim() == "--" || entityToInsert["AAFICBSRateType"].ToString().Trim().Trim() == "-") ? "" : entityToInsert["AAFICBSRateType"].ToString().Trim().Trim();
                        item.PastDueDateITLDateExtractedPerAAFICBS = (entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString().Trim().Trim() == "" || entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString().Trim().Trim() == "--" || entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString().Trim().Trim() == "-") ? "" : entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString().Trim().Trim();
                        item.PerFaMSAAFICBSIndustryCode = (entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString().Trim().Trim() == "" || entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString().Trim().Trim() == "--" || entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString().Trim().Trim() == "-") ? "" : entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString().Trim().Trim();
                        item.IndustryHeader = (entityToInsert["IndustryHeader"].ToString().Trim().Trim() == "" || entityToInsert["IndustryHeader"].ToString().Trim().Trim() == "--" || entityToInsert["IndustryHeader"].ToString().Trim().Trim() == "-") ? "" : entityToInsert["IndustryHeader"].ToString().Trim().Trim();
                        item.IndustryDetail = (entityToInsert["IndustryDetail"].ToString().Trim().Trim() == "" || entityToInsert["IndustryDetail"].ToString().Trim().Trim() == "--" || entityToInsert["IndustryHeader"].ToString().Trim().Trim() == "-") ? "" : entityToInsert["IndustryDetail"].ToString().Trim().Trim();
                        item.Collateral = (entityToInsert["Collateral"].ToString().Trim().Trim() == "" || entityToInsert["Collateral"].ToString().Trim().Trim() == "--" || entityToInsert["Collateral"].ToString().Trim().Trim() == "-") ? "" : entityToInsert["Collateral"].ToString().Trim().Trim();
                        item.PerFaMSAAFICBSAssetSize = (entityToInsert["PerFaMSAAFICBSAssetSize"].ToString().Trim().Trim() == "00" || entityToInsert["PerFaMSAAFICBSAssetSize"].ToString().Trim().Trim() == ".00" || entityToInsert["PerFaMSAAFICBSAssetSize"].ToString().Trim().Trim() == "--" || entityToInsert["PerFaMSAAFICBSAssetSize"].ToString().Trim().Trim() == "-") ? "0" : entityToInsert["PerFaMSAAFICBSAssetSize"].ToString().Trim().Trim();
                        item.CostCenter = (entityToInsert["CostCenter"].ToString().Trim().Trim() == "" || entityToInsert["CostCenter"].ToString().Trim().Trim() == "--") ? "" : entityToInsert["CostCenter"].ToString().Trim().Trim();
                        item.NationalityPerICBS = (entityToInsert["NationalityPerICBS"].ToString().Trim().Trim() == "" || entityToInsert["NationalityPerICBS"].ToString().Trim().Trim() == "--") ? "" : entityToInsert["NationalityPerICBS"].ToString().Trim().Trim();
                        item.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(entityToInsert["NextRateReviewDateExtractedPerFaMSAAFICBS"]);
                        item.TaxID = (entityToInsert["TaxID"].ToString().Trim().Trim() == "" || entityToInsert["TaxID"].ToString().Trim().Trim() == "--") ? "" : entityToInsert["TaxID"].ToString().Trim().Trim();
                        item.LoanPurposeCode = (entityToInsert["LoanPurposeCode"].ToString().Trim().Trim() == "" || entityToInsert["LoanPurposeCode"].ToString().Trim().Trim() == "--") ? "" : entityToInsert["LoanPurposeCode"].ToString().Trim().Trim();
                        item.MaturityTypeCode = (entityToInsert["MaturityTypeCode"].ToString().Trim().Trim() == "" || entityToInsert["MaturityTypeCode"].ToString().Trim().Trim() == "--") ? "" : entityToInsert["MaturityTypeCode"].ToString().Trim().Trim();
                        item.BankRelationship = (entityToInsert["BankRelationship"].ToString().Trim() == "" || entityToInsert["BankRelationship"].ToString().Trim() == "--") ? "" : entityToInsert["BankRelationship"].ToString().Trim();
                        item.SyndicatedLoanInd = (entityToInsert["SyndicatedLoanInd"].ToString().Trim() == "" || entityToInsert["SyndicatedLoanInd"].ToString().Trim() == "--") ? "" : entityToInsert["SyndicatedLoanInd"].ToString().Trim();
                        item.CustomerTypeDescription = (entityToInsert["CustomerTypeDescription"].ToString().Trim() == "" || entityToInsert["CustomerTypeDescription"].ToString().Trim() == "--") ? "" : entityToInsert["CustomerTypeDescription"].ToString().Trim();
                        item.RPT = (entityToInsert["RPT"].ToString().Trim() == "" || entityToInsert["RPT"].ToString().Trim() == "--") ? "" : entityToInsert["RPT"].ToString().Trim();
                        item.ICBSCollateralCode = (entityToInsert["ICBSCollateralCode"].ToString().Trim() == "" || entityToInsert["ICBSCollateralCode"].ToString().Trim() == "--") ? "" : entityToInsert["ICBSCollateralCode"].ToString().Trim();
                        item.AssetValue = entityToInsert["AssetValue"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(entityToInsert["AssetValue"]);
                        item.ApprovedAmount = entityToInsert["ApprovedAmount"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(entityToInsert["ApprovedAmount"]);
                        item.LastPrincipalPay = entityToInsert["LastPrincipalPay"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(entityToInsert["LastPrincipalPay"]);
                        item.PrincipalPayDate = Convert.ToDateTime(entityToInsert["PrincipalPayDate"]);
                        item.LastInterestPay = entityToInsert["LastInterestPay"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(entityToInsert["LastInterestPay"]);
                        item.LastInterestPayDate = Convert.ToDateTime(entityToInsert["LastInterestPayDate"]);
                        item.PreviousMonthsNPLTaggingByRisk = (entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString().Trim() == "" || entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString().Trim() == "--") ? "" : entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString().Trim();
                        item.SpecificRequiredProvisions = (entityToInsert["SpecificRequiredProvisions"].ToString().Trim() == "" || entityToInsert["SpecificRequiredProvisions"].ToString().Trim() == "--") ? "" : entityToInsert["SpecificRequiredProvisions"].ToString().Trim();
                        item.GeneralRequiredProvisions = (entityToInsert["GeneralRequiredProvisions"].ToString().Trim() == "" || entityToInsert["GeneralRequiredProvisions"].ToString().Trim() == "--") ? "" : entityToInsert["GeneralRequiredProvisions"].ToString().Trim();
                        item.Reason = (entityToInsert["Reason"].ToString().Trim() == "" || entityToInsert["Reason"].ToString().Trim() == "--") ? "" : entityToInsert["Reason"].ToString().Trim();
                        item.RawFiles = entityToInsert["RawFiles"].ToString().Trim();
                        item.isConsolidated = Convert.ToBoolean(entityToInsert["isConsolidated"]);
                        item.isDeleted = Convert.ToBoolean(entityToInsert["isDeleted"]);
                        item.UserName = entityToInsert["UserName"].ToString().Trim();
                        item.TransDate = Convert.ToDateTime(entityToInsert["TransDate"]);
                        item.RecordDate = Convert.ToDateTime(entityToInsert["RecordDate"]);
                        item.SYSTEM = entityToInsert["SYSTEM"].ToString().Trim();
                        ++count;
                        ++icbscount;
                        context = AddToContext(context, item, count, 100, true);
                    }

                    #endregion

                    #region AAF
                    foreach (DataRow entityToInsert in aafData.Rows)
                    {
                        BDOLF_Consolidator item = new BDOLF_Consolidator();

                        item.AccountNo = entityToInsert["AccountNo"].ToString().Trim();
                        item.ClientName = entityToInsert["ClientName"].ToString().Trim() == "--" ? "" : entityToInsert["ClientName"].ToString().Trim();
                        item.AO = entityToInsert["AO"].ToString().Trim() == "--" ? "" : entityToInsert["AO"].ToString().Trim();
                        item.FacilityCode = entityToInsert["FacilityCode"].ToString().Trim() == "--" ? "" : entityToInsert["FacilityCode"].ToString().Trim();
                        item.StatusPerSystem = entityToInsert["StatusPerSystem"].ToString().Trim() == "--" ? "" : entityToInsert["StatusPerSystem"].ToString().Trim();
                        item.ValueDate = Convert.ToDateTime(entityToInsert["ValueDate"]);
                        item.FirstDueDate = Convert.ToDateTime(entityToInsert["FirstDueDate"]);
                        item.MaturityDate = Convert.ToDateTime(entityToInsert["MaturityDate"]);
                        item.TotalLoan = (entityToInsert["TotalLoan"].ToString().Trim() == "" || entityToInsert["TotalLoan"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["TotalLoan"]);
                        item.OB = (entityToInsert["OB"].ToString().Trim() == "" || entityToInsert["OB"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["OB"]);
                        item.MonthlyOB = (entityToInsert["MonthlyOB"].ToString().Trim() == "" || entityToInsert["MonthlyOB"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["MonthlyOB"]);
                        item.UDIBalance = (entityToInsert["UDIBalance"].ToString().Trim() == "" || entityToInsert["UDIBalance"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["UDIBalance"]);
                        item.OrigERV = (entityToInsert["OrigERV"].ToString().Trim() == "" || entityToInsert["OrigERV"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["OrigERV"]);
                        item.PVRV = (entityToInsert["PVRV"].ToString().Trim() == "" || entityToInsert["PVRV"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["PVRV"]);
                        item.OrigGD = (entityToInsert["OrigGD"].ToString().Trim() == "" || entityToInsert["OrigGD"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["OrigGD"]);
                        item.PVGD = (entityToInsert["PVGD"].ToString().Trim() == "" || entityToInsert["PVGD"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["PVGD"]);
                        item.OriginalRate = (entityToInsert["OriginalRate"].ToString().Trim() == "" || entityToInsert["OriginalRate"].ToString().Trim() == "--") ? "" : entityToInsert["OriginalRate"].ToString().Trim();
                        item.CurrentRate = (entityToInsert["CurrentRate"].ToString().Trim() == "" || entityToInsert["CurrentRate"].ToString().Trim() == "--") ? "" : entityToInsert["CurrentRate"].ToString().Trim();
                        item.TermInMonths = (entityToInsert["TermInMonths"].ToString().Trim() == "" || entityToInsert["TermInMonths"].ToString().Trim() == "--") ? 0 : (int)Convert.ToDecimal(entityToInsert["TermInMonths"]);
                        item.RemainingTermInMonths = (entityToInsert["RemainingTermInMonths"].ToString().Trim() == "" || entityToInsert["RemainingTermInMonths"].ToString().Trim() == "--") ? 0 : (int)Convert.ToDecimal(entityToInsert["RemainingTermInMonths"]);
                        item.OriginalAmortizationAAF = (entityToInsert["OriginalAmortizationAAF"].ToString().Trim() == "" || entityToInsert["OriginalAmortizationAAF"].ToString().Trim() == "--") ? "" : entityToInsert["OriginalAmortizationAAF"].ToString().Trim();
                        item.PaymentScheduleAmortizationAAF = (entityToInsert["PaymentScheduleAmortizationAAF"].ToString().Trim() == "" || entityToInsert["PaymentScheduleAmortizationAAF"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["PaymentScheduleAmortizationAAF"]);
                        item.RepricedDate = Convert.ToDateTime(entityToInsert["RepricedDate"]);
                        item.AAFICBSRateType = (entityToInsert["AAFICBSRateType"].ToString().Trim() == "" || entityToInsert["AAFICBSRateType"].ToString().Trim() == "--") ? "" : entityToInsert["AAFICBSRateType"].ToString().Trim();
                        item.RepricedAmortization = (entityToInsert["RepricedAmortization"].ToString().Trim() == "" || entityToInsert["RepricedAmortization"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["RepricedAmortization"]);
                        item.PastDueDateITLDateExtractedPerAAFICBS = (entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString().Trim() == "" || entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString().Trim() == "--") ? "" : entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString().Trim();
                        item.PerFaMSAAFICBSIndustryCode = (entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString().Trim() == "" || entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString().Trim() == "--") ? "" : entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString().Trim();
                        item.IndustryHeader = (entityToInsert["IndustryHeader"].ToString().Trim() == "" || entityToInsert["IndustryHeader"].ToString().Trim() == "--") ? "" : entityToInsert["IndustryHeader"].ToString().Trim();
                        item.IndustryDetail = (entityToInsert["IndustryDetail"].ToString().Trim() == "" || entityToInsert["IndustryDetail"].ToString().Trim() == "--") ? "" : entityToInsert["IndustryDetail"].ToString().Trim();
                        item.Collateral = (entityToInsert["Collateral"].ToString().Trim() == "" || entityToInsert["Collateral"].ToString().Trim() == "--") ? "" : entityToInsert["Collateral"].ToString().Trim();
                        item.PerFaMSAAFICBSAssetSizeInWords = (entityToInsert["PerFaMSAAFICBSAssetSizeInWords"].ToString().Trim() == "" || entityToInsert["PerFaMSAAFICBSAssetSizeInWords"].ToString().Trim() == "--") ? "" : entityToInsert["PerFaMSAAFICBSAssetSizeInWords"].ToString().Trim();
                        item.ICBSGLCode = (entityToInsert["ICBSGLCode"].ToString().Trim() == "" || entityToInsert["ICBSGLCode"].ToString().Trim() == "--") ? "" : entityToInsert["ICBSGLCode"].ToString().Trim();
                        item.ICBSGLName = (entityToInsert["ICBSGLName"].ToString().Trim() == "" || entityToInsert["ICBSGLName"].ToString().Trim() == "--") ? "" : entityToInsert["ICBSGLName"].ToString().Trim();
                        item.CostCenter = (entityToInsert["CostCenter"].ToString().Trim() == "" || entityToInsert["CostCenter"].ToString().Trim() == "--") ? "" : entityToInsert["CostCenter"].ToString().Trim();
                        item.BranchNameOfCostCenterPerSystem = (entityToInsert["BranchNameOfCostCenterPerSystem"].ToString().Trim() == "" || entityToInsert["BranchNameOfCostCenterPerSystem"].ToString().Trim() == "--") ? "" : entityToInsert["BranchNameOfCostCenterPerSystem"].ToString().Trim();
                        item.OriginatingBranchBooked = (entityToInsert["OriginatingBranchBooked"].ToString().Trim() == "" || entityToInsert["OriginatingBranchBooked"].ToString().Trim() == "--") ? "" : entityToInsert["OriginatingBranchBooked"].ToString().Trim();
                        item.NationalityPerICBS = (entityToInsert["NationalityPerICBS"].ToString().Trim() == "" || entityToInsert["NationalityPerICBS"].ToString().Trim() == "--") ? "" : entityToInsert["NationalityPerICBS"].ToString().Trim();
                        item.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(entityToInsert["NextRateReviewDateExtractedPerFaMSAAFICBS"]);
                        item.TaxID = (entityToInsert["TaxID"].ToString().Trim() == "0" || entityToInsert["TaxID"].ToString().Trim() == "" || entityToInsert["TaxID"].ToString().Trim() == "--") ? "" : entityToInsert["TaxID"].ToString().Trim();
                        item.CustomerTypeDescription = (entityToInsert["CustomerTypeDescription"].ToString().Trim() == "" || entityToInsert["CustomerTypeDescription"].ToString().Trim() == "--") ? "" : entityToInsert["CustomerTypeDescription"].ToString().Trim();
                        item.RELCode = (entityToInsert["RELCode"].ToString().Trim() == "" || entityToInsert["RELCode"].ToString().Trim() == "--") ? "" : entityToInsert["RELCode"].ToString().Trim();
                        item.REECode = (entityToInsert["REECode"].ToString().Trim() == "" || entityToInsert["REECode"].ToString().Trim() == "--") ? "" : entityToInsert["REECode"].ToString().Trim();
                        item.REEAddtlInfo = (entityToInsert["REEAddtlInfo"].ToString().Trim() == "" || entityToInsert["REEAddtlInfo"].ToString().Trim() == "--") ? "" : entityToInsert["REEAddtlInfo"].ToString().Trim();
                        item.AcctRef = (entityToInsert["AcctRef"].ToString().Trim() == "" || entityToInsert["AcctRef"].ToString().Trim() == "--") ? "" : entityToInsert["AcctRef"].ToString().Trim();
                        item.RPT = (entityToInsert["RPT"].ToString().Trim() == "" || entityToInsert["RPT"].ToString().Trim() == "--") ? "" : entityToInsert["RPT"].ToString().Trim();
                        item.ASSETCOST = (entityToInsert["ASSETCOST"].ToString().Trim() == "" || entityToInsert["ASSETCOST"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["ASSETCOST"]);
                        item.LeaseType = (entityToInsert["LeaseType"].ToString().Trim() == "" || entityToInsert["LeaseType"].ToString().Trim() == "--") ? "" : entityToInsert["LeaseType"].ToString().Trim();
                        item.ICBSCollateralCode = (entityToInsert["ICBSCollateralCode"].ToString().Trim() == "" || entityToInsert["ICBSCollateralCode"].ToString().Trim() == "--") ? "" : entityToInsert["ICBSCollateralCode"].ToString().Trim();
                        item.AssetValue = (entityToInsert["AssetValue"].ToString().Trim() == "" || entityToInsert["AssetValue"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["AssetValue"]);
                        item.ApprovedAmount = (entityToInsert["ApprovedAmount"].ToString().Trim() == "" || entityToInsert["ApprovedAmount"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["ApprovedAmount"]);
                        item.CPNumber = (entityToInsert["CPNumber"].ToString().Trim() == "" || entityToInsert["CPNumber"].ToString().Trim() == "--") ? "" : entityToInsert["CPNumber"].ToString().Trim();
                        item.LastPrincipalPay = (entityToInsert["LastPrincipalPay"].ToString().Trim() == "" || entityToInsert["LastPrincipalPay"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["LastPrincipalPay"]);
                        item.PrincipalPayDate = Convert.ToDateTime(entityToInsert["PrincipalPayDate"]);
                        item.LastInterestPay = (entityToInsert["LastInterestPay"].ToString().Trim() == "" || entityToInsert["LastInterestPay"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(entityToInsert["LastInterestPay"]);
                        item.LastInterestPayDate = Convert.ToDateTime(entityToInsert["LastInterestPayDate"]);
                        item.PreviousMonthsNPLTaggingByRisk = (entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString().Trim() == "" || entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString().Trim() == "--") ? "" : entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString().Trim();
                        item.SpecificRequiredProvisions = (entityToInsert["SpecificRequiredProvisions"].ToString().Trim() == "" || entityToInsert["SpecificRequiredProvisions"].ToString().Trim() == "--") ? "" : entityToInsert["SpecificRequiredProvisions"].ToString().Trim();
                        item.GeneralRequiredProvisions = (entityToInsert["GeneralRequiredProvisions"].ToString().Trim() == "" || entityToInsert["GeneralRequiredProvisions"].ToString().Trim() == "--") ? "" : entityToInsert["GeneralRequiredProvisions"].ToString().Trim();
                        item.Reason = (entityToInsert["Reason"].ToString().Trim() == "" || entityToInsert["Reason"].ToString().Trim() == "--") ? "" : entityToInsert["Reason"].ToString().Trim();
                        item.RawFiles = entityToInsert["RawFiles"].ToString().Trim();
                        item.isConsolidated = Convert.ToBoolean(entityToInsert["isConsolidated"]);
                        item.isDeleted = Convert.ToBoolean(entityToInsert["isDeleted"]);
                        item.UserName = entityToInsert["UserName"].ToString().Trim();
                        item.TransDate = Convert.ToDateTime(entityToInsert["TransDate"]);
                        item.RecordDate = Convert.ToDateTime(entityToInsert["RecordDate"]);
                        item.SYSTEM = entityToInsert["SYSTEM"].ToString().Trim();
                        ++count;
                        context = AddToContext(context, item, count, 100, true);
                    }

                    #endregion

                    #region FaMS
                    var icount = 0;
                    foreach (DataRow dRow in famsData.Rows)
                    {
                        BDOLF_Consolidator item = new BDOLF_Consolidator();

                        item.SYSTEM = dRow["SYSTEM"].ToString().Trim();
                        item.RecordDate = Convert.ToDateTime(dRow["RecordDate"]);
                        item.Reason = (dRow["Reason"].ToString().Trim() == "" || dRow["Reason"].ToString().Trim() == "--") ? "" : dRow["Reason"].ToString().Trim();
                        item.RawFiles = (dRow["RawFiles"].ToString().Trim() == "" || dRow["RawFiles"].ToString().Trim() == "--") ? "" : dRow["RawFiles"].ToString().Trim();
                        item.isDeleted = Convert.ToBoolean(dRow["isDeleted"]);
                        item.UserName = (dRow["UserName"].ToString().Trim() == "" || dRow["UserName"].ToString().Trim() == "--") ? "" : dRow["UserName"].ToString().Trim();
                        item.TransDate = Convert.ToDateTime(dRow["TransDate"]);
                        item.isConsolidated = Convert.ToBoolean(dRow["isConsolidated"]);
                        item.AccountNo = (dRow["AccountNo"].ToString().Trim() == "" || dRow["AccountNo"].ToString().Trim() == "--") ? "" : dRow["AccountNo"].ToString().Trim();
                        item.ClientName = (dRow["ClientName"].ToString().Trim() == "" || dRow["ClientName"].ToString().Trim() == "--") ? "" : dRow["ClientName"].ToString().Trim();
                        item.AO = (dRow["AO"].ToString().Trim() == "" || dRow["AO"].ToString().Trim() == "--") ? "" : dRow["AO"].ToString().Trim();
                        item.StatusPerSystem = (dRow["StatusPerSystem"].ToString().Trim() == "" || dRow["StatusPerSystem"].ToString().Trim() == "--") ? "" : dRow["StatusPerSystem"].ToString().Trim();
                        item.ValueDate = Convert.ToDateTime(dRow["ValueDate"]);
                        item.MaturityDate = Convert.ToDateTime(dRow["MaturityDate"]);
                        item.TotalLoan = (dRow["TotalLoan"].ToString().Trim() == "" || dRow["TotalLoan"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(dRow["TotalLoan"]);
                        item.OB = (dRow["OB"].ToString().Trim() == "" || dRow["OB"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(dRow["OB"]);
                        item.MonthlyOB = (dRow["MonthlyOB"].ToString().Trim() == "" || dRow["MonthlyOB"].ToString().Trim() == "--") ? 0M : Convert.ToDecimal(dRow["MonthlyOB"]);
                        item.OriginalRate = (dRow["OriginalRate"].ToString().Trim() == "" || dRow["OriginalRate"].ToString().Trim() == "--") ? "" : dRow["OriginalRate"].ToString().Trim();
                        item.CurrentRate = (dRow["CurrentRate"].ToString().Trim() == "" || dRow["CurrentRate"].ToString().Trim() == "--") ? "" : dRow["CurrentRate"].ToString().Trim();
                        item.TermInMonths = dRow["TermInMonths"].ToString().Trim() == "" ? 0 : (int)Convert.ToDecimal(dRow["TermInMonths"]);
                        item.PerFaMSAAFICBSIndustryCode = dRow["PerFaMSAAFICBSIndustryCode"].ToString().Trim();
                        item.IndustryHeader = (dRow["IndustryHeader"].ToString().Trim() == "" || dRow["IndustryHeader"].ToString().Trim() == "--") ? "" : dRow["IndustryHeader"].ToString().Trim();
                        item.IndustryDetail = (dRow["IndustryDetail"].ToString().Trim() == "" || dRow["IndustryDetail"].ToString().Trim() == "--") ? "" : dRow["IndustryDetail"].ToString().Trim();
                        item.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(dRow["NextRateReviewDateExtractedPerFaMSAAFICBS"]);
                        item.PreviousMonthsNPLTaggingByRisk = (dRow["PreviousMonthsNPLTaggingByRisk"].ToString().Trim() == "" || dRow["PreviousMonthsNPLTaggingByRisk"].ToString().Trim() == "--") ? "" : dRow["PreviousMonthsNPLTaggingByRisk"].ToString().Trim();
                        item.SpecificRequiredProvisions = (dRow["SpecificRequiredProvisions"].ToString().Trim() == "" || dRow["SpecificRequiredProvisions"].ToString().Trim() == "--") ? "" : dRow["SpecificRequiredProvisions"].ToString().Trim();
                        item.GeneralRequiredProvisions = (dRow["GeneralRequiredProvisions"].ToString().Trim() == "" || dRow["GeneralRequiredProvisions"].ToString().Trim() == "--") ? "" : dRow["GeneralRequiredProvisions"].ToString().Trim();

                        ++count;
                        icount++;
                        context = AddToContext(context, item, count, 100, true);
                    }

                    #endregion
                    context.SaveChanges();
                }
                finally
                {
                    if (context != null)
                        context.Dispose();
                }

                scope.Complete();
            }
        }

        private NTCConn AddToContext(NTCConn context, BDOLF_Consolidator data, int count, int commitCount, bool recreateContext)
        {
            context.Set<BDOLF_Consolidator>().Add(data);

            if (count % commitCount == 0)
            {
                context.SaveChanges();
                if (recreateContext)
                {
                    context.Dispose();
                    context = context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
                    context.Configuration.AutoDetectChangesEnabled = false;
                }
            }
            return context;
        }

        public void BulkUpdete(object[] objdata)
        {
            throw new NotImplementedException();
        }

        public bool ConsoChecker(string keyword)
        {
            var parameter = DateTime.Today;
            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var query = context.BDOLF_Consolidator.Where(a => a.RecordDate < firstDayOfMonth).AsEnumerable().Any();
            return query;
        }

        public void DeleteConsolidator(string keyword)
        {
            var parameter = Convert.ToDateTime(keyword);

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

            var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable().ToList();

            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TimeSpan(2, 0, 0)))
            {
                try
                {
                    context.BDOLF_Consolidator.RemoveRange(query);
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.InnerException.Message.ToString().Trim() != "" ? ex.InnerException.Message.ToString().Trim() : "Insert Failed.!");
                }
                scope.Complete();
            }
        }

        public void DeleteConsolidator(int keyword)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_Consolidator> GetAll(string AsOfDate, string rptAsOfDate, bool isFrmRPT)
        {
            if (isFrmRPT)
            {
                var firstDayOfMonth = new DateTime(DateTime.Now.Year, Convert.ToInt32(rptAsOfDate), 1);
                var lastDayOfMonth = new DateTime(DateTime.Now.Year, Convert.ToInt32(rptAsOfDate), DateTime.DaysInMonth(DateTime.Now.Year, Convert.ToInt32(rptAsOfDate)));
                var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable();

                return query;
            }
            else
            {
                var firstDayOfMonth = new DateTime(DateTime.Now.Year, Convert.ToDateTime(AsOfDate).Month, 1);
                var lastDayOfMonth = new DateTime(DateTime.Now.Year, Convert.ToDateTime(AsOfDate).Month, DateTime.DaysInMonth(DateTime.Now.Year, Convert.ToDateTime(AsOfDate).Month));
                var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable();

                return query;
            }
        }

        public BDOLF_Consolidator GetByCode(BDOLF_Consolidator ntc)
        {
            var parameter = DateTime.Today;
            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
            var retval = context.BDOLF_Consolidator.Where(a => a.AccountNo == ntc.AccountNo && (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).FirstOrDefault();

            return retval;
        }

        public BDOLF_Consolidator GetByID(int keyword)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_Consolidator> GetTopOne()
        {
            var query = from data in context.BDOLF_Consolidator.OrderByDescending(t => t.TransDate).Take(1)
                        select data;

            return query;
        }

        public void DeleteInsertConsolidator(BDOLF_Consolidator gl, string keyword)
        {
            DeleteConsolidator(keyword);

            context.BDOLF_Consolidator.Add(gl);
        }

        public void Save()
        {
            throw new NotImplementedException();
        }

        public void TruncateTable()
        {
            throw new NotImplementedException();
        }

        public void UpdateConsolidator(BDOLF_Consolidator gl, string StatusPerSystem, string ProductDesc, string system, bool isInsert)
        {
            var parameter = DateTime.Today;
            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

            if (!isInsert)
            {
                var originalData = context.BDOLF_Consolidator.Where(a => a.AccountNo == gl.AccountNo && a.SYSTEM == gl.SYSTEM && (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable().ToList();

                originalData.ForEach(a =>
                                            {
                                                a.ICBSGLCode = gl.ICBSGLCode;
                                                a.ICBSGLName = gl.ICBSGLName;
                                            }
                                    );
                context.SaveChanges();
            }
            else
            {
                var originalData = context.BDOLF_Consolidator.Where(a => a.StatusPerSystem == StatusPerSystem && a.FacilityCode == ProductDesc && a.SYSTEM == system && (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable().ToList();

                originalData.ForEach(a =>
                                            {
                                                a.ICBSGLCode = gl.ICBSGLCode;
                                                a.ICBSGLName = gl.ICBSGLName;
                                            }
                                    );

                context.SaveChanges();
            }
        }

        public bool isGLCodeExist(string StatusPerSystem, string ProductDesc, string system)
        {
            var parameter = DateTime.Today;
            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
            var retval = context.BDOLF_Consolidator.Where(a => a.StatusPerSystem == StatusPerSystem.ToString().Trim().Trim() &&
                                                                a.FacilityCode == ProductDesc.ToString().Trim().Trim() &&
                                                                a.SYSTEM == system.ToString().Trim().Trim() &&
                                                                (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).Any();

            return retval;
        }

        public DataTable ExceptionReportBlankIndustryCode(string datefrm, string dateTo, string system)
        {
            //var qry = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= datefrm && a.RecordDate <= dateTo) && a.SYSTEM == system && (a.PerFaMSAAFICBSIndustryCode == null || a.PerFaMSAAFICBSIndustryCode == ""))
            //          select new
            //          {
            //              AccountNo = x.AccountNo,
            //              ClientName = x.ClientName,
            //              AO = x.AO,
            //              PerFaMSAAFICBSIndustryCode = x.PerFaMSAAFICBSIndustryCode,
            //              IndustryHeader = x.IndustryHeader,
            //              IndustryDetail = x.IndustryDetail,
            //          };


            DataTable dt = new DataTable();
            var sqlQuery = "SELECT  AccountNo, ClientName, AO,  PerFaMSAAFICBSIndustryCode, IndustryHeader, IndustryDetail " +
                                    "FROM[dbo].[BDOLF_Consolidator] " +
                                    "WHERE RecordDate BETWEEN '" + datefrm + "' AND '" + dateTo + "' " +
                                    "AND SYSTEM = '" + system + "' " +
                                    "AND(PerFaMSAAFICBSIndustryCode = '' OR PerFaMSAAFICBSIndustryCode = NULL)";

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }

            return dt;
        }

        public DataTable ExceptionReportZeroAssetSize(string datefrm, string dateTo, string system)
        {
            var cond = "";
            var param = "";
            var param1 = "";
            if (system == "AAF")
            {
                param = "PerFaMSAAFICBSAssetSizeInWords";
                param1 = "PerFaMSAAFICBSAssetSizeInWords = '0')";
                cond = param1;
            }
            else if (system == "ICBS")
            {
                param = "PerFaMSAAFICBSAssetSize";
                param1 = " = '' OR PerFaMSAAFICBSAssetSize = '0')";
                cond = param + param1;
            }
            //var qry = from x in context.BDOLF_Consolidator.Where(a => a.SYSTEM == system && (a.RecordDate >= datefrm && a.RecordDate <= dateTo) && (a.PerFaMSAAFICBSAssetSize == "" || a.PerFaMSAAFICBSAssetSize == "0" || a.PerFaMSAAFICBSAssetSizeInWords == null || a.PerFaMSAAFICBSAssetSizeInWords == ""))
            //          select new
            //          {
            //              AccountNo = x.AccountNo,
            //              ClientName = x.ClientName,
            //              AO = x.AO,
            //              PerFaMSAAFICBSAssetSize = x.PerFaMSAAFICBSAssetSizeInWords,
            //              // RPT = x.RPT
            //          };
            DataTable dt = new DataTable();
            var sqlQuery = "SELECT AccountNo, ClientName, AO, " + param + " as PerFaMSAAFICBSAssetSize " +
                           "FROM BDOLF_Consolidator " +
                           "WHERE SYSTEM = '" + system + "' " +
                           "AND RecordDate BETWEEN '" + datefrm + "' AND '" + dateTo + "' " +
                           "AND (" + param + " = '' OR " + cond;

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }
            return dt;
        }

        //public Array ExceptionReportZeroAssetSizeICBS(DateTime datefrm, DateTime dateTo, string system)
        //{
        //    var qry = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= datefrm && a.RecordDate <= dateTo) && a.SYSTEM == system && (a.PerFaMSAAFICBSAssetSize == "" || a.PerFaMSAAFICBSAssetSize == "0" || a.PerFaMSAAFICBSAssetSize == null))
        //              select new
        //              {
        //                  AccountNo = x.AccountNo,
        //                  ClientName = x.ClientName,
        //                  AO = x.AO,
        //                  PerFaMSAAFICBSAssetSize = x.PerFaMSAAFICBSAssetSize
        //              };

        //    return qry.ToArray();
        //}

        public DataTable ExceptionReportDosriTagging(string datefrm, string dateTo, string system)
        {
            var exceptionList = new List<string> { "1", "2", "3", "4", "5", "6", "7", "8", "9" };
            DataTable dt = new DataTable();
            //var qry = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= datefrm && a.RecordDate <= dateTo) && a.SYSTEM == system && (!exceptionList.Contains(a.RPT)))
            //          select new
            //          {
            //              AccountNo = x.AccountNo,
            //              ClientName = x.ClientName,
            //              AO = x.AO,
            //              RPT = x.RPT
            //          };

            //var final = from s in qry
            //            where !exceptionList.Contains(s.RPT)
            //            select s;

            var sqlQuery = "SELECT AccountNo, ClientName, AO, RPT " +
                            "FROM[dbo].[BDOLF_Consolidator] " +
                            "WHERE RecordDate BETWEEN '" + datefrm + "' AND '" + dateTo + "' " +
                            "AND SYSTEM = '" + system + "' " +
                            "AND RPT NOT IN ('1', '2', '3', '4', '5', '6', '7', '8', '9')";

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }

            return dt;
        }

        public DataTable ExceptionReportDifferenceInTaggingOfRriskAndGL(string datefrm, string dateTo, string system)
        {
            //var qry = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= datefrm && a.RecordDate <= dateTo) && a.SYSTEM == system && a.PreviousMonthsNPLTaggingByRisk != a.StatusPerSystem)
            //          select new
            //          {
            //              SYSTEM = x.SYSTEM,
            //              AccountNo = x.AccountNo,
            //              ClientName = x.ClientName,
            //              StatusPerSystem = x.StatusPerSystem,
            //              PreviousMonthsNPLTaggingByRisk = x.PreviousMonthsNPLTaggingByRisk
            //          };
            DataTable dt = new DataTable();

            var sqlQuery = "SELECT  SYSTEM, AccountNo, ClientName, StatusPerSystem, PreviousMonthsNPLTaggingByRisk " +
                            "FROM[dbo].[BDOLF_Consolidator]" +
                            "WHERE RecordDate BETWEEN '" + datefrm + "' AND '" + dateTo + "' " +
                             "AND SYSTEM = '" + system + "' " +
                            "AND PreviousMonthsNPLTaggingByRisk != StatusPerSystem";

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }

            return dt;
        }

        public Array GetDailyGL(DateTime datefrm, DateTime dateTo, string system)
        {

            var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= datefrm && a.CreatedDate <= dateTo))
                              select new
                              {
                                  GMACT = x.GMACT,
                                  GMCURC = x.GMCURC,
                                  GMCNTR = x.GMCNTR,
                                  GFEMO = x.GFEMO,
                                  GMFCYY = x.GMFCYY,
                                  GMNAME = x.GMNAME,
                                  GMYBAL = x.GMYBAL,
                                  GMCBAL = x.GMCBAL,
                                  GMEMO = x.GMEMO
                              };

            return DailyglData.ToArray();
        }

        public DataTable ExceptionReportSummaryReportSumOfOB(DateTime datefrm, DateTime dateTo, string system, string radio)
        {
            // List<object> values = new List<object>();
            DataTable dt = new DataTable();

            var param = "";
            var col = "";
            var group = "";
            var alias = "";
            var headergroup = "";

            if (radio.ToLower() == "daily")
            {
                param = " = '" + DateTime.Now.ToShortDateString() + "'";
                col = "SUM(a.GMCBAL) - a.OB Diff";
                group = "gl.GMCBAL";
                headergroup = "a.GMCBAL";
                alias = "GMCBAL";
            }
            else if (radio.ToLower() == "month end")
            {
                var parameter = DateTime.Today;

                var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

                param = "BETWEEN '" + firstDayOfMonth.ToShortDateString() + "' AND '" + lastDayOfMonth.ToShortDateString() + "'";
                col = "SUM(a.GMEMO) - a.OB Diff";
                group = "gl.GMEMO";
                headergroup = "a.GMEMO";
                alias = "GMEMO";
            }
            else if (radio.ToLower() == "year end")
            {
                int year = DateTime.Now.Year;
                int month = DateTime.Now.Month;
                int day = DateTime.Now.Day;

                var currentdate = new DateTime(year, month, day);
                var firstdayoftheyear = new DateTime(year, 1, 1);

                param = "BETWEEN '" + firstdayoftheyear.ToShortDateString() + "' AND '" + currentdate.ToShortDateString() + "'";
                col = "SUM(a.GMYBal) - a.OB Diff";
                group = "gl.GMYBal";
                headergroup = "a.GMYBal";
                alias = "GMYBal";
            }

            var sqlQuery = "SELECT a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.OB, SUM(" + headergroup + ") " + alias + ", " + col + " FROM ( " +
                            "SELECT c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, ISNULL(SUM(c.OB), 0.00) OB, " + group + " " +
                            "FROM BDOLF_Consolidator c " +
                            "INNER JOIN BDOLF_DailyGL gl ON gl.GMACT = c.ICBSGLCode " +
                            "WHERE gl.CreatedDate  " + param +
                            "GROUP BY c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, gl.GMACT, " + group + " ) a " +
                            "GROUP BY a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.OB " +
                            "ORDER BY a.SYSTEM";

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }

            #region MyRegion
            //if (radio.ToLower() == "daily")
            //{
            //    using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            //    {
            //        conn.Open();

            //        SqlCommand cmd = new SqlCommand(sqlQuery, conn);

            //        cmd.CommandType = CommandType.Text;
            //        using (SqlDataReader rdr = cmd.ExecuteReader())
            //        {
            //            dt.Load(rdr);
            //        }
            //    }

            //    #region MyRegion
            //    /*
            //           var conData = from x in context.BDOLF_Consolidator.Where(a => a.RecordDate == DateTime.Now)
            //                         group x by new
            //                         {
            //                             x.SYSTEM,
            //                             x.ICBSGLCode,
            //                             x.ICBSGLName
            //                         }
            //                         into g
            //                         select new
            //                         {
            //                             g.Key.ICBSGLCode,
            //                             g.Key.ICBSGLName,
            //                             g.Key.SYSTEM,
            //                             OB = g.Sum(x => x.OB)
            //                         };

            //           var DailyglData = from x in context.BDOLF_DailyGL.Where(a => a.CreatedDate == DateTime.Now)
            //                             select new
            //                             {
            //                                 GMACT = x.GMACT,
            //                                 GMCURC = x.GMCURC,
            //                                 GMCNTR = x.GMCNTR,
            //                                 GFEMO = x.GFEMO,
            //                                 GMFCYY = x.GMFCYY,
            //                                 GMNAME = x.GMNAME,
            //                                 GMYBAL = x.GMYBAL,
            //                                 GMCBAL = x.GMCBAL,
            //                                 GMEMO = x.GMEMO
            //                             };


            //           result = (from conquery in conData
            //                     join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //                     select new
            //                     {
            //                         conquery.SYSTEM,
            //                         conquery.ICBSGLCode,
            //                         conquery.ICBSGLName,
            //                         conquery.OB,
            //                         glquery.GMYBAL,
            //                         glquery.GMCBAL,
            //                         glquery.GMEMO,
            //                         glquery.GMACT,
            //                         glquery.GMNAME,
            //                         Diff = glquery.GMCBAL - conquery.OB
            //                     }).OrderByDescending(a => a.SYSTEM);

            //       foreach (object obj in result)
            //       {
            //           values.Add(obj);
            //       }
            //       */ 
            //    #endregion
            //}
            //else if (radio.ToLower() == "month end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, month, 1);

            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //                  into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      OB = g.Sum(x => x.OB)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //             join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //             select new
            //             {
            //                 conquery.SYSTEM,
            //                 conquery.ICBSGLCode,
            //                 conquery.ICBSGLName,
            //                 conquery.OB,
            //                 glquery.GMYBAL,
            //                 glquery.GMCBAL,
            //                 glquery.GMEMO,
            //                 glquery.GMACT,
            //                 glquery.GMNAME,
            //                 Diff = glquery.GMEMO - conquery.OB
            //             }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //}
            //else if (radio.ToLower() == "year end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, 1, 1);


            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //                 into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      OB = g.Sum(x => x.OB)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //             join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //             select new
            //             {
            //                 conquery.SYSTEM,
            //                 conquery.ICBSGLCode,
            //                 conquery.ICBSGLName,
            //                 conquery.OB,
            //                 glquery.GMYBAL,
            //                 glquery.GMCBAL,
            //                 glquery.GMEMO,
            //                 glquery.GMACT,
            //                 glquery.GMNAME,
            //                 Diff = glquery.GMYBAL - conquery.OB
            //             }).OrderByDescending(a => a.SYSTEM);


            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //} 
            #endregion

            return dt;
        }

        public DataTable ExceptionReportSummaryReportSumOfUDIBalance(DateTime datefrm, DateTime dateTo, string system, string radio)
        {
            // List<object> values = new List<object>();
            DataTable dt = new DataTable();

            var param = "";
            var col = "";
            var group = "";
            var alias = "";
            var headergroup = "";
            if (radio.ToLower() == "daily")
            {
                param = " = '" + DateTime.Now.ToShortDateString() + "'";
                col = "SUM(a.GMCBAL) - a.UDIBalance Diff";
                group = "gl.GMCBAL";
                alias = "GMCBAL";
                headergroup = "a.GMCBAL";
            }
            else if (radio.ToLower() == "month end")
            {
                var parameter = DateTime.Today;

                var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

                param = "BETWEEN '" + firstDayOfMonth.ToShortDateString() + "' AND '" + lastDayOfMonth.ToShortDateString() + "'";
                col = "SUM(a.GMEMO) - a.UDIBalance Diff";
                group = "gl.GMEMO";
                alias = "GMEMO";
                headergroup = "a.GMEMO";
            }
            else if (radio.ToLower() == "year end")
            {
                int year = DateTime.Now.Year;
                int month = DateTime.Now.Month;
                int day = DateTime.Now.Day;

                var currentdate = new DateTime(year, month, day);
                var firstdayoftheyear = new DateTime(year, 1, 1);

                param = "BETWEEN '" + firstdayoftheyear.ToShortDateString() + "' AND '" + currentdate.ToShortDateString() + "'";
                col = "SUM(a.GMYBal) - a.UDIBalance Diff";
                group = "gl.GMYBal";
                alias = "GMYBal";
                headergroup = "a.GMYBal";
            }
            var sqlQuery = "SELECT a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.UDIBalance, SUM(" + headergroup + ") " + alias + ", " + col + " FROM ( " +
                            "SELECT c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, ISNULL(SUM(c.UDIBalance), 0.00) UDIBalance, " + group + " " +
                            "FROM BDOLF_Consolidator c " +
                            "INNER JOIN BDOLF_DailyGL gl ON gl.GMACT = c.ICBSGLCode " +
                            "WHERE gl.CreatedDate  " + param +
                            "GROUP BY c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, gl.GMACT, " + group + " ) a " +
                            "GROUP BY a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.UDIBalance " +
                            "ORDER BY a.SYSTEM";

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }

            #region Old
            //List<object> values = new List<object>();
            //var result = (dynamic)null;
            //if (radio.ToLower() == "daily")
            //{
            //    var conData = from x in context.BDOLF_Consolidator.Where(a => a.RecordDate == DateTime.Now)
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //            into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      UDIBalance = g.Sum(x => x.UDIBalance)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => a.CreatedDate == DateTime.Now)
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.UDIBalance,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMCBAL - conquery.UDIBalance
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }
            //}
            //else if (radio.ToLower() == "month end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, month, 1);

            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //            into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      UDIBalance = g.Sum(x => x.UDIBalance)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= datefrm && a.CreatedDate <= dateTo))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.UDIBalance,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMEMO - conquery.UDIBalance
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }
            //}
            //else if (radio.ToLower() == "year end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, 1, 1);

            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //            into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      UDIBalance = g.Sum(x => x.UDIBalance)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.UDIBalance,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMYBAL - conquery.UDIBalance
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }
            //} 
            #endregion

            return dt;
        }

        public DataTable ExceptionReportSummaryReportSumOfPVRV(DateTime datefrm, DateTime dateTo, string system, string radio)
        {
            // List<object> values = new List<object>();
            DataTable dt = new DataTable();

            var param = "";
            var col = "";
            var group = "";
            var alias = "";
            var headergroup = "";
            if (radio.ToLower() == "daily")
            {
                param = " = '" + DateTime.Now.ToShortDateString() + "'";
                col = "SUM(a.GMCBAL) - a.PVRV Diff";
                group = "gl.GMCBAL";
                alias = "GMCBAL";
                headergroup = "a.GMCBAL";
            }
            else if (radio.ToLower() == "month end")
            {
                var parameter = DateTime.Today;

                var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

                param = "BETWEEN '" + firstDayOfMonth.ToShortDateString() + "' AND '" + lastDayOfMonth.ToShortDateString() + "'";
                col = "SUM(a.GMEMO) - a.PVRV Diff";
                group = "gl.GMEMO";
                alias = "GMEMO";
                headergroup = "a.GMEMO";
            }
            else if (radio.ToLower() == "year end")
            {
                int year = DateTime.Now.Year;
                int month = DateTime.Now.Month;
                int day = DateTime.Now.Day;

                var currentdate = new DateTime(year, month, day);
                var firstdayoftheyear = new DateTime(year, 1, 1);

                param = "BETWEEN '" + firstdayoftheyear.ToShortDateString() + "' AND '" + currentdate.ToShortDateString() + "'";
                col = "SUM(a.GMYBAL) - a.PVRV Diff";
                group = "gl.GMYBAL";
                alias = "GMYBAL";
                headergroup = "a.GMYBal";
            }
            var sqlQuery = "SELECT a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.FacilityCode, a.PVRV, SUM(" + headergroup + ") " + alias + ", " + col + " FROM ( " +
                            "SELECT c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, c.FacilityCode, ISNULL(SUM(c.PVRV), 0.00) PVRV, " + group + " " +
                            "FROM BDOLF_Consolidator c " +
                            "INNER JOIN BDOLF_DailyGL gl ON gl.GMACT = c.ICBSGLCode " +
                            "WHERE gl.CreatedDate  " + param +
                            "GROUP BY c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, c.FacilityCode, gl.GMACT, " + group + " ) a " +
                            "GROUP BY a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.PVRV, a.FacilityCode " +
                            "ORDER BY a.SYSTEM";

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }

            #region Old
            //List<object> values = new List<object>();
            //var result = (dynamic)null;
            //if (radio.ToLower() == "daily")
            //{
            //    var conData = from x in context.BDOLF_Consolidator.Where(a => a.RecordDate == DateTime.Now)
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName,
            //                      x.FacilityCode
            //                  }
            //             into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.FacilityCode,
            //                      g.Key.SYSTEM,
            //                      PVRV = g.Sum(x => x.PVRV)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => a.CreatedDate == DateTime.Now)
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.PVRV,
            //                  conquery.FacilityCode,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMCBAL - conquery.PVRV
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //}
            //else if (radio.ToLower() == "month end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, month, 1);

            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName,
            //                      x.FacilityCode
            //                  }
            //             into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.FacilityCode,
            //                      g.Key.SYSTEM,
            //                      PVRV = g.Sum(x => x.PVRV)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.PVRV,
            //                  conquery.FacilityCode,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMEMO - conquery.PVRV
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //}
            //else if (radio.ToLower() == "year end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, 1, 1);
            //    //var datestart = firstdayoftheyear;
            //    //var dateend = currentdate;

            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName,
            //                      x.FacilityCode
            //                  }
            //                 into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.FacilityCode,
            //                      g.Key.SYSTEM,
            //                      PVRV = g.Sum(x => x.PVRV)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.PVRV,
            //                  conquery.FacilityCode,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMYBAL - conquery.PVRV
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //} 
            #endregion
            return dt;
        }

        public DataTable ExceptionReportSummaryReportSumOfPVGD(DateTime datefrm, DateTime dateTo, string system, string radio)
        {
            // List<object> values = new List<object>();
            DataTable dt = new DataTable();

            var param = "";
            var col = "";
            var group = "";
            var alias = "";
            var headergroup = "";

            if (radio.ToLower() == "daily")
            {
                param = " = '" + DateTime.Now.ToShortDateString() + "'";
                col = "SUM(a.GMCBAL) - a.PVGD Diff";
                group = "gl.GMCBAL";
                alias = "GMCBAL";
                headergroup = "a.GMCBAL";
            }
            else if (radio.ToLower() == "month end")
            {
                var parameter = DateTime.Today;

                var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

                param = "BETWEEN '" + firstDayOfMonth.ToShortDateString() + "' AND '" + lastDayOfMonth.ToShortDateString() + "'";
                col = "SUM(a.GMEMO) - a.PVGD Diff";
                group = "gl.GMEMO";
                alias = "GMEMO";
                headergroup = "a.GMEMO";
            }
            else if (radio.ToLower() == "year end")
            {
                int year = DateTime.Now.Year;
                int month = DateTime.Now.Month;
                int day = DateTime.Now.Day;

                var currentdate = new DateTime(year, month, day);
                var firstdayoftheyear = new DateTime(year, 1, 1);

                param = "BETWEEN '" + firstdayoftheyear.ToShortDateString() + "' AND '" + currentdate.ToShortDateString() + "'";
                col = "SUM(a.GMYBAL) - a.PVGD Diff";
                group = "gl.GMYBAL";
                alias = "GMYBAL";
                headergroup = "a.GMYBal";
            }
            var sqlQuery = "SELECT a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.FacilityCode, a.PVGD, SUM(" + headergroup + ") " + alias + ", " + col + " FROM ( " +
                           "SELECT c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, c.FacilityCode, ISNULL(SUM(c.PVGD), 0.00) PVGD, " + group + " " +
                           "FROM BDOLF_Consolidator c " +
                           "INNER JOIN BDOLF_DailyGL gl ON gl.GMACT = c.ICBSGLCode " +
                           "WHERE gl.CreatedDate  " + param +
                           "GROUP BY c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, c.FacilityCode, gl.GMACT, " + group + " ) a " +
                           "GROUP BY a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.PVGD, a.FacilityCode " +
                           "ORDER BY a.SYSTEM";

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }

            #region Old
            //List<object> values = new List<object>();
            //var result = (dynamic)null;
            //if (radio.ToLower() == "daily")
            //{
            //    var conData = from x in context.BDOLF_Consolidator.Where(a => a.RecordDate == DateTime.Now)
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName,
            //                      x.FacilityCode
            //                  }
            //          into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.FacilityCode,
            //                      g.Key.SYSTEM,
            //                      PVGD = g.Sum(x => x.PVGD)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => a.CreatedDate == DateTime.Now)
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.PVGD,
            //                  conquery.FacilityCode,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMCBAL - conquery.PVGD
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //}
            //else if (radio.ToLower() == "month end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, month, 1);

            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName,
            //                      x.FacilityCode
            //                  }
            //          into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.FacilityCode,
            //                      g.Key.SYSTEM,
            //                      PVGD = g.Sum(x => x.PVGD)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.PVGD,
            //                  conquery.FacilityCode,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMEMO - conquery.PVGD
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //}
            //else if (radio.ToLower() == "year end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, 1, 1);
            //    //var datestart = firstdayoftheyear;
            //    //var dateend = currentdate;

            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName,
            //                      x.FacilityCode
            //                  }
            //              into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.FacilityCode,
            //                      g.Key.SYSTEM,
            //                      PVGD = g.Sum(x => x.PVGD)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= datefrm && a.CreatedDate <= dateTo))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.PVGD,
            //                  conquery.FacilityCode,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMYBAL - conquery.PVGD
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //} 
            #endregion
            return dt;
        }

        public DataTable ExceptionReportSummaryReportSumOfACCRUEDINTERESTRECEIVABLE(DateTime datefrm, DateTime dateTo, string system, string radio)
        {
            DataTable dt = new DataTable();

            var param = "";
            var col = "";
            var group = "";
            var alias = "";
            var headergroup = "";
            if (radio.ToLower() == "daily")
            {
                param = " = '" + DateTime.Now.ToShortDateString() + "'";
                col = "SUM(a.GMCBAL) - a.AccruedInterestReceivable Diff";
                group = "gl.GMCBAL";
                alias = "GMCBAL";
                headergroup = "a.GMCBAL";
            }
            else if (radio.ToLower() == "month end")
            {
                var parameter = DateTime.Today;

                var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

                param = "BETWEEN '" + firstDayOfMonth.ToShortDateString() + "' AND '" + lastDayOfMonth.ToShortDateString() + "'";
                col = "SUM(a.GMEMO) - a.AccruedInterestReceivable Diff";
                group = "gl.GMEMO";
                alias = "GMEMO";
                headergroup = "a.GMEMO";
            }
            else if (radio.ToLower() == "year end")
            {
                int year = DateTime.Now.Year;
                int month = DateTime.Now.Month;
                int day = DateTime.Now.Day;

                var currentdate = new DateTime(year, month, day);
                var firstdayoftheyear = new DateTime(year, 1, 1);

                param = "BETWEEN '" + firstdayoftheyear.ToShortDateString() + "' AND '" + currentdate.ToShortDateString() + "'";
                col = "SUM(a.GMYBAL) - a.AccruedInterestReceivable Diff";
                group = "gl.GMYBAL";
                alias = "GMYBAL";
                headergroup = "a.GMYBAL";
            }
            var sqlQuery = "SELECT a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.AccruedInterestReceivable, SUM(" + headergroup + ") " + alias + ", " + col + " FROM ( " +
                            "SELECT c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, ISNULL(SUM(c.AccruedInterestReceivable), 0.00) AccruedInterestReceivable, " + group + " " +
                            "FROM BDOLF_Consolidator c " +
                            "INNER JOIN BDOLF_DailyGL gl ON gl.GMACT = c.ICBSGLCode " +
                            "WHERE gl.CreatedDate  " + param +
                            "GROUP BY c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, gl.GMACT, " + group + " ) a " +
                            "GROUP BY a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.AccruedInterestReceivable " +
                            "ORDER BY a.SYSTEM";

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }

            #region Old
            //List<object> values = new List<object>();
            //var result = (dynamic)null;
            //if (radio.ToLower() == "daily")
            //{

            //    var conData = from x in context.BDOLF_Consolidator.Where(a => a.RecordDate == DateTime.Now)
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //                into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      AccruedInterestReceivable = g.Sum(x => x.AccruedInterestReceivable)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => a.CreatedDate == DateTime.Now)
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.AccruedInterestReceivable,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMCBAL - conquery.AccruedInterestReceivable
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //}
            //else if (radio.ToLower() == "month end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, month, 1);


            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //                into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      AccruedInterestReceivable = g.Sum(x => x.AccruedInterestReceivable)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.AccruedInterestReceivable,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMEMO - conquery.AccruedInterestReceivable
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //}
            //else if (radio.ToLower() == "year end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, 1, 1);
            //    //var datestart = firstdayoftheyear;
            //    //var dateend = currentdate;


            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //                into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      AccruedInterestReceivable = g.Sum(x => x.AccruedInterestReceivable)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.AccruedInterestReceivable,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMYBAL - conquery.AccruedInterestReceivable
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //} 
            #endregion
            return dt;
        }

        public DataTable ExceptionReportSummaryReportSumOfCLIENTEQUITY(DateTime datefrm, DateTime dateTo, string system, string radio)
        {
            DataTable dt = new DataTable();

            var param = "";
            var col = "";
            var group = "";
            var alias = "";
            var headergroup = "";
            if (radio.ToLower() == "daily")
            {
                param = " = '" + DateTime.Now.ToShortDateString() + "'";
                col = "SUM(a.GMCBAL) - a.ClientsEquity Diff";
                group = "gl.GMCBAL";
                alias = "GMCBAL";
                headergroup = "a.GMCBAL";
            }
            else if (radio.ToLower() == "month end")
            {
                var parameter = DateTime.Today;

                var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

                param = "BETWEEN '" + firstDayOfMonth.ToShortDateString() + "' AND '" + lastDayOfMonth.ToShortDateString() + "'";
                col = "SUM(a.GMEMO) - a.ClientsEquity Diff";
                group = "gl.GMEMO";
                alias = "GMEMO";
                headergroup = "a.GMEMO";
            }
            else if (radio.ToLower() == "year end")
            {
                int year = DateTime.Now.Year;
                int month = DateTime.Now.Month;
                int day = DateTime.Now.Day;

                var currentdate = new DateTime(year, month, day);
                var firstdayoftheyear = new DateTime(year, 1, 1);

                param = "BETWEEN '" + firstdayoftheyear.ToShortDateString() + "' AND '" + currentdate.ToShortDateString() + "'";
                col = "SUM(a.GMYBAL) - a.ClientsEquity Diff";
                group = "gl.GMYBAL";
                alias = "GMYBAL";
                headergroup = "a.GMYBAL";
            }
            var sqlQuery = "SELECT a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.ClientsEquity, SUM(" + headergroup + ") " + alias + ", " + col + " FROM ( " +
                           "SELECT c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, ISNULL(SUM(c.ClientsEquity), 0.00) ClientsEquity, " + group + " " +
                           "FROM BDOLF_Consolidator c " +
                           "INNER JOIN BDOLF_DailyGL gl ON gl.GMACT = c.ICBSGLCode " +
                           "WHERE gl.CreatedDate  " + param +
                           "GROUP BY c.ICBSGLCode, c.SYSTEM, c.ICBSGLName, gl.GMACT, " + group + " ) a " +
                           "GROUP BY a.ICBSGLCode, a.SYSTEM, a.ICBSGLName, a.ClientsEquity " +
                           "ORDER BY a.SYSTEM";

            NTCConn context = new NTCConn(ConnectionStringChanger.BuildConnectionString());
            using (SqlConnection conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sqlQuery, conn);

                cmd.CommandType = CommandType.Text;
                using (SqlDataReader rdr = cmd.ExecuteReader())
                {
                    dt.Load(rdr);
                }
                conn.Close();
            }

            #region Old

            //List<object> values = new List<object>();
            //var result = (dynamic)null;
            //if (radio.ToLower() == "daily")
            //{

            //    var conData = from x in context.BDOLF_Consolidator.Where(a => a.RecordDate == DateTime.Now)
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //              into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      ClientsEquity = g.Sum(x => x.ClientsEquity)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => a.CreatedDate == DateTime.Now)
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.ClientsEquity,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMYBAL - conquery.ClientsEquity
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }


            //}
            //else if (radio.ToLower() == "month end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, month, 1);


            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //              into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      ClientsEquity = g.Sum(x => x.ClientsEquity)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.ClientsEquity,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMEMO - conquery.ClientsEquity
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //}
            //else if (radio.ToLower() == "year end")
            //{
            //    int year = DateTime.Now.Year;
            //    int month = DateTime.Now.Month;
            //    int day = DateTime.Now.Day;

            //    var currentdate = new DateTime(year, month, day);
            //    var firstdayoftheyear = new DateTime(year, 1, 1);
            //    //var datestart = firstdayoftheyear;
            //    //var dateend = currentdate;


            //    var conData = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstdayoftheyear && a.RecordDate <= currentdate))
            //                  group x by new
            //                  {
            //                      x.SYSTEM,
            //                      x.ICBSGLCode,
            //                      x.ICBSGLName
            //                  }
            //              into g
            //                  select new
            //                  {
            //                      g.Key.ICBSGLCode,
            //                      g.Key.ICBSGLName,
            //                      g.Key.SYSTEM,
            //                      ClientsEquity = g.Sum(x => x.ClientsEquity)
            //                  };

            //    var DailyglData = from x in context.BDOLF_DailyGL.Where(a => (a.CreatedDate >= firstdayoftheyear && a.CreatedDate <= currentdate))
            //                      select new
            //                      {
            //                          GMACT = x.GMACT,
            //                          GMCURC = x.GMCURC,
            //                          GMCNTR = x.GMCNTR,
            //                          GFEMO = x.GFEMO,
            //                          GMFCYY = x.GMFCYY,
            //                          GMNAME = x.GMNAME,
            //                          GMYBAL = x.GMYBAL,
            //                          GMCBAL = x.GMCBAL,
            //                          GMEMO = x.GMEMO
            //                      };

            //    result = (from conquery in conData
            //              join glquery in DailyglData on conquery.ICBSGLCode equals glquery.GMACT
            //              select new
            //              {
            //                  conquery.SYSTEM,
            //                  conquery.ICBSGLCode,
            //                  conquery.ICBSGLName,
            //                  conquery.ClientsEquity,
            //                  glquery.GMYBAL,
            //                  glquery.GMCBAL,
            //                  glquery.GMEMO,
            //                  glquery.GMACT,
            //                  glquery.GMNAME,
            //                  Diff = glquery.GMYBAL - conquery.ClientsEquity
            //              }).OrderByDescending(a => a.SYSTEM);

            //    foreach (object obj in result)
            //    {
            //        values.Add(obj);
            //    }

            //} 
            #endregion

            return dt;
        }

        public Array Consolidator(DateTime datefrm, DateTime dateTo, string system)
        {
            var qry = from x in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= datefrm && a.RecordDate <= dateTo) && a.SYSTEM == system)
                      select new
                      {
                          SYSTEM = x.SYSTEM,
                          AccountNo = x.AccountNo,
                          ClientName = x.ClientName,
                          StatusPerSystem = x.StatusPerSystem,
                          PreviousMonthsNPLTaggingByRisk = x.PreviousMonthsNPLTaggingByRisk
                      };

            return qry.ToArray();
        }

        public Array CorrespondingGL(DateTime datefrm, DateTime dateTo, string system)
        {
            var qry = from x in context.BDOLF_CorrepondingGL.Where(a => (a.CreatedDate >= datefrm && a.CreatedDate <= dateTo) && a.System == system)
                      select new
                      {
                          SYSTEM = x.System

                      };

            return qry.ToArray();
        }

        public Array DailyGL(DateTime datefrm, DateTime dateTo, string system)
        {
            throw new NotImplementedException();
        }

        public Array ExchangeRate(DateTime datefrm, DateTime dateTo, string system)
        {
            throw new NotImplementedException();
        }

        public Array MigratedAccount(DateTime datefrm, DateTime dateTo, string system)
        {
            throw new NotImplementedException();
        }

        public Array PastDue(DateTime datefrm, DateTime dateTo, string system)
        {
            throw new NotImplementedException();
        }

        public Array QualifyingCapital(DateTime datefrm, DateTime dateTo, string system)
        {
            throw new NotImplementedException();
        }

        public Array UnderLitigation(DateTime datefrm, DateTime dateTo, string system)
        {
            throw new NotImplementedException();
        }

        public Array Summary(DateTime datefrm, DateTime dateTo, string system)
        {
            throw new NotImplementedException();
        }

        public string GetDate()
        {
            var parameter = DateTime.Today;

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
            var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).OrderByDescending(a => a.RecordDate).Take(1).Select(a => a.RecordDate);

            return query.ToString().Trim();
        }

        public string GetDate(string AsOfDate)
        {
            var parameter = DateTime.Today;
            var query = context.BDOLF_AppSettings.Where(x => x.appName == "NTCConsolidator" && x.param_name == AsOfDate).FirstOrDefault().param_value;
            return query.ToString().Trim() == "" ? parameter.ToShortDateString() : query.ToString().Trim();
        }
    }
}
