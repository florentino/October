﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Data;
using NTC_Consolidator.Model;
using System.Data.Entity;
using System.Transactions;

namespace NTC_Consolidator.Core.Repository
{
    public class CorrespondingGLRepository : ICorrespondingGLRepository, IDisposable
    {
        private NTCConn context;
        DbSet<CorrespondingGL> _bjectSet;

        public CorrespondingGLRepository(NTCConn context)
        {
            this.context = context;
            _bjectSet = context.Set<CorrespondingGL>();
        }

        public void DeleteCorrespondingGL(string GLCode)
        {
            try
            {
                BDOLF_CorrepondingGL gl = context.BDOLF_CorrepondingGL.Find(GLCode);
                context.BDOLF_CorrepondingGL.Remove(gl);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void DeleteCorrespondingGL()
        {
            throw new NotImplementedException();
        }

        public BDOLF_CorrepondingGL GetCorrespondingGLByID(string glCode, string ProdDesc, string StatusPerSys, string System)
        {
            try
            {
                return context.BDOLF_CorrepondingGL.Where(a => a.GLCode == glCode && a.Status == StatusPerSys && a.ProductDesc == ProdDesc && a.System == System).FirstOrDefault();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public BDOLF_CorrepondingGL GetCorrespondingGLByID(int glCode)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_CorrepondingGL> GetGL()
        {
            return context.Set<BDOLF_CorrepondingGL>().ToList();
        }

        public void InsertCorrespondingGL(BDOLF_CorrepondingGL gl)
        {
            try
            {
                context.BDOLF_CorrepondingGL.Add(gl);
                context.Set<BDOLF_CorrepondingGL>().Add(gl);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public void UpdateCorrespondingGL(BDOLF_CorrepondingGL glNew)
        {
            try
            {
                var glold = context.BDOLF_CorrepondingGL.Where(a => a.GLCode == glNew.GLCode && a.System == glNew.System).FirstOrDefault();

                glold.GLCode = glNew.GLCode;
                glold.GLName = glNew.GLName;

                context.Entry(glold).State = EntityState.Modified;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Save()
        {
            try
            {
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public bool GLCodeNotExists(string AccountNo)
        {
            throw new NotImplementedException();
        }
    }
}
