﻿using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Repository
{
    public class DailyGLRepository : IDailyGL, IDisposable
    {
        private NTCConn context;
        DbSet<BDOLF_DailyGL> _bjectSet;

        public DailyGLRepository(NTCConn context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_DailyGL>();
        }
        
        public IEnumerable<BDOLF_DailyGL> GetAll()
        {
            throw new NotImplementedException();
        }

        public BDOLF_DailyGL GetByAccountNo(int AccountNo)
        {
            throw new NotImplementedException();
        }

        public BDOLF_DailyGL GetByAccountNo(string AccountNo)
        {
            throw new NotImplementedException();
        }

        public void InsertRecord(BDOLF_DailyGL DailyGLData)
        {
            context.Set<BDOLF_DailyGL>().Add(DailyGLData);
            context.SaveChanges();
        }

        public void UpdateDailyGL(BDOLF_DailyGL DailyGLData)
        {
            throw new NotImplementedException();
        }

        public bool AccountNotExists(string AccountNo, string System)
        {
            throw new NotImplementedException();
        }

        public DateTime GetDate()
        {
            throw new NotImplementedException();
        }
        
        public void Save()
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public void DeleteGL(BDOLF_DailyGL GLData)
        {
            try
            {
                var parameter = Convert.ToDateTime(GLData.CreatedDate);

                var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

                var original = context.BDOLF_DailyGL.Where(a => a.CreatedDate >= firstDayOfMonth && a.CreatedDate <= lastDayOfMonth).AsEnumerable().ToList();

                context.BDOLF_DailyGL.RemoveRange(original);

                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}