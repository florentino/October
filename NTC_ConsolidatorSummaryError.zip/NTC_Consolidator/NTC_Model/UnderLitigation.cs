﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.NTC_Model
{
    public class UnderLitigation
    {
        private string _GLCode;

        private string _GLName;

        private string _AccountNo;

        public string AccountNo
        {
            get { return _AccountNo; }
            set { _AccountNo = value; }
        }

        public string GLName
        {
            get { return _GLName; }
            set { _GLName = value; }
        }

        public string GLCODE
        {
            get { return _GLCode; }
            set { _GLCode = value; }
        }
    }
}
