﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using NTC_Consolidator.NTC_Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmUnderLitigation : MetroFramework.Forms.MetroForm
    {
        #region Properties
        DataTable dtAaf;
        DataTable dtFams;
        DataTable dtupdated = new DataTable("Updated");
        DataTable dtinserted = new DataTable("Inserted");
        DataRow dru = null;
        DataRow dri = null;
        bool isNoData = false;
        bool _InValidDate = false;
        private static frmUnderLitigation litigationform = null;
        private ICorrespondingGLRepository correspondingGLRepository;
        private IUnderLitigation underLitigationRepository;
        string underLitigationFileName = "";
        private DateTime _underLitigationDateParameter;
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtunderLitigation;
        DataTable dtFromNTCRecords = new DataTable();
        string[] progressArray = new string[5]; 
        #endregion

        //Singleton
        public static frmUnderLitigation Instance()
        {
            if (litigationform == null)
            {
                litigationform = new frmUnderLitigation();
            }
            return litigationform;
        }

        public frmUnderLitigation()
        {
            InitializeComponent();
            this.underLitigationRepository = new UnderLitigationRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
            this.correspondingGLRepository = new CorrespondingGLRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
            lblBusy.Text = "";

            pnlWaitInfo.Location = new Point(
            this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
            this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            pnlSummary.Location = new Point(
           this.ClientSize.Width / 2 - pnlSummary.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlSummary.Size.Height / 2);
            pnlSummary.Visible = false;

            pnlInsertUpdate.Location = new Point(
          this.ClientSize.Width / 2 - pnlInsertUpdate.Size.Width / 2,
          this.ClientSize.Height / 2 - pnlInsertUpdate.Size.Height / 2);
            pnlInsertUpdate.Visible = false;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Please wait, While loading excel file.";
            lblWaitStatus.Text = "Status: Processing...";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlWaitInfo.Visible = true;

                NTCColumnNames();

                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }
        }

        private DataTable FaMSDataTable()
        {
            dtFams = new DataTable("FAMSDATA");

            dtFams.Columns.Add("system");
            dtFams.Columns.Add("recorddate");
            dtFams.Columns.Add("reason");
            dtFams.Columns.Add("rawfiles");
            dtFams.Columns.Add("isdeleted");
            dtFams.Columns.Add("username");
            dtFams.Columns.Add("transdate");
            dtFams.Columns.Add("isconsolidated");
            dtFams.Columns.Add("accountno");
            dtFams.Columns.Add("clientname");
            dtFams.Columns.Add("ao");
            dtFams.Columns.Add("statuspersystem");
            dtFams.Columns.Add("valuedate");
            dtFams.Columns.Add("maturitydate");
            dtFams.Columns.Add("totalloan");
            dtFams.Columns.Add("ob");
            dtFams.Columns.Add("monthlyob");
            dtFams.Columns.Add("clientsequity");
            dtFams.Columns.Add("accruedinterestreceivable");
            dtFams.Columns.Add("originalrate");
            dtFams.Columns.Add("currentrate");
            dtFams.Columns.Add("terminmonths");
            dtFams.Columns.Add("perfamsaaficbsindustrycode");
            dtFams.Columns.Add("industryheader");
            dtFams.Columns.Add("industrydetail");
            dtFams.Columns.Add("perfamsaaficbsassetsizeinwords");
            dtFams.Columns.Add("nextratereviewdateextractedperfamsaaficbs");
            dtFams.Columns.Add("previousmonthsnpltaggingbyrisk");
            dtFams.Columns.Add("specificrequiredprovisions");
            dtFams.Columns.Add("generalrequiredprovisions");

            var startRow = 0;
            DataRow dr = null;
            foreach (DataRow row in dtunderLitigation.Rows)
            {
                dr = dtAaf.NewRow();

                dr["system"] = "FAMS";
                dr["accountno"] = dtunderLitigation.Rows[startRow]["clientcode"].ToString();
                dr["clientname"] = dtunderLitigation.Rows[startRow]["clientname"].ToString();
                dr["ao"] = dtunderLitigation.Rows[startRow]["accountofficer"].ToString();
                dr["statuspersystem"] = dtunderLitigation.Rows[startRow]["status"].ToString();
                dr["valuedate"] = dtunderLitigation.Rows[startRow]["from"].ToString();
                dr["maturitydate"] = dtunderLitigation.Rows[startRow]["to"].ToString();
                dr["totalloan"] = dtunderLitigation.Rows[startRow]["investmentlimit"].ToString();
                dr["ob"] = dtunderLitigation.Rows[startRow]["receivables"].ToString();
                dr["monthlyob"] = dtunderLitigation.Rows[startRow]["receivables"].ToString();
                dr["clientsequity"] = dtunderLitigation.Rows[startRow]["clientsequityOfUnpaidInvoices"].ToString();
                dr["accruedinterestreceivable"] = dtunderLitigation.Rows[startRow]["discountChargeaccrual"].ToString();
                dr["originalrate"] = dtunderLitigation.Rows[startRow]["currentdc"].ToString();
                dr["currentrate"] = dtunderLitigation.Rows[startRow]["currentdc"].ToString();
                dr["terminmonths"] = dtunderLitigation.Rows[startRow]["creditterm"].ToString();
                dr["perfamsaaficbsindustrycode"] = dtunderLitigation.Rows[startRow]["industrycode"].ToString();
                dr["industryheader"] = dtunderLitigation.Rows[startRow]["industrydetailsdescription"].ToString();
                dr["industrydetail"] = dtunderLitigation.Rows[startRow]["industrydetailsdescription"].ToString();
                dr["perfamsaaficbsassetsizeinwords"] = dtunderLitigation.Rows[startRow]["sizeoffirmassetsize"].ToString();
                dr["nextratereviewdateextractedperfamsaaficbs"] = dtunderLitigation.Rows[startRow]["reviewdate"].ToString();
                dr["previousmonthsnpltaggingbyrisk"] = "";
                dr["specificrequiredprovisions"] = "";
                dr["generalrequiredprovisions"] = "";
                dr["recorddate"] = _underLitigationDateParameter;
                //dr["reason"] = "";
                dr["rawfiles"] = txtFilePath.Text;
                //dr["isDeleted"] = false;
                //dr["isConsolidated"] = true;
                dr["UserName"] = frmConsolidator.UserName;
                dr["transdate"] = DateTime.Now.ToShortDateString();

            }
            return dtFams;
        }

        private DataTable AAFDataTable()
        {
            dtAaf = new DataTable("AAFDATA");

            dtAaf.Columns.Add("system");
            dtAaf.Columns.Add("accountno");
            dtAaf.Columns.Add("clientname");
            dtAaf.Columns.Add("ao");
            dtAaf.Columns.Add("facilitycode");
            dtAaf.Columns.Add("statuspersystem");
            dtAaf.Columns.Add("valuedate");
            dtAaf.Columns.Add("firstduedate");
            dtAaf.Columns.Add("maturitydate");
            dtAaf.Columns.Add("totalloan");
            dtAaf.Columns.Add("ob");
            dtAaf.Columns.Add("monthlyob");
            dtAaf.Columns.Add("udibalance");
            dtAaf.Columns.Add("origerv");
            dtAaf.Columns.Add("pvrv");
            dtAaf.Columns.Add("origgd");
            dtAaf.Columns.Add("pvgd");
            dtAaf.Columns.Add("originalrate");
            dtAaf.Columns.Add("currentrate");
            dtAaf.Columns.Add("terminmonths");
            dtAaf.Columns.Add("remainingterminmonths");
            dtAaf.Columns.Add("originalamortizationaaf");
            dtAaf.Columns.Add("paymentscheduleamortizationaaf");
            dtAaf.Columns.Add("repriceddate");
            dtAaf.Columns.Add("aaficbsratetype");
            dtAaf.Columns.Add("repricedamortization");
            dtAaf.Columns.Add("pastduedateitldateextractedperaaficbs");
            dtAaf.Columns.Add("perfamsaaficbsindustrycode");
            dtAaf.Columns.Add("industryheader");
            dtAaf.Columns.Add("industrydetail");
            dtAaf.Columns.Add("collateral");
            dtAaf.Columns.Add("perfamsaaficbsassetsizeinwords");
            dtAaf.Columns.Add("icbsglcode");
            dtAaf.Columns.Add("icbsglname");
            dtAaf.Columns.Add("costcenter");
            dtAaf.Columns.Add("branchnameofcostcenterpersystem");
            dtAaf.Columns.Add("originatingbranchbooked");
            dtAaf.Columns.Add("nationalitypericbs");
            dtAaf.Columns.Add("nextratereviewdateextractedperfamsaaficbs");
            dtAaf.Columns.Add("taxid");
            dtAaf.Columns.Add("customertypedescription");
            dtAaf.Columns.Add("relcode");
            dtAaf.Columns.Add("reecode");
            dtAaf.Columns.Add("reeaddtlinfo");
            dtAaf.Columns.Add("acctref");
            dtAaf.Columns.Add("rpt");
            dtAaf.Columns.Add("assetcost");
            dtAaf.Columns.Add("leasetype");
            dtAaf.Columns.Add("icbscollateralcode");
            dtAaf.Columns.Add("assetvalue");
            dtAaf.Columns.Add("approvedamount");
            dtAaf.Columns.Add("cpnumber");
            dtAaf.Columns.Add("lastprincipalpay");
            dtAaf.Columns.Add("principalpaydate");
            dtAaf.Columns.Add("lastinterestpay");
            dtAaf.Columns.Add("lastinterestpaydate");
            dtAaf.Columns.Add("previousmonthsnpltaggingbyrisk");
            dtAaf.Columns.Add("specificrequiredprovisions");
            dtAaf.Columns.Add("generalrequiredprovisions");

            var startRow = 0;
            DataRow dr = null;
            foreach (DataRow row in dtunderLitigation.Rows)
            {
                dr = dtAaf.NewRow();

                dr["system"] = "AAF";
                dr["accountno"] = dtunderLitigation.Rows[startRow]["accountno"].ToString();
                dr["clientname"] = dtunderLitigation.Rows[startRow]["clientname"].ToString();
                dr["ao"] = dtunderLitigation.Rows[startRow]["ao"].ToString();
                dr["facilitycode"] = dtunderLitigation.Rows[startRow]["facilitycode"].ToString();
                dr["statuspersystem"] = dtunderLitigation.Rows[startRow]["statuspersystem"].ToString();
                dr["valuedate"] = dtunderLitigation.Rows[startRow]["valuedate"].ToString();
                dr["firstduedate"] = dtunderLitigation.Rows[startRow]["firstduedate"].ToString();
                dr["maturitydate"] = dtunderLitigation.Rows[startRow]["maturitydate"].ToString();
                dr["totalloan"] = dtunderLitigation.Rows[startRow]["totalloan"].ToString();
                dr["ob"] = dtunderLitigation.Rows[startRow]["ob"].ToString();
                dr["monthlyob"] = dtunderLitigation.Rows[startRow]["monthlyob"].ToString();
                dr["udibalance"] = dtunderLitigation.Rows[startRow]["udibalance"].ToString();
                dr["origerv"] = dtunderLitigation.Rows[startRow]["origerv"].ToString();
                dr["pvrv"] = dtunderLitigation.Rows[startRow]["pvrv"].ToString();
                dr["origgd"] = dtunderLitigation.Rows[startRow]["origgd"].ToString();
                dr["pvgd"] = dtunderLitigation.Rows[startRow]["pvgd"].ToString();
                dr["originalrate"] = dtunderLitigation.Rows[startRow]["originalrate"].ToString();
                dr["currentrate"] = dtunderLitigation.Rows[startRow]["currentrate"].ToString();
                dr["terminmonths"] = dtunderLitigation.Rows[startRow]["terminmonths"].ToString();
                dr["remainingterminmonths"] = dtunderLitigation.Rows[startRow]["remainingterminmonths"].ToString();
                dr["originalamortizationaaf"] = dtunderLitigation.Rows[startRow]["originalamortizationaaf"].ToString();
                dr["paymentscheduleamortizationaaf"] = dtunderLitigation.Rows[startRow]["paymentscheduleamortizationaaf"].ToString();
                dr["repriceddate"] = dtunderLitigation.Rows[startRow]["repriceddate"].ToString();
                dr["aaficbsratetype"] = dtunderLitigation.Rows[startRow]["aaficbsratetype"].ToString();
                dr["repricedamortization"] = dtunderLitigation.Rows[startRow]["repricedamortization"].ToString();
                dr["pastduedateitldateextractedperaaficbs"] = dtunderLitigation.Rows[startRow]["pastduedateitldateextractedperaaficbs"].ToString();
                dr["perfamsaaficbsindustrycode"] = dtunderLitigation.Rows[startRow]["perfamsaaficbsindustrycode"].ToString();
                dr["industryheader"] = dtunderLitigation.Rows[startRow]["industryheader"].ToString();
                dr["industrydetail"] = dtunderLitigation.Rows[startRow]["industrydetail"].ToString();
                dr["collateral"] = dtunderLitigation.Rows[startRow]["collateral"].ToString();
                dr["perfamsaaficbsassetsizeinwords"] = dtunderLitigation.Rows[startRow]["perfamsaaficbsassetsizeinwords"].ToString();
                dr["icbsglcode"] = dtunderLitigation.Rows[startRow]["icbsglcode"].ToString();
                dr["icbsglname"] = dtunderLitigation.Rows[startRow]["icbsglname"].ToString();
                dr["costcenter"] = dtunderLitigation.Rows[startRow]["costcenter"].ToString();
                dr["branchnameofcostcenterpersystem"] = dtunderLitigation.Rows[startRow]["branchnameofcostcenterpersystem"].ToString();
                dr["originatingbranchbooked"] = dtunderLitigation.Rows[startRow]["originatingbranchbooked"].ToString();
                dr["nationalitypericbs"] = dtunderLitigation.Rows[startRow]["nationalitypericbs"].ToString();
                dr["nextratereviewdateextractedperfamsaaficbs"] = dtunderLitigation.Rows[startRow]["nextratereviewdateextractedperfamsaaficbs"].ToString();
                dr["taxid"] = dtunderLitigation.Rows[startRow]["taxid"].ToString();
                dr["customertypedescription"] = dtunderLitigation.Rows[startRow]["customertypedescription"].ToString();
                dr["relcode"] = dtunderLitigation.Rows[startRow]["relcode"].ToString();
                dr["reecode"] = dtunderLitigation.Rows[startRow]["reecode"].ToString();
                dr["reeaddtlinfo"] = dtunderLitigation.Rows[startRow]["reeaddtlinfo"].ToString();
                dr["acctref"] = dtunderLitigation.Rows[startRow]["acctref"].ToString();
                dr["rpt"] = dtunderLitigation.Rows[startRow]["rpt"].ToString();
                dr["assetcost"] = dtunderLitigation.Rows[startRow]["assetcost"].ToString();
                dr["leasetype"] = dtunderLitigation.Rows[startRow]["leasetype"].ToString();
                dr["icbscollateralcode"] = dtunderLitigation.Rows[startRow]["icbscollateralcode"].ToString();
                dr["assetvalue"] = dtunderLitigation.Rows[startRow]["assetvalue"].ToString();
                dr["approvedamount"] = dtunderLitigation.Rows[startRow]["approvedamount"].ToString();
                dr["cpnumber"] = dtunderLitigation.Rows[startRow]["cpnumber"].ToString();
                dr["lastprincipalpay"] = dtunderLitigation.Rows[startRow]["lastprincipalpay"].ToString();
                dr["principalpaydate"] = dtunderLitigation.Rows[startRow]["principalpaydate"].ToString();
                dr["lastinterestpay"] = dtunderLitigation.Rows[startRow]["lastinterestpay"].ToString();
                dr["lastinterestpaydate"] = dtunderLitigation.Rows[startRow]["lastinterestpaydate"].ToString();
                dr["previousmonthsnpltaggingbyrisk"] = dtunderLitigation.Rows[startRow]["previousmonthsnpltaggingbyrisk"].ToString();
                dr["specificrequiredprovisions"] = dtunderLitigation.Rows[startRow]["specificrequiredprovisions"].ToString();
                dr["generalrequiredprovisions"] = dtunderLitigation.Rows[startRow]["generalrequiredprovisions"].ToString();
                //dr["reason"] = "";
                dr["rawfiles"] = txtFilePath.Text;
                //dr["isDeleted"] = false;
                //dr["isConsolidated"] = true;
                dr["UserName"] = frmConsolidator.UserName;
                dr["transdate"] = DateTime.Now.ToShortDateString();
                dr["recorddate"] = _underLitigationDateParameter;
            }

            return dtAaf;
        }

        private void frmUnderLitigation_Load(object sender, EventArgs e)
        {
            if (txtFilePath.Text == "") btnExecute.Enabled = false;

            btnExecute.Enabled = dtFromNTCRecords.Rows.Count > 0 ? true : false;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            dtupdated = new DataTable("Updated");
            dtinserted = new DataTable("Inserted");

            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Initializing, Please wait...";
            lblWaitStatus.Text = "Status: Initializing...";

            ListItem();
            _underLitigationDateParameter = Program.NTC_DateFrom != "" ? Convert.ToDateTime(Program.NTC_DateFrom) : Convert.ToDateTime("01/01/9001");

            saveWorker = new BackgroundWorker();
            saveWorker.WorkerReportsProgress = true;
            saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
            saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
            saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
            saveWorker.WorkerSupportsCancellation = true;
            saveWorker.RunWorkerAsync();
        }

        #region Load NTC Record 

        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";
            lblWaitInfo.Text = labelsreports[1];
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                //IsBusy = false;
                if (isNoData)
                {
                    isNoData = false;
                    MetroMessageBox.Show(this, "\r\n\r\nUnder Litigation excel files contains no data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                if (_InValidDate)
                {
                    MetroMessageBox.Show(this, "\r\nInvalid date was detected by the system, Please check all the date format.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                return;
            }
            else if (e.Error != null)
            {
                // IsBusy = false;
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else if (e.Error.ToString().Contains("External table is not in the expected format"))
                {
                    MetroMessageBox.Show(this, "\r\nPlease save first the file with the extension name of \".xls\".\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else
                {
                    MetroMessageBox.Show(this, "Error Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while reading the files, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                pnlWaitInfo.Visible = false;
                return;
            }
            else
            {
                if (ErrorLog.CountError() > 0)
                {
                    retrieveWorker.Dispose();

                    DialogResult diag = MetroMessageBox.Show(this, "\r\nValidation Error has been completed. " + ErrorLog.CountError().ToString() + " Error(s) found. Kindly review the errors log. \r\nClick OK Button to open the Notepad.", "Error Found", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    if (diag == DialogResult.OK)
                    {
                        ErrorLog.GetLogFilePath();
                    }
                    return;
                }
                else
                {
                    dtFromNTCRecords.DefaultView.RowFilter = "SYSTEM <> 'ICBS'";

                    dgvAccountUnderLit.DataSource = dtFromNTCRecords.DefaultView.ToTable();// dtFromNTCRecords;
                    dgvAccountUnderLit.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                    lblInfo.Text = "Total Records: " + string.Format("{0:n0}", dtFromNTCRecords.DefaultView.ToTable().Rows.Count);
                    FaMSDataTable();
                    AAFDataTable();
                    pnlWaitInfo.Visible = false;
                    btnExecute.Enabled = dtFromNTCRecords.Rows.Count > 0 ? true : false;
                }
            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                var invalidExcel = false;
                string connString = "";

                if (Path.GetExtension(txtFilePath.Text) == ".xls")
                    connString = string.Format("Provider = Microsoft.Jet.OLEDB.4.0;Data Source={0};" + "Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);

                if (Path.GetExtension(txtFilePath.Text) == ".xlsx")
                {
                    MetroMessageBox.Show(this, "\r\nPlease change the file format from XLSX to XLS.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                underLitigationFileName = Path.GetFileName(txtFilePath.Text);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();
                    
                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM[" + worksheetname + "] WHERE[F1] <> ''", conn);
                    DataTable dtold = new DataTable(worksheetname);
                    da.Fill(dtold);

                    if (dtold.Rows.Count <= 0)
                    {
                        if (retrieveWorker.IsBusy)
                        {
                            isNoData = true;
                            e.Cancel = true;
                            retrieveWorker.CancelAsync();
                        }
                    }
                    else
                    {
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);
                        
                        //Convert Row 3 value as a header of the DataTable
                        foreach (DataColumn dc in dtold.Columns)
                        {
                            if (dtold.Rows[0][dc].ToString().ToUpper() != "")
                            {
                                var hName = dtold.Rows[0][dc].ToString().Trim().ToUpper();
                                
                                dc.ColumnName = hName;
                            }
                        }
                        dtold.Rows.RemoveAt(0);

                        dtFromNTCRecords = dtold;

                        var requiredColumns = new HashSet<string>
                        {
                          #region Column Name For NTC
                            "SYSTEM",
                            "ACCOUNT NO",
                            "CLIENT NAME",
                            "AO",
                            "FACILITY CODE",
                            "STATUS PER SYSTEM",
                            "VALUE DATE",
                            "FIRST DUE DATE",
                            "MATURITY DATE",
                            "TOTAL LOAN",
                            "OB",
                            "MONTHLY OB",
                            "UDI BALANCE",
                            "CLIENTS EQUITY",
                            "ACCRUED INTEREST RECEIVABLE",
                            "ORIG ERV",
                            "PVRV",
                            "PVGD",
                            "ORIG GD",
                            "TOTAL LOAN PORTFOLIO",
                            "NTC",
                            "ORIGINAL RATE",
                            "CURRENT RATE",
                            "TERM IN MONTHS",
                            "REMAINING TERM IN MONTHS",
                            "ORIGINAL AMORTIZATION AAF",
                            "PAYMENT SCHEDULE AMORTIZATION AAF",
                            "REPRICED DATE",
                            "AAFICBSRATE TYPE",
                            "REPRICED AMORTIZATION",
                            "PAST DUE DATE ITLDATE EXTRACTED PER AAFICBS",
                            "PER FAMS AAF ICBS INDUSTRY CODE",
                            "INDUSTRY HEADER",
                            "INDUSTRY DETAIL",
                            "COLLATERAL",
                            "PER FAMS AAF ICBS ASSET SIZE",
                            "PER FAMS AAF ICBS ASSET SIZE IN WORDS",
                            "ICBS GLCODE",
                            "ICBS GLNAME",
                            "COST CENTER",
                            "BRANCH NAME OF COST CENTER PER SYSTEM",
                            "STATUS PER GL",
                            "ORIGINATING BRANCH BOOKED",
                            "NATIONALITY PER ICBS",
                            "NEXT RATE REVIEW DATE EXTRACTED PER FAMS AAF ICBS",
                            "TAX ID",
                            "LOAN PURPOSE CODE",
                            "MATURITY TYPE CODE",
                            "BANK RELATIONSHIP",
                            "SYNDICATED LOAN IND",
                            "CUSTOMER TYPE DESCRIPTION",
                            "REL CODE",
                            "REE CODE",
                            "REE ADDTL INFO",
                            "ACCT REF",
                            "RPT",
                            "ASSET COST",
                            "LEASE TYPE",
                            "PROVISIONING",
                            "MATRIX",
                            "REMARKS",
                            "ICBS COLLATERAL CODE",
                            "ASSET VALUE",
                            "APPROVED AMOUNT",
                            "CP NUMBER",
                            "LAST PRINCIPAL PAY",
                            "PRINCIPAL PAY DATE",
                            "LAST INTEREST PAY",
                            "LAST INTEREST PAY DATE",
                            "PREVIOUS MONTHS NPL TAGGING BY RISK",
                            "SPECIFIC REQUIRED PROVISIONS",
                            "GENERAL REQUIRED PROVISIONS"

	#endregion
                        };
                        for (int i = 0; i < dtold.Columns.Count; i++)
                        {
                            string colname = dtold.Columns[i].ColumnName.ToString().ToUpper();
                            //var NewHeader = Regex.Replace(colname, @"([^a-zA-Z0-9]|^\s)", string.Empty);

                            if (!requiredColumns.Contains(colname.Trim()))
                            {
                                invalidExcel = true;
                                ErrorLog.AddError(colname.Trim().ToUpper() + " column name is not found.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Update NTC Records

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitStatus.Text = labelsreports[2].ToString();
            lblWaitInfo.Text = labelsreports[1].ToString();
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                lblWaitStatus.Text = "Status: Error Encountered while processing";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "Error Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while saving the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                return;
            }
            else
            {
                if (ErrorLog.CountError() > 0)
                {
                    retrieveWorker.Dispose();
                    saveWorker.Dispose();

                    DialogResult diag = MetroMessageBox.Show(this, "\r\nValidation Error has been completed. " + ErrorLog.CountError().ToString() + " Error(s) found. Kindly review the errors log. \r\nClick OK Button to open the Notepad.", "Error Found", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    if (diag == DialogResult.OK)
                    {
                        ErrorLog.GetLogFilePath();
                    }
                    return;
                }
                else
                {
                    pnlSummary.Visible = false;
                    pnlWaitInfo.Visible = false;
                    lblWaitInfo.Text = "DONE";
                    lblWaitStatus.Text = "Status: Success";

                    //dtupdated = new DataTable("Updated");
                    //dtinserted = new DataTable("Inserted");

                    DialogResult responseMsg = MetroMessageBox.Show(this, "\r\nData was successfully added.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    if (responseMsg.Equals(DialogResult.OK))
                    {
                        pnlSummary.Visible = true;

                        dtFromNTCRecords.DefaultView.RowFilter = "SYSTEM <> 'ICBS'";

                        lnkDetailsUpdated.Text = dtupdated.Rows.Count.ToString() + " " + "out of " + dtFromNTCRecords.DefaultView.ToTable().Rows.Count.ToString(); //dtFromNTCRecords.Rows.Count.ToString();
                        lnkDetailsInserted.Text = dtinserted.Rows.Count.ToString() + " " + "out of " + dtFromNTCRecords.DefaultView.ToTable().Rows.Count.ToString(); //dtFromNTCRecords.Rows.Count.ToString();
                    }
                }
            }
        }
        
        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var iCount = 1;
            try
            {
                foreach (DataRow dritem in dtFromNTCRecords.Rows)
                {
                    try
                    {
                        BDOLF_Consolidator data = new BDOLF_Consolidator();

                        if (dritem["SYSTEM"].ToString().Trim() != "ICBS")
                        {
                            #region Data
                            progressArray[0] = (iCount * 100 / dtFromNTCRecords.Rows.Count).ToString(); // percent
                            progressArray[1] = "Validating AccountNo, Please wait..."; //header text
                            progressArray[2] = "Status: Updating the record, Please wait...";// for the AccountNo: " + dritem["AccountNo"].ToString(); //Status
                            progressArray[3] = "";// i.ToString(); //column
                            progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                            data.RawFiles = underLitigationFileName.ToString();
                            data.isConsolidated = true;
                            data.isDeleted = false;
                            data.UserName = frmConsolidator.UserName;
                            data.TransDate = DateTime.Today;
                            data.RecordDate = _underLitigationDateParameter;
                            data.SYSTEM = dritem["SYSTEM"].ToString().Trim() == "" ? "" : dritem["SYSTEM"].ToString().Trim();
                            data.AccountNo = dritem["Account No"].ToString().Trim() == "" ? "" : dritem["Account No"].ToString().Trim();
                            data.ClientName = dritem["Client Name"].ToString().Trim() == "" ? "" : dritem["Client Name"].ToString().Trim();
                            data.AO = dritem["AO"].ToString().Trim() == "" ? "" : dritem["AO"].ToString().Trim();
                            data.FacilityCode = dritem["Facility Code"].ToString().Trim() == "" ? "" : dritem["Facility Code"].ToString().Trim();
                            data.StatusPerSystem = dritem["Status Per System"].ToString().Trim() == "" ? "" : dritem["Status Per System"].ToString().Trim();

                            if (!isValidDate(dritem["Value Date"].ToString().Trim()))
                            {
                                data.ValueDate = Convert.ToDateTime("01/01/1900");
                            }
                            else
                            {
                                data.ValueDate = Convert.ToDateTime(dritem["Value Date"]);
                            }

                            if (!isValidDate(dritem["First Due Date"].ToString().Trim()))
                            {
                                data.FirstDueDate = Convert.ToDateTime("01/01/1900");
                            }
                            else
                            {
                                data.FirstDueDate = Convert.ToDateTime(dritem["First Due Date"]);
                            }

                            if (!isValidDate(dritem["Maturity Date"].ToString().Trim()))
                            {
                                data.MaturityDate = Convert.ToDateTime("01/01/1900");
                            }
                            else
                            {
                                data.MaturityDate = Convert.ToDateTime(dritem["Maturity Date"]);
                            }

                            data.TotalLoan = Convert.ToDecimal(dritem["Total Loan"].ToString().Trim() == "" ? 0.00 : dritem["Total Loan"]);
                            data.OB = Convert.ToDecimal(dritem["OB"].ToString().Trim() == "" ? 0.00 : dritem["OB"]);
                            data.MonthlyOB = Convert.ToDecimal(dritem["Monthly OB"].ToString().Trim() == "" ? 0.00 : dritem["Monthly OB"]);
                            data.UDIBalance = Convert.ToDecimal(dritem["UDI Balance"].ToString().Trim() == "" ? 0.00 : dritem["UDI Balance"]);
                            data.ClientsEquity = Convert.ToDecimal(dritem["Clients Equity"].ToString().Trim() == "" ? 0.00 : dritem["Clients Equity"]);
                            data.AccruedInterestReceivable = Convert.ToDecimal(dritem["Accrued Interest Receivable"].ToString().Trim() == "" ? 0.00 : dritem["Accrued Interest Receivable"]);
                            data.OrigERV = Convert.ToDecimal(dritem["Orig ERV"].ToString().Trim() == "" ? 0.00 : dritem["Orig ERV"]);
                            data.PVRV = Convert.ToDecimal(dritem["PVRV"].ToString().Trim() == "" ? 0.00 : dritem["PVRV"]);
                            data.OrigGD = Convert.ToDecimal(dritem["Orig GD"].ToString().Trim() == "" ? 0.00 : dritem["Orig GD"]);
                            data.PVGD = Convert.ToDecimal(dritem["PVGD"].ToString().Trim() == "" ? 0.00 : dritem["PVGD"]);
                            data.TotalLoanPortfolio = Convert.ToDecimal(dritem["Total Loan Portfolio"].ToString().Trim() == "" ? 0.00 : dritem["Total Loan Portfolio"]);
                            data.NTC = dritem["NTC"].ToString().Trim() == "" ? "" : dritem["NTC"].ToString().Trim();
                            data.OriginalRate = dritem["Original Rate"].ToString().Trim();
                            data.CurrentRate = dritem["Current Rate"].ToString().Trim();
                            data.TermInMonths = Convert.ToInt32(dritem["Term in months"].ToString().Trim() == "" ? "0" : dritem["Term in months"]);
                            data.RemainingTermInMonths = Convert.ToInt32(dritem["Remaining Term in months"].ToString().Trim() == "" ? 0 : dritem["Remaining Term in months"]);
                            data.OriginalAmortizationAAF = dritem["Original Amortization AAF"].ToString().Trim();

                            data.PaymentScheduleAmortizationAAF = Convert.ToDecimal(dritem["Payment Schedule Amortization AAF"].ToString().Trim() == "" ? 0.00 : dritem["Payment Schedule Amortization AAF"]);

                            if (!isValidDate(dritem["Repriced Date"].ToString().Trim()))
                            {
                                data.RepricedDate = Convert.ToDateTime("01/01/1900");
                            }
                            else
                            {
                                data.RepricedDate = Convert.ToDateTime(dritem["Repriced Date"]);
                            }

                            data.AAFICBSRateType = dritem["AAFICBSRate Type"].ToString().Trim() == "" ? "" : dritem["AAFICBSRate Type"].ToString().Trim();
                            data.RepricedAmortization = Convert.ToDecimal(dritem["Repriced Amortization"].ToString().Trim() == "" ? 0.00 : dritem["Repriced Amortization"]);
                            data.PastDueDateITLDateExtractedPerAAFICBS = dritem["Past Due Date ITLDate Extracted Per AAFICBS"].ToString().Trim();
                            data.PerFaMSAAFICBSIndustryCode = dritem["Per FaMS AAF ICBS Industry Code"].ToString().Trim() == "" ? "" : dritem["Per FaMS AAF ICBS Industry Code"].ToString().Trim();
                            data.IndustryHeader = dritem["Industry Header"].ToString().Trim() == "" ? "" : dritem["Industry Header"].ToString().Trim();
                            data.IndustryDetail = dritem["Industry Detail"].ToString().Trim() == "" ? "" : dritem["Industry Detail"].ToString().Trim();
                            data.Collateral = dritem["COLLATERAL"].ToString().Trim() == "" ? "" : dritem["COLLATERAL"].ToString().Trim();
                            data.PerFaMSAAFICBSAssetSize = (dritem["Per FaMS AAF ICBS Asset Size"].ToString().Trim() == "00" || dritem["Per FaMS AAF ICBS Asset Size"].ToString().Trim() == "-" || dritem["Per FaMS AAF ICBS Asset Size"].ToString().Trim() == "--") ? "0" : dritem["Per FaMS AAF ICBS Asset Size"].ToString().Trim();
                            data.PerFaMSAAFICBSAssetSizeInWords = dritem["Per FaMS AAF ICBS Asset Size In Words"].ToString().Trim() == "" ? "" : dritem["Per FaMS AAF ICBS Asset Size In Words"].ToString().Trim();
                            data.ICBSGLCode = dritem["ICBS GLCode"].ToString().Trim() == "" ? "" : dritem["ICBS GLCode"].ToString().Trim();
                            data.ICBSGLName = dritem["ICBS GLName"].ToString().Trim() == "" ? "" : dritem["ICBS GLName"].ToString().Trim();
                            data.CostCenter = dritem["Cost Center"].ToString().Trim() == "" ? "" : dritem["Cost Center"].ToString().Trim();
                            data.BranchNameOfCostCenterPerSystem = dritem["Branch Name Of Cost Center Per System"].ToString().Trim() == "" ? "" : dritem["Branch Name Of Cost Center Per System"].ToString().Trim();
                            data.StatusPerGL = dritem["Status Per GL"].ToString().Trim() == "" ? "" : dritem["Status Per GL"].ToString().Trim();
                            data.OriginatingBranchBooked = dritem["Originating Branch Booked"].ToString().Trim() == "" ? "" : dritem["Originating Branch Booked"].ToString().Trim();
                            data.NationalityPerICBS = dritem["Nationality Per ICBS"].ToString().Trim() == "" ? "" : dritem["Nationality Per ICBS"].ToString().Trim();

                            if (!isValidDate(dritem["Next Rate Review Date Extracted Per FaMS AAF ICBS"].ToString().Trim()))
                            {
                                data.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime("01/01/1900");
                            }
                            else
                            {
                                data.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(dritem["Next Rate Review Date Extracted Per FaMS AAF ICBS"]);
                            }

                            data.TaxID = dritem["TAX ID"].ToString().Trim() == "" ? "" : dritem["TAX ID"].ToString().Trim();
                            data.LoanPurposeCode = dritem["Loan Purpose Code"].ToString().Trim() == "" ? "" : dritem["Loan Purpose Code"].ToString().Trim();
                            data.MaturityTypeCode = dritem["Maturity Type Code"].ToString().Trim() == "" ? "" : dritem["Maturity Type Code"].ToString().Trim();
                            data.BankRelationship = dritem["Bank Relationship"].ToString().Trim() == "" ? "" : dritem["Bank Relationship"].ToString().Trim();
                            data.SyndicatedLoanInd = dritem["Syndicated Loan Ind"].ToString().Trim() == "" ? "" : dritem["Syndicated Loan Ind"].ToString().Trim();
                            data.CustomerTypeDescription = dritem["Customer Type Description"].ToString().Trim() == "" ? "" : dritem["Customer Type Description"].ToString().Trim();
                            data.RELCode = dritem["REL Code"].ToString().Trim() == "" ? "" : dritem["REL Code"].ToString().Trim();
                            data.REECode = dritem["REE Code"].ToString().Trim() == "" ? "" : dritem["REE Code"].ToString().Trim();
                            data.REEAddtlInfo = dritem["REE Addtl Info"].ToString().Trim() == "" ? "" : dritem["REE Addtl Info"].ToString().Trim();
                            data.AcctRef = dritem["Acct Ref"].ToString().Trim() == "" ? "" : dritem["Acct Ref"].ToString().Trim();
                            data.RPT = dritem["RPT"].ToString().Trim() == "" ? "" : dritem["RPT"].ToString().Trim();
                            data.ASSETCOST = Convert.ToDecimal(dritem["ASSET COST"].ToString().Trim() == "" ? 0.00 : dritem["ASSET COST"]);
                            data.LeaseType = dritem["Lease Type"].ToString().Trim() == "" ? "" : dritem["Lease Type"].ToString().Trim();
                            data.Provisioning = dritem["PROVISIONING"].ToString().Trim() == "" ? "" : dritem["PROVISIONING"].ToString().Trim();
                            data.Matrix = dritem["MATRIX"].ToString().Trim() == "" ? "" : dritem["MATRIX"].ToString().Trim();
                            data.Remarks = dritem["REMARKS"].ToString().Trim() == "" ? "" : dritem["REMARKS"].ToString().Trim();
                            data.ICBSCollateralCode = dritem["ICBS Collateral Code"].ToString().Trim() == "" ? "" : dritem["ICBS Collateral Code"].ToString().Trim();
                            data.AssetValue = Convert.ToDecimal(dritem["Asset Value"].ToString().Trim() == "" ? 0.00 : dritem["Asset Value"]);
                            data.ApprovedAmount = Convert.ToDecimal(dritem["Approved Amount"].ToString().Trim() == "" ? 0.00 : dritem["Approved Amount"]);
                            data.CPNumber = dritem["CP Number"].ToString().Trim() == "" ? "" : dritem["CP Number"].ToString().Trim();
                            data.LastInterestPay = Convert.ToDecimal(dritem["Last Principal Pay"].ToString().Trim() == "" ? 0.00 : dritem["Last Principal Pay"]);

                            if (!isValidDate(dritem["Principal Pay Date"].ToString().Trim()))
                            {
                                data.PrincipalPayDate = Convert.ToDateTime("01/01/1900");
                            }
                            else
                            {
                                data.PrincipalPayDate = Convert.ToDateTime(dritem["Principal Pay Date"]);
                            }

                            data.LastInterestPay = Convert.ToDecimal(dritem["Last Interest Pay"].ToString().Trim() == "" ? 0.00 : dritem["Last Interest Pay"]);
                            if (!isValidDate(dritem["Last Interest Pay Date"].ToString().Trim()))
                            {
                                data.LastInterestPayDate = Convert.ToDateTime("01/01/1900");
                            }
                            else
                            {
                                data.LastInterestPayDate = Convert.ToDateTime(dritem["Last Interest Pay Date"]);
                            }

                            data.PreviousMonthsNPLTaggingByRisk = dritem["Previous Months NPL Tagging By Risk"].ToString().Trim() == "" ? "" : dritem["Previous Months NPL Tagging By Risk"].ToString().Trim();
                            data.SpecificRequiredProvisions = dritem["Specific Required Provisions"].ToString().Trim() == "" ? "" : dritem["Specific Required Provisions"].ToString().Trim();
                            data.GeneralRequiredProvisions = dritem["General Required Provisions"].ToString().Trim() == "" ? "" : dritem["General Required Provisions"].ToString().Trim();
                            data.Reason = "";
                            #endregion

                            if (underLitigationRepository.AccountNotExists(data.AccountNo, _underLitigationDateParameter.ToString().Trim()))
                            {
                                underLitigationRepository.DeleteConsolidator(data);
                                underLitigationRepository.InsertRecord(data);

                                dru = dtupdated.NewRow();
                                dru["AccountNo"] = data.AccountNo;
                                dru["GL Code"] = data.ICBSGLCode;
                                dru["GL Description"] = data.ICBSGLName;
                                dtupdated.Rows.Add(dru);
                            }
                            else
                            {
                                underLitigationRepository.InsertRecord(data);

                                dri = dtinserted.NewRow();
                                dri["AccountNo"] = data.AccountNo;
                                dri["GL Code"] = data.ICBSGLCode;
                                dri["GL Description"] = data.ICBSGLName;
                                dtinserted.Rows.Add(dri);
                            }

                            saveWorker.ReportProgress(iCount++ * 100 / dtFromNTCRecords.Rows.Count, progressArray); // wla lng
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError(string.Format("Error found at row {0}. Error message: {1}.", iCount.ToString(), ex.Message.ToString()));
                    }
                }
            }
            catch (Exception ex)
            {
                var asdasd = iCount;
                throw ex;
            }
        }
        #endregion

        protected bool isValidDate(String date)
        {
            try
            {
                DateTime dt = DateTime.Parse(date);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void ListItem()
        {
            dtupdated.Columns.Add("AccountNo");
            dtupdated.Columns.Add("GL Code");
            dtupdated.Columns.Add("GL Description");

            dtinserted.Columns.Add("AccountNo");
            dtinserted.Columns.Add("GL Code");
            dtinserted.Columns.Add("GL Description");
        }

        private DataTable NTCColumnNames()
        {
            dtunderLitigation = new DataTable("dtunderLitigation");
            dtunderLitigation.Columns.Add("TransID", typeof(String));
            dtunderLitigation.Columns.Add("RawFiles", typeof(String));
            dtunderLitigation.Columns.Add("isConsolidated", typeof(String));
            dtunderLitigation.Columns.Add("isDeleted", typeof(String));
            dtunderLitigation.Columns.Add("UserName", typeof(String));
            dtunderLitigation.Columns.Add("TransDate", typeof(String));
            dtunderLitigation.Columns.Add("RecordDate", typeof(String));
            dtunderLitigation.Columns.Add("SYSTEM", typeof(String));
            dtunderLitigation.Columns.Add("AccountNo", typeof(String));
            dtunderLitigation.Columns.Add("ClientName", typeof(String));
            dtunderLitigation.Columns.Add("AO", typeof(String));
            dtunderLitigation.Columns.Add("FacilityCode", typeof(String));
            dtunderLitigation.Columns.Add("StatusPerSystem", typeof(String));
            dtunderLitigation.Columns.Add("ValueDate", typeof(String));
            dtunderLitigation.Columns.Add("FirstDueDate", typeof(String));
            dtunderLitigation.Columns.Add("MaturityDate", typeof(String));
            dtunderLitigation.Columns.Add("TotalLoan", typeof(String));
            dtunderLitigation.Columns.Add("OB", typeof(String));
            dtunderLitigation.Columns.Add("MonthlyOB", typeof(String));
            dtunderLitigation.Columns.Add("UDIBalance", typeof(String));
            dtunderLitigation.Columns.Add("ClientsEquity", typeof(String));
            dtunderLitigation.Columns.Add("AccruedInterestReceivable", typeof(String));
            dtunderLitigation.Columns.Add("OrigERV", typeof(String));
            dtunderLitigation.Columns.Add("PVRV", typeof(String));
            dtunderLitigation.Columns.Add("OrigGD", typeof(String));
            dtunderLitigation.Columns.Add("PVGD", typeof(String));
            dtunderLitigation.Columns.Add("TotalLoanPortfolio", typeof(String));
            dtunderLitigation.Columns.Add("NTC", typeof(String));
            dtunderLitigation.Columns.Add("OriginalRate", typeof(String));
            dtunderLitigation.Columns.Add("CurrentRate", typeof(String));
            dtunderLitigation.Columns.Add("TermInMonths", typeof(String));
            dtunderLitigation.Columns.Add("RemainingTermInMonths", typeof(String));
            dtunderLitigation.Columns.Add("OriginalAmortizationAAF", typeof(String));
            dtunderLitigation.Columns.Add("PaymentScheduleAmortizationAAF", typeof(String));
            dtunderLitigation.Columns.Add("RepricedDate", typeof(String));
            dtunderLitigation.Columns.Add("AAFICBSRateType", typeof(String));
            dtunderLitigation.Columns.Add("RepricedAmortization", typeof(String));
            dtunderLitigation.Columns.Add("PastDueDateITLDateExtractedPerAAFICBS", typeof(String));
            dtunderLitigation.Columns.Add("PerFaMSAAFICBSIndustryCode", typeof(String));
            dtunderLitigation.Columns.Add("IndustryHeader", typeof(String));
            dtunderLitigation.Columns.Add("IndustryDetail", typeof(String));
            dtunderLitigation.Columns.Add("Collateral", typeof(String));
            dtunderLitigation.Columns.Add("PerFaMSAAFICBSAssetSize", typeof(String));
            dtunderLitigation.Columns.Add("PerFaMSAAFICBSAssetSizeInWords", typeof(String));
            dtunderLitigation.Columns.Add("ICBSGLCode", typeof(String));
            dtunderLitigation.Columns.Add("ICBSGLName", typeof(String));
            dtunderLitigation.Columns.Add("CostCenter", typeof(String));
            dtunderLitigation.Columns.Add("BranchNameOfCostCenterPerSystem", typeof(String));
            dtunderLitigation.Columns.Add("StatusPerGL", typeof(String));
            dtunderLitigation.Columns.Add("OriginatingBranchBooked", typeof(String));
            dtunderLitigation.Columns.Add("NationalityPerICBS", typeof(String));
            dtunderLitigation.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS", typeof(String));
            dtunderLitigation.Columns.Add("TaxID", typeof(String));
            dtunderLitigation.Columns.Add("LoanPurposeCode", typeof(String));
            dtunderLitigation.Columns.Add("MaturityTypeCode", typeof(String));
            dtunderLitigation.Columns.Add("BankRelationship", typeof(String));
            dtunderLitigation.Columns.Add("SyndicatedLoanInd", typeof(String));
            dtunderLitigation.Columns.Add("CustomerTypeDescription", typeof(String));
            dtunderLitigation.Columns.Add("RELCode", typeof(String));
            dtunderLitigation.Columns.Add("REECode", typeof(String));
            dtunderLitigation.Columns.Add("REEAddtlInfo", typeof(String));
            dtunderLitigation.Columns.Add("AcctRef", typeof(String));
            dtunderLitigation.Columns.Add("RPT", typeof(String));
            dtunderLitigation.Columns.Add("ASSETCOST", typeof(String));
            dtunderLitigation.Columns.Add("LeaseType", typeof(String));
            dtunderLitigation.Columns.Add("Provisioning", typeof(String));
            dtunderLitigation.Columns.Add("Matrix", typeof(String));
            dtunderLitigation.Columns.Add("Remarks", typeof(String));
            dtunderLitigation.Columns.Add("ICBSCollateralCode", typeof(String));
            dtunderLitigation.Columns.Add("AssetValue", typeof(String));
            dtunderLitigation.Columns.Add("ApprovedAmount", typeof(String));
            dtunderLitigation.Columns.Add("CPNumber", typeof(String));
            dtunderLitigation.Columns.Add("LastPrincipalPay", typeof(String));
            dtunderLitigation.Columns.Add("PrincipalPayDate", typeof(String));
            dtunderLitigation.Columns.Add("LastInterestPay", typeof(String));
            dtunderLitigation.Columns.Add("LastInterestPayDate", typeof(String));
            dtunderLitigation.Columns.Add("PreviousMonthsNPLTaggingByRisk", typeof(String));
            dtunderLitigation.Columns.Add("SpecificRequiredProvisions", typeof(String));
            dtunderLitigation.Columns.Add("GeneralRequiredProvisions", typeof(String));
            dtunderLitigation.Columns.Add("Reason", typeof(String));

            return dtunderLitigation;

        }

        private void frmUnderLitigation_FormClosed(object sender, FormClosedEventArgs e)
        {
            //frmConsolidator frmreload = new frmConsolidator();
            //frmreload.GetConsolidator();

            frmUnderLitigation.litigationform = null;
        }

        private void lblOutOf_Click(object sender, EventArgs e)
        {

        }

        private void lnkDetails_DoubleClick(object sender, EventArgs e)
        {
            pnlInsertUpdate.Visible = true;
        }

        private void btnpnlUpdateInsert_Click(object sender, EventArgs e)
        {
            this.pnlInsertUpdate.Visible = false;
            this.pnlSummary.Visible = true;
        }

        private void ShowHiddenPanel()
        {
            pnlInsertUpdate.Visible = true;
            //loop here
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.pnlSummary.Visible = false;
            //this.pnlInsertUpdate.Visible = true;
        }

        private void lnkDetailsInserted_DoubleClick(object sender, EventArgs e)
        {
            ShowHiddenPanel();
        }
        
        private void lnkDetailsUpdated_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            BindData();
            this.pnlSummary.Visible = false;
            this.pnlInsertUpdate.Visible = true;
        }

        private void lnkDetailsInserted_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            BindData();
            this.pnlSummary.Visible = false;
            this.pnlInsertUpdate.Visible = true;
        }

        private void BindData()
        {
            if (dtupdated.Rows.Count > 0)
            {
                dgrViewUpdatedList.DataSource = dtupdated;
            }

            if (dtinserted.Rows.Count > 0)
            {
                dgrViewInserted.DataSource = dtinserted;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                var retVal = DownloadExcelTemplate.DownloadTemplate("Accounts Under Litigation");

                if (retVal == 1)
                {
                    MetroMessageBox.Show(this, "\r\nAccounts Under Litigation excel Template was successfully downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "Error Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while downloading the template, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
