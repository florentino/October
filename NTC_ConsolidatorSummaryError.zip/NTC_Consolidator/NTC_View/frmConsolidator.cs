﻿using MetroFramework;
using Microsoft.Reporting.WinForms;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using NTC_Consolidator.NTC_Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Core.EntityClient;
using System.Data.Entity.Validation;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmConsolidator : MetroFramework.Forms.MetroForm
    {
        #region Properties
        public static string UserName = "";
        public static string dbUserName = "";
        public static string dbPassword = "";
        private static string[] param = new string[10];
        public static string _AafPath = "";
        public static string _FamsPath = "";
        public static string _IcbsPath = "";
        public static string _GLCodeAndDescPath = "";
        public static string _USDollarPath = "";
        string NTC_DateTime;
        bool hasDollarError = false;
        bool isNoData = false;
        BindingSource source = new BindingSource();
        DataTable dtTmp = new DataTable();
        DataTable dtcompare = new DataTable();
        DataTable dtConso = new DataTable();
        DataTable dtGLCODE = new DataTable();
        DataTable dtQTable = new DataTable();
        DataTable dtIcbs = new DataTable();
        DataTable dtAaf = new DataTable();
        DataTable dtFams = new DataTable();
        DataTable dtExport = new DataTable();
        public static DataTable dtUSDollar;
        bool isIcbsPreviousDate = false;
        bool isAffPreviousDate = false;
        bool isfamsPreviousDate = false;
        bool isPreviousDate = false;
        bool dateNotTheSame = false;
        int lineCount = 0;
        int iCounter = 1;
        bool isInProcess = false;
        bool _InValidDate = false;
        bool _isValidAafRawFile = true;
        bool _isValidIcbsRawFile = true;
        bool isPreviousData = false;
        string ICBSDateParameter = "";
        string AAFDateParameter = "";
        string FAMSDateParameter = "";
        int curRow = 0;
        decimal currencyRate = 0.0M;
        string[] progressArray;
        string ExportFilename = "";
        bool isICBSReadyToProcess = false;
        bool isAAFReadyToProcess = false;
        bool isFAMSReadyToProcess = false;
        bool IsBusy = false;
        bool isOnloadErr = false;
        NumberStyles styles;
        private BackgroundWorker icbsWorker;
        private BackgroundWorker aafWorker;
        private BackgroundWorker famsWorker;
        private BackgroundWorker consolidateWorker;
        private BackgroundWorker ExportWorker;
        private BackgroundWorker updateGLworker;
        private BackgroundWorker Currencyworker;
        CultureInfo cultureInfo;
        TextInfo textInfo;
        AAFModel consoModel = new AAFModel();
        AAFModel famsmodel = new AAFModel();
        AAFModel icbsmodel = new AAFModel();
        AAFModel aafmodel = new AAFModel();
        string icbsFileName = "";
        string famsFileName = "";
        string aafFileName = "";
        string isOnloadErrmsg = "";
        private ICorrespondingGLRepository correspondingGLRepository;
        private IConsolidator consolidatorRepository;
        private IFilePathRepository filePathRepository;
        private IExchangeRate exchangeRate;
        private IQualifyingCapital qualifyingCapitalRepository;
        private static frmConsolidator frmconsolidator = null;
        private static ManualResetEvent mre = new ManualResetEvent(false);

        #endregion

        //Singleton
        public static frmConsolidator Instance()
        {
            // MessageBox.Show("Success!");
            if (frmconsolidator == null)
            {
                frmconsolidator = new frmConsolidator();
            }

            return frmconsolidator;
        }

        public frmConsolidator()
        {
            InitializeComponent();
            UserName = Program.NTC_UserloginName;
            Initializer();
            lblBusy.Text = "";
            CenterPanel();
            this.ConsoMenu.RenderMode = ToolStripRenderMode.Professional;
            this.ConsoMenu.Renderer = new ToolStripProfessionalRenderer(new CustomColorTable());
        }

        private void Initializer()
        {
            try
            {
                this.consolidatorRepository = new ConsolidatorRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
                this.filePathRepository = new FilePathRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
                this.exchangeRate = new ExchangeRateRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
                this.correspondingGLRepository = new CorrespondingGLRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
                this.qualifyingCapitalRepository = new QualifyingCapitalRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));
            }
            catch (Exception ex)
            {
                isOnloadErr = true;
                isOnloadErrmsg = ex.InnerException.Message.ToString();
                MetroMessageBox.Show(this, ex.Message.ToString(), "Invalid Validity Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        private void CenterPanel()
        {
            pnlWaitInfo.Location = new Point(
            this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2, this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;
        }

        public List<string> GetColumnNames()
        {
            var properties = (from t in typeof(BDOLF_Consolidator).GetProperties()
                              select t.Name).ToList();

            return properties;
        }

        private void frmConsolidator_Load(object sender, EventArgs e)
        {
            UserName = Program.NTC_UserloginName;

            var AppsettingsDate = consolidatorRepository.GetDate("AsOfDate");

            if (isValidDate(AppsettingsDate))
            {
                NTC_DateTime = AppsettingsDate;
            }
            else
            {
                MetroMessageBox.Show(this, "\r\nValidity date of Raw Files was not set OR invalid date format.", "Invalid Validity Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (!isOnloadErr)
            {
                #region Remove Negative(-) Amount inside the parentheses
                styles = NumberStyles.AllowParentheses | NumberStyles.AllowTrailingSign | NumberStyles.Float | NumberStyles.AllowThousands;
                #endregion
                GetConsolidator();
            }
            else
            {
                btnGenerate.Enabled = false;
                MetroMessageBox.Show(this, isOnloadErrmsg, "Error Message: " + isOnloadErrmsg + "\r\nNTC Consolidator Failed to initialize", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private bool CheckIDirectoryIfExists(string fileDir, string module)
        {
            DirectoryInfo info = new DirectoryInfo(fileDir);
            FileInfo[] files = info.GetFiles().OrderBy(p => p.CreationTime).ToArray();

            bool exists = Directory.Exists(fileDir);
            var retValue = false;

            #region ICBS Checker
            if (exists && module == "icbs")
            {
                foreach (FileInfo file in files)
                {
                    _IcbsPath = file.FullName;
                    retValue = true;
                    break;
                }

                lineCount = File.ReadAllLines(_IcbsPath).Length - 1;//may error kc ung path hnd naka specify
                lblWaitFilePath.Text = _IcbsPath;
                lblWaitStatus1.Text = string.Format("Total numbers of records: {0}", lineCount);
            }
            #endregion
            #region AAF Checker
            if (exists && module == "aaf")
            {
                foreach (FileInfo file in files)
                {
                    _AafPath = file.FullName;
                    retValue = true;
                    break;
                }
            }
            #endregion
            #region FAMS Checker
            if (exists && module == "FACTOREDRECEIVABLE")
            {
                foreach (FileInfo file in files)
                {
                    _FamsPath = file.FullName;
                    retValue = true;
                    break;
                }
            }
            #endregion
            #region GLCODEDESCRIPTION Checker
            if (exists && module == "GLCODEDESCRIPTION")
            {
                foreach (FileInfo file in files)
                {
                    _GLCodeAndDescPath = file.FullName;
                    retValue = true;
                    break;
                }
            }
            #endregion
            return retValue;
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            dtUSDollar = new DataTable();
            dtIcbs = new DataTable("ICBSDATA");//Initialize again the datatable to avoid Error
            FilePathMaintenance maintenance = new FilePathMaintenance();

            if (!IsBusy)
            {
                progressArray = new string[5];
                dateNotTheSame = false;
                var hasError = false;
                _isValidAafRawFile = true;
                _isValidIcbsRawFile = true;
                ConsoMenu.Enabled = false;
                btnSearch.Enabled = false;
                GetConsolidator();

                consoModel = new AAFModel();

                DataTable dtpath = new DataTable();
                dtIcbs = new DataTable();

                #region ICBS, AAF, FAMS

                var pathdata = filePathRepository.GetAll(UserName);

                if (pathdata.ToList().Count <= 0)
                {
                    DialogResult diag = MetroMessageBox.Show(this, "\r\nThe specified path of Raw File does not exists.\r\nClick YES to Setup the path of the files.", "Path Not Exists", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
                    if (diag == DialogResult.No)
                    {
                        ConsoMenu.Enabled = true;
                        btnSearch.Enabled = true;
                        return;
                    }
                    else
                    {
                        try
                        {
                            frmPathMaintenance objfrm = frmPathMaintenance.Instance();
                            objfrm.ShowDialog();
                        }
                        catch (Exception ex)
                        {
                            isICBSReadyToProcess = false;
                            return;
                        }
                    }

                    pathdata = filePathRepository.GetAll(UserName);

                    if (pathdata.ToList().Count > 0) CheckerFiles(pathdata, ref hasError);

                }
                else
                {
                    CheckerFiles(pathdata, ref hasError);
                }

                if (hasError) return;

                #endregion

                #region GL Code And Description

                if (LoadGLData().Rows.Count <= 0)
                {
                    DialogResult dr = MetroMessageBox.Show(this, "\r\nNo record found for GL Code and GL Description. Click YES to Setup GL Code and Description", "GL Code and Description", MessageBoxButtons.YesNo, MessageBoxIcon.Error);

                    if (dr == DialogResult.No)
                    {
                        ConsoMenu.Enabled = true;
                        btnSearch.Enabled = true;
                        isICBSReadyToProcess = false;
                        return;
                    }
                    else
                    {
                        try
                        {
                            frmCorrespondingGL objfrm = frmCorrespondingGL.Instance();
                            objfrm.ShowDialog();
                        }
                        catch
                        {
                            isICBSReadyToProcess = false;
                        }
                    }
                    LoadGLData();
                }

                #endregion

                #region Qualifying Table
                if (LoadQualifyingTable().Rows.Count <= 0)
                {
                    DialogResult dr = MetroMessageBox.Show(this, "\r\nNo record found for Qualifying Capital. Click YES to Setup Qualifying Capital", "Qualifying Capital", MessageBoxButtons.YesNo, MessageBoxIcon.Error);

                    if (dr == DialogResult.No)
                    {
                        ConsoMenu.Enabled = true;
                        btnSearch.Enabled = true;
                        isICBSReadyToProcess = false;
                    }
                    else
                    {
                        try
                        {
                            frmQualifyingCapital objfrm = frmQualifyingCapital.Instance();
                            objfrm.ShowDialog();
                        }
                        catch
                        {
                            isICBSReadyToProcess = false;
                            return;
                        }
                    }
                }
                #endregion

                #region US Dollar Exchange Rate
                var curresult = exchangeRate.GetByCode("PHP");

                if (curresult == null)
                {
                    DialogResult dr = MetroMessageBox.Show(this, "\r\nNo currency Rate found for the current month. Click YES to setup currency.", "US Dollar Exchange Rate", MessageBoxButtons.YesNo, MessageBoxIcon.Error);

                    if (dr == DialogResult.No)
                    {
                        ConsoMenu.Enabled = true;
                        btnSearch.Enabled = true;
                        isICBSReadyToProcess = false;
                    }
                    else
                    {
                        try
                        {
                            frmExchangeRate frmExchange = frmExchangeRate.Instance();
                            frmExchange.ShowDialog();
                            curresult = exchangeRate.GetByCode("PHP");
                        }
                        catch (Exception ex)
                        {
                            isICBSReadyToProcess = false;
                            return;
                        }
                    }
                }

                if (curresult != null)
                    currencyRate = curresult.CurrencyRate;
                #endregion

                #region For ICBS Currency Tagging
                DialogResult diagUSD = MetroMessageBox.Show(this, "\r\nPlease load ICBS or FAMS files, to be consider as a US Dollar Account.\r\nClick OK button to load the files.", "US Dollar Account", MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
                if (diagUSD == DialogResult.OK)
                {
                    OpenFileDialog dlgUSD = new OpenFileDialog();
                    dlgUSD.Title = "NTC Consolidator";
                    dlgUSD.Filter = "Excel Files(.xls)|*.xls";

                    DialogResult resDlgUSD = dlgUSD.ShowDialog();

                    if (resDlgUSD == DialogResult.OK)
                    {
                        _USDollarPath = dlgUSD.FileName;
                        try
                        {
                            pnlWaitInfo.Visible = true;
                            lblWaitInfo.Text = "Reading US Dollar Account, Please wait...";
                            lblWaitStatus.Text = "In-progress...";

                            Currencyworker = new BackgroundWorker();
                            Currencyworker.DoWork += new DoWorkEventHandler(Currencyworker_DoWork);
                            Currencyworker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(Currencyworker_RunWorkerCompleted);
                            Currencyworker.RunWorkerAsync();
                        }
                        catch
                        {
                            isICBSReadyToProcess = false;
                            return;
                        }
                    }
                    else
                    {
                        ConsoMenu.Enabled = true;
                        btnSearch.Enabled = true;
                        isICBSReadyToProcess = false;
                        return;
                    }
                }
                else
                {
                    ConsoMenu.Enabled = true;
                    btnSearch.Enabled = true;
                    isICBSReadyToProcess = false;
                    return;
                }
                #endregion

                #region For Raw File Checker
                string[] ifile = Directory.GetFiles(Path.GetDirectoryName(_IcbsPath), "*.txt");
                if (ifile.Length > 1)
                {
                    MetroMessageBox.Show(this, "\r\n" + "Proccess terminated. Multiple \".txt\" Files detected in this path: \"" + _IcbsPath + "\".", "Proccess Terminated", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                string[] afile = Directory.GetFiles(Path.GetDirectoryName(_AafPath), "*.xls");
                if (afile.Length > 1)
                {
                    MetroMessageBox.Show(this, "\r\n" + "Proccess terminated. Multiple \".xls\" Files detected in this path: \"" + _AafPath + "\".", "Proccess Terminated", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                string[] ffile = Directory.GetFiles(Path.GetDirectoryName(_FamsPath), "*.xls");
                if (ffile.Length > 1)
                {
                    MetroMessageBox.Show(this, "\r\n" + "Proccess terminated. Multiple \".xls\" Files detected in this path: \"" + _FamsPath + "\".", "Proccess Terminated", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                #endregion

                #region Execute Proccess
                if (isICBSReadyToProcess)
                {
                    ProcceedICBS(ref hasDollarError);
                }
                else
                {
                    btnGenerate_Click(null, null);
                }
                #endregion
            }
            else
            {
                lblBusy.Text = "Busy processing, Please wait...";
            }
        }

        private void ProcceedICBS(ref bool hasDollarError)
        {
            pnlWaitInfo.Visible = true;
            icbsWorker = new BackgroundWorker();
            icbsWorker.WorkerReportsProgress = true;
            icbsWorker.DoWork += new DoWorkEventHandler(icbsWorker_DoWork);
            icbsWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(icbsWorker_RunWorkerCompleted);
            icbsWorker.ProgressChanged += new ProgressChangedEventHandler(icbsWorker_ProgressChanged);
            icbsWorker.WorkerSupportsCancellation = true;
            icbsWorker.RunWorkerAsync();
        }

        private void CheckerFiles(IEnumerable<BDOLF_PathMaintenance> pathdata, ref bool hasError)
        {
            try
            {
                foreach (var item in pathdata)
                {
                    if (item.System.ToUpper() == "ICBS")
                    {
                        icbsFileName = item.FilePath;
                    }

                    if (item.System.ToUpper() == "AAF")
                    {
                        aafFileName = item.FilePath;
                    }
                    if (item.System.ToUpper() == "FAMS")
                    {
                        famsFileName = item.FilePath;
                    }
                }

                isICBSReadyToProcess = CheckIDirectoryIfExists(icbsFileName, "icbs");
                isAAFReadyToProcess = CheckIDirectoryIfExists(aafFileName, "aaf");
                isFAMSReadyToProcess = CheckIDirectoryIfExists(famsFileName, "FACTOREDRECEIVABLE");
                if (!isICBSReadyToProcess || !isAAFReadyToProcess || !isFAMSReadyToProcess)
                {
                    MetroMessageBox.Show(this, "\r\nThe Raw File does not exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
            }
            catch (Exception ex)
            {
                ConsoMenu.Enabled = true;
                btnSearch.Enabled = true;
                isICBSReadyToProcess = false;

                hasError = true;
                MetroMessageBox.Show(this, "Error Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
        }

        #region For Currency Import
        private void Currencyworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Cancelled";


                if (isNoData)
                {
                    isNoData = false;
                    MetroMessageBox.Show(this, "\r\n\r\nDollar Rate and Dollar Accounts excel files contains no data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //ErrorLog.AddError("Dollar Rate and Dollar Accounts excel files contains no data.");
                }
                isICBSReadyToProcess = false;
                return;
            }
            else if (e.Error != null)
            {
                //pnlWaitInfo.Visible = false;
                //lblWaitInfo.Text = "";
                //lblWaitStatus.Text = "Status: Error";
                //IsBusy = false;
                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    ErrorLog.AddError("US Dollar Account RAW File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents.");
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    ErrorLog.AddError("US Dollar Account excel file is no a valid excel template, To verify the excel format. Please download the template.");
                }
                else if (e.Error.ToString().Contains("There is no row at position 0."))
                {
                    ErrorLog.AddError("US Dollar Account excel file is not a valid excel template, To verify the excel format. Please download the template.");
                }
                else
                {
                    ErrorLog.AddError(e.Error.Message.ToString());
                }
                //wait = true;
                isICBSReadyToProcess = false;
            }
            else
            {
                //pnlWaitInfo.Visible = false;
                //lblWaitInfo.Text = "";
                //lblWaitStatus.Text = "Done";
                mre.Set(); //Set the first backgroundworker
            }
        }

        private void Currencyworker_DoWork(object sender, DoWorkEventArgs e)
        {
            //try
            //{
            IsBusy = true;
            // Create the connection object 
            string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", _USDollarPath);
            // aafFileName = Path.GetFileName(_AafPath);
            using (OleDbConnection conn = new OleDbConnection(connString))
            {
                conn.Open();
                OleDbCommand cmd = new OleDbCommand();
                DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                if (dbSchema == null || dbSchema.Rows.Count < 1)
                {
                    ErrorLog.AddError("Could not determined the name of the worksheet for US Dollar Account excel file.");
                    //throw new Exception("Error: Could not determined the name of the worksheet.");
                }

                string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + worksheetname + "] WHERE[F1] <> ''", conn);
                DataTable dtold = new DataTable(worksheetname);
                da.Fill(dtold);

                dtold.Rows.RemoveAt(0);
                dtold.Rows.RemoveAt(0);
                dtold.Rows.RemoveAt(0);
                dtold.Rows.RemoveAt(0);

                foreach (DataColumn dc in dtold.Columns)
                {
                    try
                    {
                        if (dtold.Rows[0][dc].ToString().ToUpper() != "")
                        {
                            var hName = dtold.Rows[0][dc].ToString().Trim();
                            dc.ColumnName = hName;
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError("Error in \"" + dtold.Rows[0][dc].ToString().ToUpper() + "\" Error message: " + ex.Message.ToString());
                        continue;
                    }
                }
                dtold.Rows.RemoveAt(0);

                if (dtold.Rows.Count <= 0)
                {
                    ErrorLog.AddError("Dollar Rate and Dollar Accounts excel files contains no data.");
                }

                //Thread.Sleep(1);

                // bool invalidExcel = false;
                var requiredColumns = new HashSet<string>
                    { "SYSTEM", "CONTRACT / PN NO.", "CLIENT NAME" };

                for (int i = 0; i < dtold.Columns.Count; i++)
                {
                    string colname = dtold.Columns[i].ColumnName;
                    if (!requiredColumns.Contains(colname.Trim()))
                    {
                        //invalidExcel = true;
                        ErrorLog.AddError(colname.Trim() + " in US Dollar Account excel file is not found. To verify the excel format. Please download the template.");
                    }
                }

                //if (invalidExcel)
                //{
                //    ErrorLog.AddError("US Dollar Account excel file is no a valid excel template, To verify the excel format. Please download the template.");
                //    throw new Exception("does not belong to table");
                //}

                dtUSDollar = dtold;

            }
            //}
            //catch (Exception ex)
            //{
            //    //if (ex.Message.ToString().Contains("There is no row at position 0."))
            //    //{
            //    //    ErrorLog.AddError("US Dollar Account excel file is not a valid excel template, To verify the excel format. Please download the template.");
            //    //    throw new Exception("does not belong to table");
            //    //}
            //    //else
            //    //{
            //    throw new Exception("Error in US Dollar Account");
            //    //}
            //}
        }
        #endregion
        #region ICBS Worker
        private void icbsWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;
            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = string.Format("Status: Reading at row {0} out of {1}", curRow, lineCount);
        }

        private void icbsWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Cancelled";

                //IsBusy = false;

                //isICBSExist = false;
                //isAAFExist = false;
                //isFAMSExist = false;
                dtIcbs = new DataTable("ICBSDATA");//Initialize again the datatable to avoid Error

                if (isPreviousData)
                {
                    MetroMessageBox.Show(this, "\r\n" + "\"As Of Date\" Column is invalid \r\n" + "Sorry! System will not allow the user to insert a record from previous Months or Year.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (_InValidDate)
                {
                    MetroMessageBox.Show(this, "\r\nICBS Raw File date is Invalid Date.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (!_isValidIcbsRawFile)
                {
                    MetroMessageBox.Show(this, "\r\nUnable to proccess, Due to invalid ICBS Raw File.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (isIcbsPreviousDate)
                {
                    MetroMessageBox.Show(this, "\r\nUnable to proccess record, Date must be greater than the value base on the configured implementation date.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, e.Error.Message.ToString() + "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                ConsoMenu.Enabled = true;
                btnSearch.Enabled = true;
                return;
            }
            else if (e.Error != null)
            {
                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    ErrorLog.AddError("ICBS RAW File is already opened exclusively by another user, or you need permission to view and write its data. NOTE: Please Close or Save all Open Documents");
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    ErrorLog.AddError("Invalid excel template for ICBS RAW File. Please download ICBS Excel template.");
                }
                else if (!_isValidIcbsRawFile)
                {
                    ErrorLog.AddError("Unable to proccess, Due to invalid ICBS Raw File.");
                }
                else
                {
                    ErrorLog.AddError(e.Error.Message.ToString());
                }
                //ConsoMenu.Enabled = true;
                //btnSearch.Enabled = true;
                //pnlWaitInfo.Visible = false;
                //lblWaitInfo.Text = "";
                //lblWaitStatus.Text = "Status: Error Encountered while processing";
                //dtIcbs = new DataTable("ICBSDATA");//Initialize again the datatable to avoid Error

                hasDollarError = true;

            }
            else
            {
                if (isAAFReadyToProcess)
                {


                    progressArray = new string[5];
                    lineCount = 0;
                    curRow = 0;
                    AAFDataTable();
                    lblWaitInfo.Text = "Fetching Data from AAF Raw file, Please wait...";
                    lblWaitStatus.Text = "Status: Processing...";

                    aafWorker = new BackgroundWorker();
                    aafWorker.WorkerReportsProgress = true;
                    aafWorker.DoWork += new DoWorkEventHandler(aafWorker_DoWork);
                    aafWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(aafWorker_RunWorkerCompleted);
                    aafWorker.ProgressChanged += new ProgressChangedEventHandler(aafWorker_ProgressChanged);
                    aafWorker.WorkerSupportsCancellation = true;
                    aafWorker.RunWorkerAsync();
                    mre.Set(); //Set the first backgroundworker
                }
            }
        }

        private void icbsWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            mre.WaitOne(); // wait to finish the current backgroundworkers.

            var curid = "";
            IsBusy = true;

            #region For ICBS
            ArrayList icbsdata = new ArrayList();

            icbsFileName = Path.GetFileName(_IcbsPath);
            //try
            //{
            using (StreamReader sr = new StreamReader(_IcbsPath))
            {
                string[] headers = sr.ReadLine().Split('|');

                if (headers[2].ToString() != "PN Number")
                {
                    if (icbsWorker.IsBusy)
                    {
                        ErrorLog.AddError("Unable to proccess, Due to invalid ICBS Raw File.");
                    }
                }

                #region Replace Header Name
                foreach (var headername in headers)
                {
                    try
                    {
                        var headercolumn = headername.ToString().Trim();

                        if (headername != "")
                        {
                            #region Change Column Name
                            headercolumn = headername.ToString().Trim() == "PN Number" ? "AccountNo" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Customer Name" ? "ClientName" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Officer (AO Code)" ? "AO" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Product Description" ? "FacilityCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Status Code" ? "StatusPerSystem" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Book Date" ? "ValueDate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Maturity Date" ? "MaturityDate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Amount Financed" ? "TotalLoan" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "O/S Bal. (Orig)" ? "OB" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "AIR (Orig)" ? "AccruedInterestReceivable" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "New Int. Rate" ? "OriginalRate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Current Int. Rate" ? "CurrentRate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Term in months" ? "TermInMonths" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Rate Type" ? "AAFICBSRateType" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Non-Accrual Date" ? "PastDueDateITLDateExtractedPerAAFICBS" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Industry Classification" ? "PerFaMSAAFICBSIndustryCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Class Description" ? "IndustryHeader" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Class Description 2" ? "IndustryDetail" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Size of Firm" ? "PerFaMSAAFICBSAssetSize" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Branch No." ? "CostCenter" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Nationality" ? "NationalityPerICBS" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Next Rate Review Date" ? "NextRateReviewDateExtractedPerFaMSAAFICBS" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Tax ID No." ? "TaxID" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Loan Purpose Code" ? "LoanPurposeCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Maturity Type Code" ? "MaturityTypeCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Bank Relationship" ? "BankRelationship" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Syndicated Loan Ind" ? "SyndicatedLoanInd" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Customer Type" ? "CustomerTypeDescription" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Dosri Tag" ? "RPT" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Collateral Code" ? "ICBSCollateralCode" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Collateral Value" ? "AssetValue" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Line Amount" ? "ApprovedAmount" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Last Principal Payment" ? "LastPrincipalPay" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "LPP Date" ? "PrincipalPayDate" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "Last Interest Payment" ? "LastInterestPay" : headercolumn;
                            headercolumn = headername.ToString().Trim() == "LIP Date" ? "LastInterestPayDate" : headercolumn;
                            #endregion

                            //Remove unwanted characters(Special Characters and whitespace) and convert into lowercase
                            var NewHeader = Regex.Replace(headercolumn, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToLower();

                            dtIcbs.Columns.Add(NewHeader);
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError(ex.Message.ToString());
                        continue;
                    }
                }
                #endregion

                #region Add Column After reading the Raw File 

                dtIcbs.Columns.Add("Collateral");
                dtIcbs.Columns.Add("monthlyob");
                dtIcbs.Columns.Add("system");
                dtIcbs.Columns.Add("previousmonthsnpltaggingbyrisk");
                dtIcbs.Columns.Add("specificrequiredprovisions");
                dtIcbs.Columns.Add("generalrequiredprovisions");

                dtIcbs.Columns.Add("RecordDate");
                dtIcbs.Columns.Add("Reason");

                dtIcbs.Columns.Add("ICBSGLCode");
                dtIcbs.Columns.Add("ICBSGLName");

                dtIcbs.Columns.Add("TranNo");
                dtIcbs.Columns.Add("RawFiles");
                dtIcbs.Columns.Add("isDeleted");
                dtIcbs.Columns.Add("UserName");
                dtIcbs.Columns.Add("TransDate");
                dtIcbs.Columns.Add("isConsolidated");
                #endregion

                var rowsCount = 0;
                while (!sr.EndOfStream)
                {
                    var isPassed = false;
                    try
                    {
                        rowsCount++;
                        string[] cols = sr.ReadLine().Split('|');

                        #region Overriding the CurrencyValue into 1 if the account Not exists from the list in "dtUSDollar"
                        var currAcctNo = Convert.ToInt64(cols[2]).ToString();

                        curid = currAcctNo;
                        foreach (DataRow drRowusd in dtUSDollar.Rows)
                        {
                            if (drRowusd[1].ToString() == currAcctNo && drRowusd[0].ToString() == "ICBS") //Check if accountno in icbs exists in US Dollar
                            {
                                cols[24] = "1"; // Update the Currency Type Value to 1, To identify the record if is in USD. Because as per sir denver the Currency columns in ICBS Files is always 0 or Peso
                                break;
                            }
                        }
                        #endregion

                        DataRow dr = dtIcbs.NewRow();

                        curRow = rowsCount;

                        for (int i = 0; i < headers.Length - 1; i++)
                        {
                            try
                            {
                                icbsmodel = new AAFModel();

                                progressArray[0] = (i * 100 / headers.Length).ToString(); // percent
                                progressArray[1] = "Reading ICBS RAW Files, Please wait..."; //header text
                                progressArray[2] = "Validating Columns, Please wait..."; //Status
                                progressArray[3] = i.ToString(); //column
                                progressArray[4] = headers.Length.ToString(); //total column

                                var value = cols[i].ToString().Trim();
                                
                                var AsOfDate = "";

                                if (!isPassed)
                                {
                                    try
                                    {
                                        AsOfDate = Convert.ToDateTime(cols[1]).ToShortDateString().ToString();

                                        if (Convert.ToDateTime(AsOfDate) < Convert.ToDateTime(NTC_DateTime))
                                        {
                                            ErrorLog.AddError("Unable to proccess record, Date must be greater than the value base on the configured implementation date.");
                                        }

                                        if (!isValidDate(AsOfDate))
                                        {
                                            ErrorLog.AddError("ICBS Raw File date is Invalid Date.");
                                        }
                                        else
                                        {
                                            if ((Convert.ToDateTime(AsOfDate) >= Convert.ToDateTime(NTC_DateTime)) && (Convert.ToDateTime(NTC_DateTime) <= DateTime.Now))
                                            {
                                                ICBSDateParameter = AsOfDate;// Set the parameter value based on the icbs data
                                            }
                                            else
                                            {
                                                ErrorLog.AddError("ICBS Raw File date is Invalid Date.");
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        var msg = ex.Message.ToString().Split('.');
                                        ErrorLog.AddError("ICBS \"As Of Date\" Column is invalid date in row " + iCounter.ToString() + ". Error Message: " + msg[0].ToString() + ".");
                                    }

                                    isPassed = true;
                                }

                                //For Currency value
                                var _currencyType = cols[24];

                                #region Currency Checker "Check the Currency Type if 1 convert the amount into peso, NOTE: Browse the Exchange Rate maintenance to see the updated Rate value."
                                if (_currencyType == "1") //Convert Amount to peso if Currency is in Dollar
                                {
                                    #region Convert "(1234)" into negative value
                                    #region For Amount Finance Value OR Total Loan 
                                    if (i == 17)
                                    {
                                        var amountFinance = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        dr[i] = ((GetOutputStramount(styles, amountFinance)) * currencyRate).ToString("#,0.00");//For Amount Finance Value OR Total Loan 
                                    }
                                    #endregion
                                    #region For O/S Bal. (Orig) Value
                                    else if (i == 18)
                                    {
                                        var amountOSBAL = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        dr[i] = ((GetOutputStramount(styles, amountOSBAL)) * currencyRate).ToString("#,0.00");//For O/S Bal. (Orig) Value
                                    }
                                    #endregion
                                    #region For AIR (Orig) Value OR Accrued Interest Receivable
                                    else if (i == 27)
                                    {
                                        var amountAIR = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        dr[i] = ((GetOutputStramount(styles, amountAIR)) * currencyRate).ToString("#,0.00");//For AIR (Orig) Value OR Accrued Interest Receivable
                                    }                                                                   // }
                                    #endregion
                                    #region For Last Principal Payment Value
                                    else if (i == 37)
                                    {
                                        var amountLastPrincipal = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        dr[i] = ((GetOutputStramount(styles, amountLastPrincipal)) * currencyRate).ToString("#,0.00");//For Last Principal Payment Value
                                    }                                                                                //}
                                    #endregion
                                    #region For Last Interest Payment Value
                                    else if (i == 39)
                                    {
                                        var amountLastInterest = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        dr[i] = ((GetOutputStramount(styles, amountLastInterest)) * currencyRate).ToString("#,0.00");//For Last Interest Payment Value
                                    }
                                    #endregion
                                    #region For Collateral Value Value  OR Asset Value
                                    else if (i == 65)
                                    {
                                        var amountAssetValue = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        dr[i] = ((GetOutputStramount(styles, amountAssetValue)) * currencyRate).ToString("#,0.00");//For Collateral Value Value  OR Asset Value
                                    }
                                    #endregion
                                    #endregion
                                    else if (i == 31)
                                    {
                                        dr[i] = cols[i].ToString().Trim() + " & " + cols[32].ToString().Trim();
                                    }
                                    else if (i == 8)
                                    {
                                        dr[i] = isValidDate(cols[8].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 9)
                                    {
                                        dr[i] = isValidDate(cols[9].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 10)
                                    {
                                        dr[i] = isValidDate(cols[10].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 38)
                                    {
                                        dr[i] = isValidDate(cols[38].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 40)
                                    {
                                        dr[i] = isValidDate(cols[40].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 60)
                                    {
                                        dr[i] = isValidDate(cols[60].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else
                                    {
                                        dr[i] = cols[i].ToString().Trim();
                                    }
                                }
                                #endregion
                                else if (_currencyType == "0")
                                {
                                    #region Convert "(1234)" into negative value
                                    #region For Amount Finance Value OR Total Loan 
                                    if (i == 17)
                                    {
                                        var amountFinance = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        var newValue = (GetOutputStramount(styles, amountFinance)).ToString("#,0.00");//For Collateral Value Value  OR Asset Value
                                        dr[i] = newValue;
                                    }
                                    #endregion
                                    #region For O/S Bal. (Orig) Value
                                    else if (i == 18)
                                    {
                                        var amountOSBAL = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        var newValue = (GetOutputStramount(styles, amountOSBAL)).ToString("#,0.00");//For Collateral Value Value  OR Asset Value
                                        dr[i] = newValue;
                                    }
                                    #endregion
                                    #region For AIR (Orig) Value OR Accrued Interest Receivable
                                    else if (i == 27)
                                    {
                                        var amountAIR = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        var newValue = (GetOutputStramount(styles, amountAIR)).ToString("#,0.00");//For Collateral Value Value  OR Asset Value
                                        dr[i] = newValue;
                                    }
                                    #endregion
                                    #region For Last Principal Payment Value
                                    else if (i == 37)
                                    {
                                        var amountLastPrincipal = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        var newValue = (GetOutputStramount(styles, amountLastPrincipal)).ToString("#,0.00");//For Collateral Value Value  OR Asset Value
                                        dr[i] = newValue;
                                    }
                                    #endregion
                                    #region For Last Interest Payment Value
                                    else if (i == 39)
                                    {
                                        var amountLastInterest = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        var newValue = (GetOutputStramount(styles, amountLastInterest)).ToString("#,0.00");//For Collateral Value Value  OR Asset Value
                                        dr[i] = newValue;
                                    }
                                    #endregion
                                    #region For Collateral Value Value  OR Asset Value
                                    else if (i == 65)
                                    {
                                        var amountAssetValue = cols[i].ToString().Trim() == "" ? "0" : cols[i].ToString().Trim();
                                        var newValue = (GetOutputStramount(styles, amountAssetValue)).ToString("#,0.00");//For Collateral Value Value  OR Asset Value
                                        dr[i] = newValue;
                                    }
                                    #endregion
                                    #endregion
                                    #region Set Default Date if Null
                                    else if (i == 31)
                                    {
                                        dr[i] = cols[i].ToString().Trim() + " & " + cols[32].ToString().Trim();
                                    }
                                    else if (i == 8)
                                    {
                                        dr[i] = isValidDate(cols[8].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 9)
                                    {
                                        dr[i] = isValidDate(cols[9].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 10)
                                    {
                                        dr[i] = isValidDate(cols[10].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 38)
                                    {
                                        dr[i] = isValidDate(cols[38].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 40)
                                    {
                                        dr[i] = isValidDate(cols[40].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    else if (i == 60)
                                    {
                                        dr[i] = isValidDate(cols[60].ToString().Trim()) == false ? "01/01/1900" : Convert.ToDateTime(cols[i]).ToString("MM/dd/yyyy");
                                    }
                                    #endregion
                                    else
                                    {
                                        dr[i] = i == 2 ? Convert.ToInt64(cols[2]).ToString().Trim() : cols[i].ToString().Trim();
                                    }
                                }
                                else
                                {
                                    ErrorLog.AddError("Invalid type of currency column in ICBS.");
                                }
                            }
                            catch (Exception ex)
                            {
                                ErrorLog.AddError(string.Format("Error Found at row {0} in column \"{1}\" in ICBS. Error Message: {2} ", iCounter.ToString(), headers[i].ToString().ToUpper(), ex.Message.ToString()));
                                iCounter++;
                                continue;
                            }
                        }

                        dtIcbs.Rows.Add(dr);
                        icbsWorker.ReportProgress(iCounter++ * 100 / lineCount, progressArray);
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError(string.Format("Exception found at row {0}. Error Message: {1} in ICBS", iCounter.ToString(), ex.Message.ToString()));
                        continue;
                    }
                }

                for (int i = 0; i < dtIcbs.Rows.Count; i++)
                {
                    try
                    {
                        var valueToCopy = dtIcbs.Rows[i]["ob"].ToString();
                        var valueToCopyCollateral = dtIcbs.Rows[i]["ICBSCollateralCode"].ToString();
                        dtIcbs.Rows[i]["monthlyob"] = valueToCopy;//Duplication the OB column, and put into Monthly OB
                        dtIcbs.Rows[i]["system"] = "ICBS";//Used for System Tagging
                        dtIcbs.Rows[i]["previousmonthsnpltaggingbyrisk"] = "";//For the Future purpose
                        dtIcbs.Rows[i]["specificrequiredprovisions"] = "";//For the Future purpose
                        dtIcbs.Rows[i]["generalrequiredprovisions"] = "";//For the Future purpose
                        dtIcbs.Rows[i]["RecordDate"] = Convert.ToDateTime(ICBSDateParameter);//from the date of the files
                        dtIcbs.Rows[i]["Reason"] = "";//add reason for changes
                        dtIcbs.Rows[i]["Collateral"] = valueToCopyCollateral;//same as Collateral code
                        dtIcbs.Rows[i]["RawFiles"] = icbsFileName;//save the failename of the files, use to validate if the current file was already inserted in the database
                        dtIcbs.Rows[i]["isDeleted"] = false;//tagging for soft delete
                        dtIcbs.Rows[i]["UserName"] = UserName;//current user logged
                        dtIcbs.Rows[i]["TransDate"] = DateTime.Now.ToShortDateString();//date inserted
                        dtIcbs.Rows[i]["isConsolidated"] = true;//For the Future purpose

                        var _productdescription = dtIcbs.Rows[i]["facilitycode"].ToString().ToUpper().Trim();
                        var _statuscode = dtIcbs.Rows[i]["statuspersystem"].ToString().ToUpper().Trim();
                    }
                    catch (Exception ex)
                    {
                        // ErrorLog.AddError("Error found in ICBS. Error message: " + ex.Message.ToString());
                        continue;
                    }
                }

                #region Eliminate Unwanted Columns
                if (dtcompare.Columns.Count > 0)
                {
                    List<DataColumn> columnsToDelete = new List<DataColumn>();
                    foreach (DataColumn col in dtIcbs.Columns)
                    {
                        if (!dtcompare.Columns.Contains(col.ColumnName))
                            columnsToDelete.Add(col);
                    }

                    foreach (DataColumn col in columnsToDelete)
                        dtIcbs.Columns.Remove(col);
                }
                #endregion
            }
            //}
            //catch (Exception ex)
            //{
            //    var erid = curid;
            //    throw ex;
            //}
            #endregion
        }
        #endregion
        #region AAF Worker
        private void aafWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = string.Format("Status: Reading at row {0} out of {1}", curRow, lineCount);
        }

        private void aafWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                // IsBusy = false;
                //isICBSExist = false;
                //isAAFExist = false;
                //isFAMSExist = false;
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Cancelled";

                if (isPreviousData)
                {
                    MetroMessageBox.Show(this, "\r\n" + "\"As Of Date\" Column is invalid \r\n" + "Sorry! System will not allow the user to insert a record from previous Months/Year.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (_InValidDate)
                {
                    MetroMessageBox.Show(this, "\r\nAAF Raw File date is Invalid Date.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (!_isValidAafRawFile)
                {
                    MetroMessageBox.Show(this, "\r\nUnable to proccess, Due to invalid AAF Raw File.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (isAffPreviousDate)
                {
                    MetroMessageBox.Show(this, "\r\nUnable to proccess record, Date must be greater than the value base on the configured implementation date. ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, e.Error.Message.ToString() + "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                dtAaf = new DataTable("AAFDATA");//Initialize again the datatable to avoid Error
                ConsoMenu.Enabled = true;
                btnSearch.Enabled = true;
                return;
            }
            else if (e.Error != null)
            {
                //IsBusy = false;

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    ErrorLog.AddError("AAF RAW File is already opened exclusively by another user, or you need permission to view and write its data. NOTE: Please Close or Save all Open Documents.");
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    ErrorLog.AddError("Invalid AAF excel template. Please download AAF excel template.");
                }
                else if (!_isValidAafRawFile)
                {
                    ErrorLog.AddError("Unable to proccess, Due to invalid AAF Raw File.");
                }
                else
                {
                    ErrorLog.AddError(e.Error.Message.ToString());
                }

                //pnlWaitInfo.Visible = false;
                //lblWaitInfo.Text = "";
                //lblWaitStatus.Text = "Status: Error Encountered while processing";
                //dtAaf = new DataTable("AAFDATA");
                //ConsoMenu.Enabled = true;
                //btnSearch.Enabled = true;
            }
            else
            {
                Thread.Sleep(500);

                if (isFAMSReadyToProcess)
                {
                    progressArray = new string[5];
                    lineCount = 0;
                    FaMSDataTable();
                    lblWaitInfo.Text = "Fetching Data from FaMS Raw file, Please wait...";
                    lblWaitStatus.Text = "Status: Processing...";

                    famsWorker = new BackgroundWorker();
                    famsWorker.WorkerReportsProgress = true;
                    famsWorker.DoWork += new DoWorkEventHandler(famsWorker_DoWork);
                    famsWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(famsWorker_RunWorkerCompleted);
                    famsWorker.ProgressChanged += new ProgressChangedEventHandler(famsWorker_ProgressChanged);
                    famsWorker.WorkerSupportsCancellation = true;
                    famsWorker.RunWorkerAsync();
                    mre.Set(); //Set the first backgroundworker
                }
            }
        }

        private void aafWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            mre.WaitOne(); // wait to finish the current backgroundworkers.
            #region For AAF
            IsBusy = true;
            // Create the connection object 

            var accno = "";
            //try
            //{
            string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0}; Extended Properties='Excel 8.0;HDR=no;IMEX=1;'", _AafPath);
            aafFileName = Path.GetFileName(_AafPath);

            using (OleDbConnection conn = new OleDbConnection(connString))
            {
                conn.Open();
                OleDbCommand cmd = new OleDbCommand();
                DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                if (dbSchema == null || dbSchema.Rows.Count < 1)
                {
                    ErrorLog.AddError("Error: Could not determined the name of the worksheet.");
                }

                string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + worksheetname + "] WHERE[F1] <> ''", conn);
                DataTable dtold = new DataTable(worksheetname);
                da.Fill(dtold);

                DataRow delrowver = dtold.Rows[0];
                delrowver.Delete();
                delrowver.AcceptChanges();

                //Check File is for AAF
                var isValidRawFile = dtold.Rows[0][0].ToString().Trim().ToLower().Contains("aging inventory");

                try
                {
                    var AsOfDate = String.Format("{0:d}", Convert.ToDateTime(dtold.Rows[0][0].ToString().Substring(61)));

                    if (Convert.ToDateTime(AsOfDate) < Convert.ToDateTime(NTC_DateTime))
                    {
                        ErrorLog.AddError("Unable to proccess record, Date must be greater than the value base on the configured implementation date.");
                    }

                    if (!isValidDate(AsOfDate))
                    {
                        ErrorLog.AddError("AAF Raw File date is Invalid Date.");
                    }
                    else
                    {
                        if ((Convert.ToDateTime(AsOfDate) >= Convert.ToDateTime(NTC_DateTime)) && (Convert.ToDateTime(NTC_DateTime) <= DateTime.Now) && isValidRawFile)
                        {
                            AAFDateParameter = AsOfDate; //Get As Of DATE of generated File
                        }
                        else
                        {
                            ErrorLog.AddError("Unable to proccess, Due to invalid AAF Raw File.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    var msg = ex.Message.ToString().Split('.');
                    ErrorLog.AddError("AAF \"As Of Date\" Column is invalid date in row " + iCounter.ToString() + ". Error Message: " + msg[0].ToString() + ".");
                    //break;
                }

                DataRow delrow = dtold.Rows[0];
                delrow.Delete();
                delrow.AcceptChanges();

                int icount = dtold.Rows.Count;
                DataRow delrow1 = dtold.Rows[icount - 1];
                delrow1.Delete();
                delrow1.AcceptChanges();

                //Convert Row 3 value as a header of the DataTable
                foreach (DataColumn dc in dtold.Columns)
                {
                    dc.ColumnName = dtold.Rows[0][dc].ToString();
                }

                DataRow delrow2 = dtold.Rows[0];
                delrow2.Delete();
                delrow2.AcceptChanges();

                lineCount = dtold.Rows.Count;

                var irowCount = 0;
                DataRow dr = null;
                foreach (var item in dtold.Rows)
                {
                    try
                    {
                        accno = dtold.Rows[irowCount]["AccountNo"].ToString();

                        if (dtold.Rows[irowCount]["AccountNo"].ToString().Contains("ver")) break;

                        progressArray[0] = (irowCount * 100 / lineCount).ToString(); // percent
                        progressArray[1] = "Reading AAF RAW File, Please wait..."; //header text
                        progressArray[2] = "Validating Columns, Please wait..."; //Status
                        progressArray[3] = curRow.ToString(); //column
                        progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                        //Start from row 4 and column 0
                        if (!string.IsNullOrEmpty(dtold.Rows[irowCount]["AccountNo"].ToString()))
                        {
                            dr = dtAaf.NewRow();
                            var _currencyType = dtold.Rows[irowCount]["Currency"].ToString();

                            #region Columns Manipulation
                            if (_currencyType.ToLower() == "usd")
                            {
                                var amountTotalLoan = dtold.Rows[irowCount]["Total Loan"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Total Loan"].ToString().Trim();
                                dr["TotalLoan"] = ((GetOutputStramount(styles, amountTotalLoan)) * currencyRate).ToString("#,0.00");
                                var amountOB = dtold.Rows[irowCount]["OB"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["OB"].ToString().Trim();
                                dr["OB"] = ((GetOutputStramount(styles, amountOB)) * currencyRate).ToString("#,0.00");
                                var amountMonthlyOB = dtold.Rows[irowCount]["Monthly OB"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Monthly OB"].ToString().Trim();
                                dr["MonthlyOB"] = ((GetOutputStramount(styles, amountMonthlyOB)) * currencyRate).ToString("#,0.00");
                                var amountUDIBalance = dtold.Rows[irowCount]["UDI Balance"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["UDI Balance"].ToString().Trim();
                                dr["UDIBalance"] = ((GetOutputStramount(styles, amountUDIBalance)) * currencyRate).ToString("#,0.00");
                                var amountOrigERV = dtold.Rows[irowCount]["Orig ERV"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Orig ERV"].ToString().Trim();
                                dr["OrigERV"] = ((GetOutputStramount(styles, amountOrigERV)) * currencyRate).ToString("#,0.00");
                                var amountPVRV = dtold.Rows[irowCount]["PVRV"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["PVRV"].ToString().Trim();
                                dr["PVRV"] = ((GetOutputStramount(styles, amountPVRV)) * currencyRate).ToString("#,0.00");
                                var amountOrigGD = dtold.Rows[irowCount]["Orig GD"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Orig GD"].ToString().Trim();
                                dr["OrigGD"] = ((GetOutputStramount(styles, amountOrigGD)) * currencyRate).ToString("#,0.00");
                                var amountPVGD = dtold.Rows[irowCount]["PVGD"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["PVGD"].ToString().Trim();
                                dr["PVGD"] = ((GetOutputStramount(styles, amountPVGD)) * currencyRate).ToString("#,0.00");
                                var amountOriginalAmortizationAAF = dtold.Rows[irowCount]["Orig Amort."].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Orig Amort."].ToString().Trim();
                                dr["OriginalAmortizationAAF"] = ((GetOutputStramount(styles, amountOriginalAmortizationAAF)) * currencyRate).ToString("#,0.00");
                                var amountPaymentScheduleAmortizationAAF = dtold.Rows[irowCount]["Amort. Per Pay Sched."].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Amort. Per Pay Sched."].ToString().Trim();
                                dr["PaymentScheduleAmortizationAAF"] = ((GetOutputStramount(styles, amountPaymentScheduleAmortizationAAF)) * currencyRate).ToString("#,0.00");
                                var amountRepricedAmortization = dtold.Rows[irowCount]["Reprice Amort."].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Reprice Amort."].ToString().Trim();
                                dr["RepricedAmortization"] = ((GetOutputStramount(styles, amountRepricedAmortization)) * currencyRate).ToString("#,0.00");
                                var amountASSETCOST = dtold.Rows[irowCount]["Asset Cost"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Asset Cost"].ToString().Trim();
                                dr["ASSETCOST"] = ((GetOutputStramount(styles, amountASSETCOST)) * currencyRate).ToString("#,0.00");
                                var amountAssetValue = dtold.Rows[irowCount]["Asset Value"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Asset Value"].ToString().Trim();
                                dr["AssetValue"] = ((GetOutputStramount(styles, amountAssetValue)) * currencyRate).ToString("#,0.00");
                                var amountApprovedAmount = dtold.Rows[irowCount]["Approved Amount"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Approved Amount"].ToString().Trim();
                                dr["ApprovedAmount"] = ((GetOutputStramount(styles, amountApprovedAmount)) * currencyRate).ToString("#,0.00");
                                var amountLastPrincipalPay = dtold.Rows[irowCount]["LastPrincipalPay"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["LastPrincipalPay"].ToString().Trim();
                                dr["LastPrincipalPay"] = ((GetOutputStramount(styles, amountLastPrincipalPay)) * currencyRate).ToString("#,0.00");
                                var amountLastInterestPay = dtold.Rows[irowCount]["LastInterestPay"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["LastInterestPay"].ToString().Trim();
                                dr["LastInterestPay"] = ((GetOutputStramount(styles, amountLastInterestPay)) * currencyRate).ToString("#,0.00");
                            }
                            else if (_currencyType.ToLower() == "php")
                            {
                                var amountTotalLoan = dtold.Rows[irowCount]["Total Loan"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Total Loan"].ToString().Trim();
                                dr["TotalLoan"] = (GetOutputStramount(styles, amountTotalLoan)).ToString("#,0.00");
                                var amountOB = dtold.Rows[irowCount]["OB"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["OB"].ToString().Trim();
                                dr["OB"] = (GetOutputStramount(styles, amountOB)).ToString("#,0.00");
                                var amountMonthlyOB = dtold.Rows[irowCount]["Monthly OB"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Monthly OB"].ToString().Trim();
                                dr["MonthlyOB"] = (GetOutputStramount(styles, amountMonthlyOB)).ToString("#,0.00");
                                var amountUDIBalance = dtold.Rows[irowCount]["UDI Balance"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["UDI Balance"].ToString().Trim();
                                dr["UDIBalance"] = (GetOutputStramount(styles, amountUDIBalance)).ToString("#,0.00");
                                var amountOrigERV = dtold.Rows[irowCount]["Orig ERV"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Orig ERV"].ToString().Trim();
                                dr["OrigERV"] = (GetOutputStramount(styles, amountOrigERV)).ToString("#,0.00");
                                var amountPVRV = dtold.Rows[irowCount]["PVRV"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["PVRV"].ToString().Trim();
                                dr["PVRV"] = (GetOutputStramount(styles, amountPVRV)).ToString("#,0.00");
                                var amountOrigGD = dtold.Rows[irowCount]["Orig GD"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Orig GD"].ToString().Trim();
                                dr["OrigGD"] = (GetOutputStramount(styles, amountOrigGD)).ToString("#,0.00");
                                var amountPVGD = dtold.Rows[irowCount]["PVGD"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["PVGD"].ToString().Trim();
                                dr["PVGD"] = (GetOutputStramount(styles, amountPVGD)).ToString("#,0.00");
                                var amountOriginalAmortizationAAF = dtold.Rows[irowCount]["Orig Amort."].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Orig Amort."].ToString().Trim();
                                dr["OriginalAmortizationAAF"] = (GetOutputStramount(styles, amountOriginalAmortizationAAF)).ToString("#,0.00");
                                var amountPaymentScheduleAmortizationAAF = dtold.Rows[irowCount]["Amort. Per Pay Sched."].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Amort. Per Pay Sched."].ToString().Trim();
                                dr["PaymentScheduleAmortizationAAF"] = (GetOutputStramount(styles, amountPaymentScheduleAmortizationAAF)).ToString("#,0.00");
                                var amountRepricedAmortization = dtold.Rows[irowCount]["Reprice Amort."].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Reprice Amort."].ToString().Trim();
                                dr["RepricedAmortization"] = (GetOutputStramount(styles, amountRepricedAmortization)).ToString("#,0.00");
                                var amountASSETCOST = dtold.Rows[irowCount]["Asset Cost"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Asset Cost"].ToString().Trim();
                                dr["ASSETCOST"] = (GetOutputStramount(styles, amountASSETCOST)).ToString("#,0.00");
                                var amountAssetValue = dtold.Rows[irowCount]["Asset Value"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Asset Value"].ToString().Trim();
                                dr["AssetValue"] = (GetOutputStramount(styles, amountAssetValue)).ToString("#,0.00");
                                var amountApprovedAmount = dtold.Rows[irowCount]["Approved Amount"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["Approved Amount"].ToString().Trim();
                                dr["ApprovedAmount"] = (GetOutputStramount(styles, amountApprovedAmount)).ToString("#,0.00");
                                var amountLastPrincipalPay = dtold.Rows[irowCount]["LastPrincipalPay"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["LastPrincipalPay"].ToString().Trim();
                                dr["LastPrincipalPay"] = (GetOutputStramount(styles, amountLastPrincipalPay)).ToString("#,0.00");
                                var amountLastInterestPay = dtold.Rows[irowCount]["LastInterestPay"].ToString().Trim() == "" ? "0" : dtold.Rows[irowCount]["LastInterestPay"].ToString().Trim();
                                dr["LastInterestPay"] = (GetOutputStramount(styles, amountLastInterestPay)).ToString("#,0.00");
                            }
                            else
                            {
                                ErrorLog.AddError("Invalid type of currency column in AAF.");
                            }

                            dr["AccountNo"] = dtold.Rows[irowCount]["AccountNo"].ToString().Trim();
                            dr["ClientName"] = dtold.Rows[irowCount]["Client Name"].ToString().Trim();
                            dr["AO"] = dtold.Rows[irowCount]["AO"].ToString().Trim();
                            dr["FacilityCode"] = dtold.Rows[irowCount]["Prod Type"].ToString().Trim();
                            dr["StatusPERSYSTEM"] = dtold.Rows[irowCount]["Status"].ToString().Trim();
                            dr["ValueDate"] = isValidDate(dtold.Rows[irowCount]["Value Date"].ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[irowCount]["Value Date"].ToString().Trim();
                            dr["FirstDueDate"] = isValidDate(dtold.Rows[irowCount]["FirstDueDate"].ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[irowCount]["FirstDueDate"].ToString().Trim();
                            dr["MaturityDate"] = isValidDate(dtold.Rows[irowCount]["Maturity Date"].ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[irowCount]["Maturity Date"].ToString().Trim();
                            dr["OriginalRate"] = dtold.Rows[irowCount]["Effective Rate"].ToString().Trim() + "%";
                            dr["CurrentRate"] = dtold.Rows[irowCount]["EYAfterReprice"].ToString().Trim() + "%";
                            dr["TermInmonths"] = dtold.Rows[irowCount]["Term"].ToString().Trim();
                            dr["RemainingTermInMonths"] = dtold.Rows[irowCount]["Remaining Term"].ToString().Trim();
                            dr["RepricedDate"] = isValidDate(dtold.Rows[irowCount]["Reprice Date"].ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[irowCount]["Reprice Date"].ToString().Trim();
                            dr["AAFICBSRateType"] = dtold.Rows[irowCount]["Rate Type"].ToString().Trim();
                            var pduedate = dtold.Rows[irowCount]["PastDueDate"].ToString().Trim() != "" ? dtold.Rows[irowCount]["PastDueDate"].ToString().Trim() : "";
                            var itldate = dtold.Rows[irowCount]["ITL Date"].ToString().Trim() != "" ? dtold.Rows[irowCount]["ITL Date"].ToString().Trim() : "";
                            string concat = "";
                            concat = pduedate == "" ? concat = itldate : itldate == "" ? concat = pduedate : concat = pduedate + " & " + itldate;
                            dr["PastDueDateITLDateExtractedPerAAFICBS"] = concat;
                            dr["PerFaMSAAFICBSIndustryCode"] = dtold.Rows[irowCount]["Industry Code"].ToString().Trim();
                            dr["IndustryHeader"] = dtold.Rows[irowCount]["Industry Detail"].ToString().Trim();
                            dr["IndustryDetail"] = dtold.Rows[irowCount]["Industry Detail"].ToString().Trim();
                            dr["Collateral"] = dtold.Rows[irowCount]["Collateral"].ToString().Trim();
                            dr["PerFaMSAAFICBSAssetSizeInwords"] = dtold.Rows[irowCount]["Asset Size"].ToString().Trim();
                            dr["ICBSGLCODE"] = dtold.Rows[irowCount]["GL Code"].ToString().Trim();
                            dr["ICBSGLName"] = dtold.Rows[irowCount]["GL Desc"].ToString().Trim();
                            dr["COSTCENTER"] = dtold.Rows[irowCount]["Cost Center"].ToString().Trim();
                            dr["BRANCHNAMEOFCOSTCENTERPERSYSTEM"] = dtold.Rows[irowCount]["Branch Per Cost Center"].ToString().Trim();
                            dr["OriginatingBranchBooked"] = dtold.Rows[irowCount]["Orig. Branch"].ToString().Trim();
                            dr["NationalityPerICBS"] = dtold.Rows[irowCount]["Nationality"].ToString().Trim();
                            dr["NextRateReviewDateExtractedPerFaMSAAFICBS"] = isValidDate(dtold.Rows[irowCount]["Next Review Date"].ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[irowCount]["Next Review Date"].ToString().Trim();
                            dr["TAXID"] = dtold.Rows[irowCount]["Tax ID"].ToString().Trim();
                            dr["CustomerTypeDescription"] = dtold.Rows[irowCount]["Borrower Type"].ToString().Trim();
                            dr["RELCode"] = dtold.Rows[irowCount]["REL Code"].ToString().Trim();
                            dr["REECode"] = dtold.Rows[irowCount]["REE Code"].ToString().Trim();
                            dr["REEAddtlInfo"] = dtold.Rows[irowCount]["REEAddtl.Info"].ToString().Trim();
                            dr["AcctRef"] = dtold.Rows[irowCount]["Acct. Ref."].ToString().Trim();
                            dr["RPT"] = dtold.Rows[irowCount]["RPT"].ToString().Trim();
                            dr["LeaseType"] = dtold.Rows[irowCount]["Lease Type"].ToString().Trim();
                            dr["ICBSCollateralCode"] = dtold.Rows[irowCount]["ICBS Collateral Code"].ToString().Trim();
                            dr["CPNumber"] = dtold.Rows[irowCount]["CP Number"].ToString().Trim();
                            dr["PrincipalPayDate"] = isValidDate(dtold.Rows[irowCount]["Principal Pay Date"].ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[irowCount]["Principal Pay Date"].ToString().ToString().Trim();
                            dr["LastInterestPayDate"] = isValidDate(dtold.Rows[irowCount]["Last Interest Pay Date"].ToString().ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[irowCount]["Last Interest Pay Date"].ToString().ToString().Trim();

                            dtAaf.Rows.Add(dr);
                            #endregion
                        }

                        curRow++;
                        aafWorker.ReportProgress(irowCount++ * 100 / lineCount, progressArray);
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError(string.Format("Error Found at row {0} in AAF. Error Message: {1} ", irowCount.ToString(), ex.Message.ToString()));
                        irowCount++;
                        continue;
                    }
                }

                dtAaf.Columns.Add("RecordDate");
                dtAaf.Columns.Add("Reason");
                dtAaf.Columns.Add("RawFiles");
                dtAaf.Columns.Add("isDeleted");
                dtAaf.Columns.Add("UserName");
                dtAaf.Columns.Add("TransDate");
                dtAaf.Columns.Add("isConsolidated");

                for (int i = 0; i < dtAaf.Rows.Count; i++)
                {
                    try
                    {
                        dtAaf.Rows[i]["RecordDate"] = Convert.ToDateTime(AAFDateParameter);//from the date of the files
                        dtAaf.Rows[i]["Reason"] = "";//add reason for changes
                        dtAaf.Rows[i]["RawFiles"] = aafFileName;//save the failename of the files, use to validate if the current file was already inserted in the database
                        dtAaf.Rows[i]["isDeleted"] = false;//tagging for soft delete
                        dtAaf.Rows[i]["UserName"] = UserName;//current user logged
                        dtAaf.Rows[i]["TransDate"] = DateTime.Now.ToShortDateString();//date inserted
                        dtAaf.Rows[i]["isConsolidated"] = true;//For the Future purpose
                        dtAaf.Rows[i]["SYSTEM"] = "AAF";
                        dtAaf.Rows[i]["PreviousMonthsNPLTaggingByRisk"] = "";
                        dtAaf.Rows[i]["SpecificRequiredProvisions"] = "";
                        dtAaf.Rows[i]["GeneralRequiredProvisions"] = "";

                        var _productdescription = dtAaf.Rows[i]["facilitycode"].ToString().ToUpper().Trim();
                        var _statuscode = dtAaf.Rows[i]["statuspersystem"].ToString().ToUpper().Trim();
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError(ex.Message.ToString());
                        continue;
                    }
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            #endregion
        }
        #endregion
        #region FAMS Worker

        private void famsWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = string.Format("Status: Reading at row {0} out of {1}", curRow, lineCount);
        }

        private void famsWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Cancelled";

                //isICBSExist = false;
                //isAAFExist = false;
                //isFAMSExist = false;

                if (isPreviousData)
                {
                    MetroMessageBox.Show(this, "\r\n" + "\"As Of Date\" Column is invalid \r\n" + "Sorry! System will not allow the user to insert a record from previous Months or Year.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (_InValidDate)
                {
                    MetroMessageBox.Show(this, "\r\nFAMS Raw File date is Invalid Date.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (!_isValidAafRawFile)
                {
                    MetroMessageBox.Show(this, "\r\nUnable to proccess, Due to invalid FAMS Raw File.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (isfamsPreviousDate)
                {
                    MetroMessageBox.Show(this, "\r\nUnable to proccess record, Date must be greater than the value base on the configured implementation date.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, e.Error.Message.ToString() + "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                ConsoMenu.Enabled = true;
                btnSearch.Enabled = true;
                dtFams = new DataTable("FAMSDATA");//Initialize again the datatable to avoid Error
                return;
            }
            else if (e.Error != null)
            {
                //ConsoMenu.Enabled = true;
                //btnSearch.Enabled = true;
                //IsBusy = false;

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    ErrorLog.AddError("FaMS RAW File is already opened exclusively by another user, or you need permission to view and write its data. NOTE: Please Close or Save all Open Documents.");
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    ErrorLog.AddError("Invalid FAMS excel template.");
                }
                else if (!_isValidAafRawFile)
                {
                    ErrorLog.AddError("Unable to proccess, Due to invalid FAMS Raw File.");
                }
                else
                {
                    ErrorLog.AddError(e.Error.Message.ToString());
                }
                //pnlWaitInfo.Visible = false;
                //lblWaitInfo.Text = "";
                //lblWaitStatus.Text = "Status: Error Encountered while processing";
                //dtFams = new DataTable("FAMSDATA");//Initialize again the datatable to avoid Error
            }
            else
            {
                var todate = DateTime.Today;
                var icbsparameter = new DateTime();
                var aafparameter = new DateTime();
                var famsparameter = new DateTime();

                if (ICBSDateParameter != "")
                {
                    icbsparameter = Convert.ToDateTime(ICBSDateParameter);
                }
                if (AAFDateParameter != "")
                {
                    aafparameter = Convert.ToDateTime(AAFDateParameter);
                }
                if (FAMSDateParameter != "")
                {
                    famsparameter = Convert.ToDateTime(FAMSDateParameter);
                }

                if ((icbsparameter < Convert.ToDateTime(NTC_DateTime)) || (aafparameter < Convert.ToDateTime(NTC_DateTime)) || (famsparameter < Convert.ToDateTime(NTC_DateTime)))
                {
                    ErrorLog.AddError("Unable to proccess record, Date must be greater than the value base on the configured implementation date.");
                }

                if ((ICBSDateParameter != AAFDateParameter) || (FAMSDateParameter != AAFDateParameter))
                {
                    ErrorLog.AddError("ICBS \"As Of Date\" And AAF \"As Of Date\" and FaMS \"As Of Date\" is not valid. Date should be the same.");
                }

                if (ErrorLog.CountError() > 0)
                {
                    icbsWorker.Dispose();
                    aafWorker.Dispose();
                    famsWorker.Dispose();
                    Currencyworker.Dispose();
                    pnlWaitInfo.Visible = false;
                    lblBusy.Text = "";
                    IsBusy = false;
                    ConsoMenu.Enabled = true;
                    btnSearch.Enabled = true;
                    mre = new ManualResetEvent(false);
                    DialogResult diag = MetroMessageBox.Show(this, "\r\nValidation Error has been completed. " + ErrorLog.CountError().ToString() + " Error(s) found. Kindly review the errors log. \r\nClick OK Button to open the Notepad.", "Error Found", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    if (diag == DialogResult.OK)
                    {
                        ErrorLog.GetLogFilePath();
                    }
                    return;
                }
                else
                {
                    Thread.Sleep(100);

                    progressArray = new string[5];
                    lineCount = 0;
                    lblWaitInfo.Text = "Inserting records to DataBase, Please wait...";
                    lblWaitStatus.Text = "Status: Processing...";

                    consolidateWorker = new BackgroundWorker();
                    consolidateWorker.WorkerReportsProgress = true;
                    consolidateWorker.WorkerSupportsCancellation = true;
                    consolidateWorker.DoWork += new DoWorkEventHandler(consolidateWorker_DoWork);
                    consolidateWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(consolidateWorker_RunWorkerCompleted);
                    consolidateWorker.ProgressChanged += new ProgressChangedEventHandler(consolidateWorker_ProgressChanged);
                    consolidateWorker.RunWorkerAsync();
                    mre.Set(); //Set the first backgroundworker
                }
            }
        }

        private void famsWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            mre.WaitOne(); // wait to finish the current backgroundworkers.
            IsBusy = true;
            #region For Fams
            //try
            //{
            string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=yes;IMEX=1;'", _FamsPath);
            famsFileName = Path.GetFileName(_FamsPath);
            using (OleDbConnection conn = new OleDbConnection(connString))
            {
                conn.Open();
                OleDbCommand cmd = new OleDbCommand();
                DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                if (dbSchema == null || dbSchema.Rows.Count < 1)
                {
                    ErrorLog.AddError("Error: Could not determined the name of the worksheet.");
                }

                string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + worksheetname + "] WHERE [BDO LEASING AND FINANCE, INC] <> ''", conn);
                DataTable dtold = new DataTable(worksheetname);
                da.Fill(dtold);

                #region Remove Unwanted columns
                dtold.Columns.Remove("F1");
                dtold.Columns.Remove("F4");
                dtold.Columns.Remove("F6");
                dtold.Columns.Remove("F8");
                dtold.Columns.Remove("F9");
                dtold.Columns.Remove("F13");
                dtold.Columns.Remove("F14");
                dtold.Columns.Remove("F15");
                dtold.Columns.Remove("F16");
                dtold.Columns.Remove("F17");
                dtold.Columns.Remove("F18");
                dtold.Columns.Remove("F21");
                dtold.Columns.Remove("F22");
                dtold.Columns.Remove("F23");
                dtold.Columns.Remove("F24");
                dtold.Columns.Remove("F25");
                dtold.Columns.Remove("F26");
                dtold.Columns.Remove("F27");
                dtold.Columns.Remove("F28");
                dtold.Columns.Remove("F29");
                dtold.Columns.Remove("F30");
                dtold.Columns.Remove("F31");
                dtold.Columns.Remove("F32");
                dtold.Columns.Remove("F33");
                dtold.Columns.Remove("F34");
                dtold.Columns.Remove("F35");
                dtold.Columns.Remove("F36");
                dtold.Columns.Remove("F44");

                #endregion

                var isValidRawFile = dtold.Rows[0][0].ToString().Trim().ToLower().Contains("factored receivable");

                var AsOfDate = String.Format("{0:d}", Convert.ToDateTime(dtold.Rows[1][0].ToString()).ToShortDateString().ToString());

                if (Convert.ToDateTime(AsOfDate) < Convert.ToDateTime(NTC_DateTime))
                {
                    ErrorLog.AddError("Unable to proccess record, Date must be greater than the value base on the configured implementation date.");
                }

                if (!isValidDate(AsOfDate))
                {
                    ErrorLog.AddError("FAMS Raw File date is Invalid Date.");
                }
                else
                {
                    if ((Convert.ToDateTime(AsOfDate) >= Convert.ToDateTime(NTC_DateTime)) && (Convert.ToDateTime(NTC_DateTime) <= DateTime.Now) && isValidRawFile)
                    {
                        FAMSDateParameter = AsOfDate; //Get As Of DATE of generated File
                    }
                    else
                    {
                        ErrorLog.AddError("FAMS Raw File date is Invalid Date.");
                    }
                }

                DataRow delrow0 = dtold.Rows[0];
                delrow0.Delete();
                delrow0.AcceptChanges();
                DataRow delrow1 = dtold.Rows[0];
                delrow1.Delete();
                delrow1.AcceptChanges();
                DataRow delrow2 = dtold.Rows[0];
                delrow2.Delete();
                delrow2.AcceptChanges();

                var startRow = 0;
                DataRow dr = null;
                //Convert Row 3 value as a header of the DataTable
                foreach (DataColumn dc in dtold.Columns)
                {
                    dc.ColumnName = dtold.Rows[0][dc].ToString();
                }

                DataRow delrow3 = dtold.Rows[0];
                delrow3.Delete();
                delrow3.AcceptChanges();

                lineCount = dtold.Rows.Count;
                var irowCount = 0;

                foreach (DataRow row in dtold.Rows)
                {
                    try
                    {
                        progressArray[0] = (irowCount * 100 / lineCount).ToString(); // percent
                        progressArray[1] = "Reading FaMS RAW File, Please wait..."; //header text
                        progressArray[2] = "Validating Columns, Please wait..."; //Status
                        progressArray[3] = "";// i.ToString(); //column
                        progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                        var code = dtold.Rows[startRow].ItemArray[0].ToString().Trim();//"Receivables"

                        int _code = 0;
                        bool validCode = int.TryParse(code, out _code);

                        if (validCode)
                        {
                            var ReceivablesAmount = Convert.ToDouble(dtold.Rows[startRow].ItemArray[6]);//"Receivables"
                            var status = dtold.Rows[startRow].ItemArray[3].ToString();//["Status"].ToString();

                            if (ReceivablesAmount <= 0 || status == "PAST DUE" || string.IsNullOrEmpty(code))
                            {
                                startRow++;
                                continue;
                            }
                            else
                            {
                                dr = dtFams.NewRow();

                                dr["SYSTEM"] = "FAMS";
                                dr["AccountNo"] = dtold.Rows[startRow]["Client Code"].ToString().Trim();
                                dr["ClientName"] = dtold.Rows[startRow]["Client Name"].ToString().Trim();
                                dr["AO"] = dtold.Rows[startRow]["Account Officer"].ToString().Trim();
                                dr["StatusPERSYSTEM"] = dtold.Rows[startRow]["Status"].ToString().Trim();
                                dr["ValueDate"] = isValidDate(dtold.Rows[startRow]["From"].ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[startRow]["From"].ToString().Trim();
                                dr["MaturityDate"] = isValidDate(dtold.Rows[startRow]["To"].ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[startRow]["To"].ToString().Trim();
                                var TotalLoan = dtold.Rows[startRow]["Investment Limit"].ToString().Trim() == "" ? "0" : dtold.Rows[startRow]["Investment Limit"].ToString().Trim();
                                dr["TotalLoan"] = (GetOutputStramount(styles, TotalLoan)).ToString("#,0.00");
                                var OB = dtold.Rows[startRow]["Receivables"].ToString().Trim() == "" ? "0" : dtold.Rows[startRow]["Receivables"].ToString().Trim();
                                dr["OB"] = (GetOutputStramount(styles, OB)).ToString("#,0.00");
                                var MonthlyOB = dtold.Rows[startRow]["Receivables"].ToString().Trim() == "" ? "0" : dtold.Rows[startRow]["Receivables"].ToString().Trim();
                                dr["MonthlyOB"] = (GetOutputStramount(styles, MonthlyOB)).ToString("#,0.00");
                                var ClientsEquity = dtold.Rows[startRow]["Client's Equity Of Unpaid Invoices"].ToString().Trim() == "" ? "0" : dtold.Rows[startRow]["Client's Equity Of Unpaid Invoices"].ToString().Trim();
                                dr["ClientsEquity"] = (GetOutputStramount(styles, ClientsEquity)).ToString("#,0.00");
                                var AccruedInterestReceivable = dtold.Rows[startRow]["Discount Charge - Accrual"].ToString().Trim() == "" ? "0" : dtold.Rows[startRow]["Discount Charge - Accrual"].ToString().Trim();
                                dr["AccruedInterestReceivable"] = (GetOutputStramount(styles, AccruedInterestReceivable)).ToString("#,0.00");
                                dr["OriginalRate"] = dtold.Rows[irowCount]["Current DC%"].ToString().Trim(); //dtold.Rows[startRow]["Current DC%"].ToString();
                                dr["CurrentRate"] = dtold.Rows[irowCount]["Current DC%"].ToString().Trim(); //dtold.Rows[startRow]["Current DC%"].ToString();
                                dr["TermInmonths"] = dtold.Rows[startRow]["Credit Term"].ToString().Trim();
                                dr["PerFaMSAAFICBSIndustryCode"] = dtold.Rows[startRow]["Industry Code"].ToString().Trim();
                                dr["IndustryHeader"] = dtold.Rows[startRow]["Industry Details / Description"].ToString().Trim();
                                dr["IndustryDetail"] = dtold.Rows[startRow]["Industry Details / Description"].ToString().Trim();
                                dr["PerFaMSAAFICBSAssetSizeInwords"] = dtold.Rows[startRow]["Size Of Firm / Asset Size"].ToString().Trim();
                                dr["NextRateReviewDateExtractedPerFaMSAAFICBS"] = isValidDate(dtold.Rows[startRow]["To"].ToString().Trim()) == false ? "01/01/1900" : dtold.Rows[startRow]["Review Date"].ToString().Trim();
                                dr["PreviousMonthsNPLTaggingByRisk"] = "";
                                dr["SpecificRequiredProvisions"] = "";
                                dr["GeneralRequiredProvisions"] = "";
                                dr["RecordDate"] = Convert.ToDateTime(FAMSDateParameter);
                                dr["Reason"] = "";
                                dr["RawFiles"] = famsFileName;
                                dr["isDeleted"] = false;
                                dr["isConsolidated"] = true;
                                dr["UserName"] = UserName;
                                dr["TransDate"] = DateTime.Now.ToShortDateString();

                                famsWorker.ReportProgress(irowCount++ * 100 / lineCount, progressArray);
                            }

                            dtFams.Rows.Add(dr);
                            startRow++;
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError(string.Format("Error found at row {0} in FAMS. Error message: {1}", startRow.ToString(), ex.ToString()));
                        startRow++;
                        continue;
                    }
                }
            }
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            #endregion
        }

        #endregion
        #region Conso Worker

        private void consolidateWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;
            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = "In progress...";
        }

        private void consolidateWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                ConsoMenu.Enabled = true;
                btnSearch.Enabled = true;

                //isICBSExist = false;
                //isAAFExist = false;
                //isFAMSExist = false;

                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Cancelled";

                if (dateNotTheSame)
                {
                    MetroMessageBox.Show(this, "\r\nICBS \"As Of Date\" And AAF \"As Of Date\" and FaMS \"As Of Date\" is not valid. Date should be the same.", "Invalid As Of Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (isPreviousDate)
                {
                    MetroMessageBox.Show(this, "\r\nUnable to proccess record, Date must be greater than the value base on the configured implementation date.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "Error Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                //dtConso = new DataTable();//Initialize again the datatable to avoid Error
                return;
            }
            else if (e.Error != null)
            {
                //ConsoMenu.Enabled = true;
                //btnSearch.Enabled = true;

                //pnlWaitInfo.Visible = false;
                //lblWaitInfo.Text = "";
                //lblWaitStatus.Text = "Status: Error Encountered while processing";
                //dtConso = new DataTable();//Initialize again the datatable to avoid Error
                //IsBusy = false;
                ErrorLog.AddError("Error during consolidation proccess, Error message: " + e.Error.Message.ToString());
                //MetroMessageBox.Show(this, "Error Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while Consolidating the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //return;
            }
            else
            {
                pnlWaitInfo.Visible = false;

                //isICBSExist = false;
                //isAAFExist = false;
                //isFAMSExist = false;
                //================================================================

                //updateGLworker
                lblWaitInfo.Text = "Updating the GL Code and GL Description, Please wait...";
                lblWaitStatus.Text = "Status: Processing...";

                updateGLworker = new BackgroundWorker();
                updateGLworker.WorkerReportsProgress = true;
                updateGLworker.WorkerSupportsCancellation = true;
                updateGLworker.DoWork += new DoWorkEventHandler(updateGLworker_DoWork);
                updateGLworker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(updateGLworker_RunWorkerCompleted);
                updateGLworker.ProgressChanged += new ProgressChangedEventHandler(updateGLworker_ProgressChanged);
                updateGLworker.RunWorkerAsync();
                mre.Set(); //Set the first backgroundworker
            }
        }

        private void consolidateWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            mre.WaitOne(); // wait to finish the current backgroundworkers.
            IsBusy = true;
            try
            {
                if (!dateNotTheSame)
                {
                    object[] data = { dtIcbs, dtAaf, dtFams };
                    consolidatorRepository.BulkInsert(data, ICBSDateParameter);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
        #region Update GL ++++ this part, if updating of GL will not success then you can reupdate the GL Code And Description Manualy just GO to maintenance and click the GL Code and Description
        private void updateGLworker_DoWork(object sender, DoWorkEventArgs e)
        {
            mre.WaitOne(); // wait to finish the current backgroundworkers.
            IsBusy = true;
            try
            {
                var startRow = 0;
                foreach (DataRow rec in dtGLCODE.Rows)
                {
                    try
                    {
                        if (consolidatorRepository.isGLCodeExist(rec["Status"].ToString().Trim(), rec["ProductDesc"].ToString().Trim(), rec["System"].ToString().Trim()))
                        {
                            var consoForGL = new BDOLF_Consolidator();

                            consoForGL.ICBSGLCode = rec["GLCode"].ToString().Trim();
                            consoForGL.ICBSGLName = rec["GLName"].ToString().Trim();
                            consolidatorRepository.UpdateConsolidator(consoForGL, rec["Status"].ToString().Trim(), rec["ProductDesc"].ToString().Trim(), rec["System"].ToString().Trim(), true);
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError(string.Format("Error found at row {0} during the update of GL Code and Description . Error message: {1}", startRow.ToString(), ex.ToString()));
                        startRow++;
                        continue;
                    }
                }

                #region 
                //AS per sir denver
                foreach (DataRow drRowusd in dtUSDollar.Rows)
                {
                    var conso = new BDOLF_Consolidator();

                    var usdAcctNo = drRowusd[1].ToString().Trim(); // Get the usdaccount number from usd excel file
                    var usdSystem = drRowusd[0].ToString().Trim();

                    conso.SYSTEM = usdSystem;
                    conso.AccountNo = usdAcctNo; // put the usd accountno in a an object

                    if (usdSystem.ToUpper() != "ICBS") continue; // filtered if accountno is ICBS. Get only all accountno that is tag as ICBS

                    var returnVal = consolidatorRepository.GetByCode(conso); //Get the specific record
                    var tempGLName = "";
                    if (returnVal != null)
                    {
                        var nctStatusPerSystem = returnVal.StatusPerSystem.Trim();
                        var nctFacilityCode = returnVal.FacilityCode.Trim();
                        var nctSYSTEM = returnVal.SYSTEM.Trim();

                        foreach (DataRow rec in dtGLCODE.Rows) // iterate the record of GLCODE and DESCRIPTION
                        {
                            //Filter the record by status, ProductDesc,ICBS,GLNAME with usb contains, Just to get the USD GLName
                            // because in the database there are multiple GMACT or GLCode with the same STATUSPersytem and Product description. 
                            //That's why we doing this kind of filteration to help us to identify that the GLCode that has contains USD in GLNAme.
                            if (nctStatusPerSystem == rec["Status"].ToString().Trim() && nctFacilityCode == rec["ProductDesc"].ToString().Trim().ToUpper() && nctSYSTEM == "ICBS" && rec["GLName"].ToString().Contains("USD"))
                            {
                                tempGLName = rec["GLName"].ToString().Trim();
                                break;
                            }
                        }

                        var startRowInner = 0;
                        foreach (DataRow rec in dtGLCODE.Rows)
                        {
                            try
                            {

                                //Compare the data from the NTCConsolidator table in the database and from the Corresponding Table in the Database.
                                //If data matched, the update the current data in ntcconsolidator table. the new values was came from the filtered data in CorrespondingGL table
                                if (nctStatusPerSystem == rec["Status"].ToString().Trim() && nctFacilityCode == rec["ProductDesc"].ToString().Trim().ToUpper() && nctSYSTEM == "ICBS")
                                {
                                    var consoForGL = new BDOLF_Consolidator();

                                    consoForGL.ICBSGLCode = rec["GLCode"].ToString().Trim();
                                    consoForGL.ICBSGLName = tempGLName;// rec["GLName"].ToString().Trim();
                                    consoForGL.AccountNo = usdAcctNo;//rec["ProductDesc"].ToString().Trim();
                                    consoForGL.SYSTEM = usdSystem;// rec["Status"].ToString().Trim();
                                    consolidatorRepository.UpdateConsolidator(consoForGL, "", "", "", false);
                                }

                            }
                            catch (Exception ex)
                            {
                                ErrorLog.AddError(string.Format("Error found at row {0} during the update of GL Code and Description . Error message: {1}", startRowInner.ToString(), ex.ToString()));
                                startRowInner++;
                                continue;
                            }
                        }
                    }
                }

                #endregion

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void updateGLworker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                //ConsoMenu.Enabled = true;
                //btnSearch.Enabled = true;

                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Cancelled";

                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and couldn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else if (e.Error != null)
            {

                //pnlWaitInfo.Visible = false;
                //lblWaitInfo.Text = "";
                //lblWaitStatus.Text = "Status: Error Encountered while processing";
                // IsBusy = false;
                ErrorLog.AddError("Error upon updating the GLCode and Description. \r\n" + e.Error.Message.ToString());
                //MetroMessageBox.Show(this, "Error Message: " + "Error upon updating the GLCode and Description. \r\n" + e.Error.Message.ToString() + "\r\n\r\nError encountered while updating the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                ConsoMenu.Enabled = true;
                btnSearch.Enabled = true;
                pnlWaitInfo.Visible = false;
                IsBusy = false;
                lblBusy.Text = "";
                icbsWorker.Dispose();
                aafWorker.Dispose();
                famsWorker.Dispose();
                Currencyworker.Dispose();
                ExportWorker.Dispose();
                updateGLworker.Dispose();
                mre = new ManualResetEvent(false);
                // Thread.Sleep(1000);

                if (ErrorLog.CountError() > 0)
                {
                    //ResetParameter();
                    frmConsolidator_Load(null, null);
                    DialogResult diag = MetroMessageBox.Show(this, "\r\nValidation Error has been completed. " + ErrorLog.CountError().ToString() + " Error(s) found. Kindly review the errors log. \r\nClick OK Button to open the Notepad.", "Error Found", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    if (diag == DialogResult.OK)
                    {
                        ErrorLog.GetLogFilePath();
                    }
                    return;
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\nData was successfully consolidated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    GetConsolidator();
                }
            }
        }

        private void ResetParameter()
        {
            #region Properties
            UserName = "";
            dbUserName = "";
            dbPassword = "";
            param = new string[10];
            _AafPath = "";
            _FamsPath = "";
            _IcbsPath = "";
            _GLCodeAndDescPath = "";
            _USDollarPath = "";
            NTC_DateTime = "";
            hasDollarError = false;
            isNoData = false;
            source = new BindingSource();
            dtTmp = new DataTable();
            dtcompare = new DataTable();
            dtConso = new DataTable();
            dtGLCODE = new DataTable();
            dtQTable = new DataTable();
            dtIcbs = new DataTable();
            dtAaf = new DataTable();
            dtFams = new DataTable();
            dtExport = new DataTable();
            dtUSDollar = new DataTable();
            isIcbsPreviousDate = false;
            isAffPreviousDate = false;
            isfamsPreviousDate = false;
            isPreviousDate = false;
            dateNotTheSame = false;
            lineCount = 0;
            iCounter = 1;
            isInProcess = false;
            _InValidDate = false;
            _isValidAafRawFile = true;
            _isValidIcbsRawFile = true;
            isPreviousData = false;
            ICBSDateParameter = "";
            AAFDateParameter = "";
            FAMSDateParameter = "";
            curRow = 0;
            currencyRate = 0.0M;
            progressArray = new string[5];
            ExportFilename = "";
            isICBSReadyToProcess = false;
            isAAFReadyToProcess = false;
            isFAMSReadyToProcess = false;
            IsBusy = false;

            isOnloadErr = false;
            NumberStyles styles = new NumberStyles();

            icbsWorker = new BackgroundWorker();
            Currencyworker = new BackgroundWorker();

            consoModel = new AAFModel();
            famsmodel = new AAFModel();
            icbsmodel = new AAFModel();
            aafmodel = new AAFModel();

            icbsFileName = "";
            famsFileName = "";
            aafFileName = "";
            isOnloadErrmsg = "";

            frmconsolidator = null;
            #endregion
        }

        private void updateGLworker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;
            lblWaitInfo.Text = labelsreports[1];
            lblWaitStatus.Text = "In progress...";
        }

        #endregion

        protected bool isValidDate(String date)
        {
            try
            {
                DateTime dt = DateTime.Parse(date);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void HideColumns()
        {
            dgvConsolidator.Columns["TransID"].Visible = false;
            dgvConsolidator.Columns["RawFiles"].Visible = false;
            dgvConsolidator.Columns["isConsolidated"].Visible = false;
            dgvConsolidator.Columns["isDeleted"].Visible = false;
            dgvConsolidator.Columns["UserName"].Visible = false;
            dgvConsolidator.Columns["TransDate"].Visible = false;
            dgvConsolidator.Columns["Reason"].Visible = false;
            dgvConsolidator.Columns["RecordDate"].Visible = false;
        }

        public void GetConsolidator()
        {
            try
            {
                lblWaitInfo.Text = "Please wait while loading records...";
                lblWaitStatus.Text = "Status: Fetching Data.";

                var dte = ICBSDateParameter == "" ? DateTime.Now.ToShortDateString() : ICBSDateParameter;

                Program.NTC_DateFrom = dte;

                var query = consolidatorRepository.GetAll(dte, "", false).ToList();
                source.DataSource = query;
                lblInfo.Text = "Total Records: " + string.Format("{0:n0}", query.ToList().Count);

                if (query.Count() <= 0)
                {
                    var retval = GetColumnNames().ToList();

                    dtTmp = retval.ToDataTable();
                    dtcompare = dtTmp.ToLowerDataTable();

                    dgvConsolidator.DataSource = dtTmp;
                    HideColumns();
                }
                else
                {
                    dgvConsolidator.DataSource = source;
                    dgvConsolidator.Refresh();

                    HideColumns();
                }
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "Error Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while loading the record, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private DataTable FaMSDataTable()
        {
            dtFams = new DataTable("FAMSDATA");

            dtFams.Columns.Add("system");
            dtFams.Columns.Add("RecordDate");
            dtFams.Columns.Add("Reason");
            dtFams.Columns.Add("RawFiles");
            dtFams.Columns.Add("isDeleted");
            dtFams.Columns.Add("UserName");
            dtFams.Columns.Add("TransDate");
            dtFams.Columns.Add("isConsolidated");
            dtFams.Columns.Add("AccountNo");
            dtFams.Columns.Add("ClientName");
            dtFams.Columns.Add("AO");
            dtFams.Columns.Add("StatusPERSYSTEM");
            dtFams.Columns.Add("ValueDate");
            dtFams.Columns.Add("MaturityDate");
            dtFams.Columns.Add("TotalLoan");
            dtFams.Columns.Add("OB");
            dtFams.Columns.Add("MonthlyOB");
            dtFams.Columns.Add("ClientsEquity");
            dtFams.Columns.Add("AccruedInterestReceivable");
            dtFams.Columns.Add("OriginalRate");
            dtFams.Columns.Add("CurrentRate");
            dtFams.Columns.Add("TermInmonths");
            dtFams.Columns.Add("PerFaMSAAFICBSIndustryCode");
            dtFams.Columns.Add("IndustryHeader");
            dtFams.Columns.Add("IndustryDetail");
            dtFams.Columns.Add("PerFaMSAAFICBSAssetSizeInwords");
            dtFams.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS");
            dtFams.Columns.Add("PreviousMonthsNPLTaggingByRisk");
            dtFams.Columns.Add("SpecificRequiredProvisions");
            dtFams.Columns.Add("GeneralRequiredProvisions");
            return dtFams;
        }

        private static decimal GetOutputStramount(NumberStyles styles, string amount)
        {
            var _amount = decimal.Parse(amount, styles).ToString("#,0.00;-#,0.00");
            return decimal.Parse(_amount);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            pnlWaitInfo.Visible = false;
            IsBusy = false;

            Initializer();
            GetConsolidator();
        }

        private void Search(string keyword)
        {
            if (!string.IsNullOrEmpty(keyword))
            {
                DataView dv = new DataView(dtConso);
                dv.RowFilter = "AccountNo LIKE '%" + keyword + "%' OR ClientName LIKE '%" + keyword + "%' OR ICBSGLCode LIKE '%" + keyword + "%' OR SYSTEM LIKE '%" + keyword + "%' OR UserName LIKE '%" + keyword + "%'";

                dgvConsolidator.DataSource = dv;
            }
            else
            {
                dgvConsolidator.DataSource = dtConso;
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (isInProcess) return;
            Search(txtSearch.Text);
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            //  if (bgWorker.IsBusy) lblBusy.Text = "Busy processing, Please wait...";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //if (!bgWorker.IsBusy)
            //{
            //    lblBusy.Text = "No operation in progress to cancel";
            //    return;
            //}

            //DialogResult response = MetroMessageBox.Show(this, "\r\n\r\n Are you sure you want to cancel the process?", "Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //if (response == DialogResult.Yes)
            //{
            //    this.bgWorker.CancelAsync();
            //    progressConso.Visible = false;
            //    lblPercent.Visible = false;
            //    lblBusy.Visible = false;
            //    MetroMessageBox.Show(this, "\r\n\r\nThe operation has been cancelled", "Cancel", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            //}
        }

        private void btnExport_Click(object sender, EventArgs e)
        {

        }

        private DataTable AAFDataTable()
        {
            dtAaf = new DataTable("AAFDATA");

            dtAaf.Columns.Add("SYSTEM");
            dtAaf.Columns.Add("AccountNo");
            dtAaf.Columns.Add("ClientName");
            dtAaf.Columns.Add("AO");
            dtAaf.Columns.Add("FacilityCode");
            dtAaf.Columns.Add("StatusPERSYSTEM");
            dtAaf.Columns.Add("ValueDate");
            dtAaf.Columns.Add("FirstDueDate");
            dtAaf.Columns.Add("MaturityDate");
            dtAaf.Columns.Add("TotalLoan");
            dtAaf.Columns.Add("OB");
            dtAaf.Columns.Add("MonthlyOB");
            dtAaf.Columns.Add("UDIBalance");
            dtAaf.Columns.Add("OrigERV");
            dtAaf.Columns.Add("PVRV");
            dtAaf.Columns.Add("OrigGD");
            dtAaf.Columns.Add("PVGD");
            dtAaf.Columns.Add("OriginalRate");
            dtAaf.Columns.Add("CurrentRate");
            dtAaf.Columns.Add("TermInmonths");
            dtAaf.Columns.Add("RemainingTermInMonths");
            dtAaf.Columns.Add("OriginalAmortizationAAF");
            dtAaf.Columns.Add("PaymentScheduleAmortizationAAF");
            dtAaf.Columns.Add("RepricedDate");
            dtAaf.Columns.Add("AAFICBSRateType");
            dtAaf.Columns.Add("RepricedAmortization");
            dtAaf.Columns.Add("PastDueDateITLDateExtractedPerAAFICBS");
            dtAaf.Columns.Add("PerFaMSAAFICBSIndustryCode");
            dtAaf.Columns.Add("IndustryHeader");
            dtAaf.Columns.Add("IndustryDetail");
            dtAaf.Columns.Add("Collateral");
            dtAaf.Columns.Add("PerFaMSAAFICBSAssetSizeInwords");
            dtAaf.Columns.Add("ICBSGLCODE");
            dtAaf.Columns.Add("ICBSGLName");
            dtAaf.Columns.Add("COSTCENTER");
            dtAaf.Columns.Add("BRANCHNAMEOFCOSTCENTERPERSYSTEM");
            dtAaf.Columns.Add("OriginatingBranchBooked");
            dtAaf.Columns.Add("NationalityPerICBS");
            dtAaf.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS");
            dtAaf.Columns.Add("TAXID");
            dtAaf.Columns.Add("CustomerTypeDescription");
            dtAaf.Columns.Add("RELCode");
            dtAaf.Columns.Add("REECode");
            dtAaf.Columns.Add("REEAddtlInfo");
            dtAaf.Columns.Add("AcctRef");
            dtAaf.Columns.Add("RPT");
            dtAaf.Columns.Add("ASSETCOST");
            dtAaf.Columns.Add("LeaseType");
            dtAaf.Columns.Add("ICBSCollateralCode");
            dtAaf.Columns.Add("AssetValue");
            dtAaf.Columns.Add("ApprovedAmount");
            dtAaf.Columns.Add("CPNumber");
            dtAaf.Columns.Add("LastPrincipalPay");
            dtAaf.Columns.Add("PrincipalPayDate");
            dtAaf.Columns.Add("LastInterestPay");
            dtAaf.Columns.Add("LastInterestPayDate");
            dtAaf.Columns.Add("PreviousMonthsNPLTaggingByRisk");
            dtAaf.Columns.Add("SpecificRequiredProvisions");
            dtAaf.Columns.Add("GeneralRequiredProvisions");

            return dtAaf;
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {

        }

        private void setRawFilePathToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPathMaintenance frmMaintenance = frmPathMaintenance.Instance();
            // frmMaintenance.TopMost = true;
            frmMaintenance.ShowDialog();
        }

        private void uSDollarExchangeRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExchangeRate frmExchange = frmExchangeRate.Instance();
            frmExchange.ShowDialog();
        }

        private void exportToExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void gLCodeAndDescriptionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ErrorLog newErr = new ErrorLog();
            //newErr.
            frmCorrespondingGL frmcorrespondingGL = frmCorrespondingGL.Instance();
            frmcorrespondingGL.ShowDialog();
        }

        private void qualifyingTableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmQualifyingCapital frmqualifyingCapital = frmQualifyingCapital.Instance();
            frmqualifyingCapital.ShowDialog();
        }

        private void accountUnderLitigationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ErrorLog newErr = new ErrorLog();
            frmUnderLitigation frmunderLitigation = frmUnderLitigation.Instance();
            frmunderLitigation.ShowDialog();
        }

        private void nTCConsolidatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NTCColumnNames();

            dtExport = consolidatorRepository.GetAll(NTC_DateTime, "", false).ToDataTable();

            dtExport.Columns.Remove("TransID");
            dtExport.Columns.Remove("RawFiles");
            dtExport.Columns.Remove("isConsolidated");
            dtExport.Columns.Remove("isDeleted");
            dtExport.Columns.Remove("UserName");
            dtExport.Columns.Remove("TransDate");
            dtExport.Columns.Remove("Reason");
            dtExport.Columns.Remove("RecordDate");

            SaveFileDialog diag = new SaveFileDialog();
            diag.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            //diag.Filter = "All files (*.*)|*.*";
            diag.FilterIndex = 0;
            diag.RestoreDirectory = true;
            //  diag.CreatePrompt = true;
            diag.Title = "Export NTC Consolidator To Excel File";

            if (dtExport.Rows.Count > 0)
            {
                if (diag.ShowDialog() == DialogResult.OK)
                {
                    ExportFilename = diag.FileName;


                    //  ExportWorker
                    pnlWaitInfo.Visible = true;
                    ExportWorker = new BackgroundWorker();
                    ExportWorker.WorkerReportsProgress = true;
                    ExportWorker.DoWork += new DoWorkEventHandler(ExportWorker_DoWork);
                    ExportWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(ExportWorker_RunWorkerCompleted);
                    ExportWorker.ProgressChanged += new ProgressChangedEventHandler(ExportWorker_ProgressChanged);
                    ExportWorker.RunWorkerAsync();
                }
            }
        }

        #region Export BGWorker
        private void ExportWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Fetching record, Please wait..."; //header text
            lblWaitStatus.Text = "Status: Exporting is in progress...";
        }

        private void ExportWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                IsBusy = false;
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "Error";
                lblWaitStatus.Text = "Status: Error Encountered while exporting";

                MetroMessageBox.Show(this, "Error Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while Exporting the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                pnlWaitInfo.Visible = false;
                MetroMessageBox.Show(this, "\r\n" + Path.GetFileName(ExportFilename) + " was successfully generated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void ExportWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                frmReportViewer rpt = new frmReportViewer();
                rpt.ShowDialog();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion

        private void exportToExcelToolStripMenuItem_Click_1(object sender, EventArgs e)
        { }

        private DataTable NTCColumnNames()
        {
            dtExport = new DataTable("dtExport");
            dtExport.Columns.Add("TransID", typeof(int));
            dtExport.Columns.Add("RawFiles", typeof(String));
            dtExport.Columns.Add("isConsolidated", typeof(bool));
            dtExport.Columns.Add("isDeleted", typeof(bool));
            dtExport.Columns.Add("UserName", typeof(String));
            dtExport.Columns.Add("TransDate", typeof(DateTime));
            dtExport.Columns.Add("RecordDate", typeof(DateTime));
            dtExport.Columns.Add("SYSTEM", typeof(String));
            dtExport.Columns.Add("AccountNo", typeof(String));
            dtExport.Columns.Add("ClientName", typeof(String));
            dtExport.Columns.Add("AO", typeof(String));
            dtExport.Columns.Add("FacilityCode", typeof(String));
            dtExport.Columns.Add("StatusPerSystem", typeof(String));
            dtExport.Columns.Add("ValueDate", typeof(DateTime));
            dtExport.Columns.Add("FirstDueDate", typeof(DateTime));
            dtExport.Columns.Add("MaturityDate", typeof(DateTime));
            dtExport.Columns.Add("TotalLoan", typeof(decimal));
            dtExport.Columns.Add("OB", typeof(decimal));
            dtExport.Columns.Add("MonthlyOB", typeof(decimal));
            dtExport.Columns.Add("UDIBalance", typeof(decimal));
            dtExport.Columns.Add("ClientsEquity", typeof(decimal));
            dtExport.Columns.Add("AccruedInterestReceivable", typeof(decimal));
            dtExport.Columns.Add("OrigERV", typeof(decimal));
            dtExport.Columns.Add("PVRV", typeof(decimal));
            dtExport.Columns.Add("OrigGD", typeof(decimal));
            dtExport.Columns.Add("PVGD", typeof(decimal));
            dtExport.Columns.Add("TotalLoanPortfolio", typeof(decimal));
            dtExport.Columns.Add("NTC", typeof(String));
            dtExport.Columns.Add("OriginalRate", typeof(String));
            dtExport.Columns.Add("CurrentRate", typeof(String));
            dtExport.Columns.Add("TermInMonths", typeof(int));
            dtExport.Columns.Add("RemainingTermInMonths", typeof(int));
            dtExport.Columns.Add("OriginalAmortizationAAF", typeof(String));
            dtExport.Columns.Add("PaymentScheduleAmortizationAAF", typeof(decimal));
            dtExport.Columns.Add("RepricedDate", typeof(DateTime));
            dtExport.Columns.Add("AAFICBSRateType", typeof(String));
            dtExport.Columns.Add("RepricedAmortization", typeof(decimal));
            dtExport.Columns.Add("PastDueDateITLDateExtractedPerAAFICBS", typeof(String));
            dtExport.Columns.Add("PerFaMSAAFICBSIndustryCode", typeof(String));
            dtExport.Columns.Add("IndustryHeader", typeof(String));
            dtExport.Columns.Add("IndustryDetail", typeof(String));
            dtExport.Columns.Add("Collateral", typeof(String));
            dtExport.Columns.Add("PerFaMSAAFICBSAssetSize", typeof(String));
            dtExport.Columns.Add("PerFaMSAAFICBSAssetSizeInWords", typeof(String));
            dtExport.Columns.Add("ICBSGLCode", typeof(String));
            dtExport.Columns.Add("ICBSGLName", typeof(String));
            dtExport.Columns.Add("CostCenter", typeof(String));
            dtExport.Columns.Add("BranchNameOfCostCenterPerSystem", typeof(String));
            dtExport.Columns.Add("StatusPerGL", typeof(String));
            dtExport.Columns.Add("OriginatingBranchBooked", typeof(String));
            dtExport.Columns.Add("NationalityPerICBS", typeof(String));
            dtExport.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS", typeof(DateTime));
            dtExport.Columns.Add("TaxID", typeof(String));
            dtExport.Columns.Add("LoanPurposeCode", typeof(String));
            dtExport.Columns.Add("MaturityTypeCode", typeof(String));
            dtExport.Columns.Add("BankRelationship", typeof(String));
            dtExport.Columns.Add("SyndicatedLoanInd", typeof(String));
            dtExport.Columns.Add("CustomerTypeDescription", typeof(String));
            dtExport.Columns.Add("RELCode", typeof(String));
            dtExport.Columns.Add("REECode", typeof(String));
            dtExport.Columns.Add("REEAddtlInfo", typeof(String));
            dtExport.Columns.Add("AcctRef", typeof(String));
            dtExport.Columns.Add("RPT", typeof(String));
            dtExport.Columns.Add("ASSETCOST", typeof(decimal));
            dtExport.Columns.Add("LeaseType", typeof(String));
            dtExport.Columns.Add("Provisioning", typeof(String));
            dtExport.Columns.Add("Matrix", typeof(String));
            dtExport.Columns.Add("Remarks", typeof(String));
            dtExport.Columns.Add("ICBSCollateralCode", typeof(String));
            dtExport.Columns.Add("AssetValue", typeof(decimal));
            dtExport.Columns.Add("ApprovedAmount", typeof(decimal));
            dtExport.Columns.Add("CPNumber", typeof(String));
            dtExport.Columns.Add("LastPrincipalPay", typeof(Int64));
            dtExport.Columns.Add("PrincipalPayDate", typeof(DateTime));
            dtExport.Columns.Add("LastInterestPay", typeof(decimal));
            dtExport.Columns.Add("LastInterestPayDate", typeof(DateTime));
            dtExport.Columns.Add("PreviousMonthsNPLTaggingByRisk", typeof(String));
            dtExport.Columns.Add("SpecificRequiredProvisions", typeof(String));
            dtExport.Columns.Add("GeneralRequiredProvisions", typeof(String));
            dtExport.Columns.Add("Reason", typeof(String));

            return dtExport;

        }

        private void aAFMigratedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ErrorLog newErr = new ErrorLog();
            frmMigratedAccount frmmigratedAccount = frmMigratedAccount.Instance();
            frmmigratedAccount.ShowDialog();
        }

        private void faMSPastDueAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ErrorLog newErr = new ErrorLog();
            frmPastDue frmpastDue = frmPastDue.Instance();
            frmpastDue.ShowDialog();
        }

        private void dailyGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ErrorLog newErr = new ErrorLog();
            frmDailyGL frmdailyGL = frmDailyGL.Instance();
            frmdailyGL.ShowDialog();
        }

        private DataTable LoadGLData()
        {
            dtGLCODE = new DataTable();
            dtGLCODE = correspondingGLRepository.GetGL().ToDataTable();
            return dtGLCODE;
        }

        private DataTable LoadQualifyingTable()
        {
            dtQTable = new DataTable();
            dtQTable = qualifyingCapitalRepository.GetAllForTheMonth().ToDataTable();
            return dtQTable;
        }

        private void nTCReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReportViewer rpt = new frmReportViewer();
            rpt.ShowDialog();
        }

        private void aPLFromRiskToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ErrorLog newErr = new ErrorLog();
            frmAPLAccount apl = new frmAPLAccount();
            apl.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //btnHideShowProccess.Visible = true;
            pnlWaitInfo.Visible = false;
        }

        private void btnHideShowProccess_Click(object sender, EventArgs e)
        {
            //btnHideShowProccess.Visible = false;
            pnlWaitInfo.Visible = true;
        }

        private void ConsoMenu_MouseClick(object sender, MouseEventArgs e)
        {
            if (IsBusy)
            {
                lblBusy.Text = "Busy processing, Please wait...";
                return;
            }
        }

        private void btnSearch_MouseClick(object sender, MouseEventArgs e)
        {
            if (IsBusy)
            {
                lblBusy.Text = "Busy processing, Please wait...";
                return;
            }
        }

        private void lnkExcelTemplate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                var retVal = DownloadExcelTemplate.DownloadTemplate("NTC Consolidator");

                if (retVal == 1)
                {
                    MetroMessageBox.Show(this, "\r\nNTC Consolidator excel Template was successfully downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "Error Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while downloading the template, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void dgvConsolidator_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                var retVal = DownloadExcelTemplate.DownloadTemplate("Dollar Rate And Dollar Accounts");

                if (retVal == 1)
                {
                    MetroMessageBox.Show(this, "\r\nDollar Rate And Dollar Accounts excel Template was successfully downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "Error Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while downloading the template, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void downloadTemplateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExcelTemplate frmexcelTemplate = frmExcelTemplate.Instance();
            // frmMaintenance.TopMost = true;
            frmexcelTemplate.ShowDialog();
        }
    }

    #region "Override MenuStrip Border"
    public class CustomColorTable : ProfessionalColorTable
    {
        public override Color MenuItemBorder
        {
            get { return Color.White; }
        }
    }
    #endregion
}

