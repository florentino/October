﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmPastDue : MetroFramework.Forms.MetroForm
    {
        #region Properties
        private static frmPastDue frmpastDue = null;
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtPastDueAccount;
        string pastDueAccountFileName = "";
        NumberStyles styles;
        DateTime dateparam;
        string[] progressArray = new string[5];
        bool isNoData = false;
        private IPastDueAccount pastDueAccountRepository;

        #endregion

        public static frmPastDue Instance()
        {
            if (frmpastDue == null)
            {
                frmpastDue = new frmPastDue();
            }
            return frmpastDue;
        }

        public frmPastDue()
        {
            InitializeComponent();
            this.pastDueAccountRepository = new PastDueAccountRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));

            pnlWaitInfo.Location = new Point(
           this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;
            lblBusy.Text = "";
        }

        private void frmPastDue_Load(object sender, EventArgs e)
        {
            dtPastDueAccount = new DataTable();
            btnExecute.Enabled = dtPastDueAccount.Rows.Count > 0 ? true : false;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Please wait, While loading excel file.";
            lblWaitStatus.Text = "Status: Processing...";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlWaitInfo.Visible = true;

                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }
        }

        #region Retrieving records
        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (isNoData)
                {
                    isNoData = false;
                    MetroMessageBox.Show(this, "\r\n\r\nPast Due excel files contains no data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                //if (_InValidDate)
                //{
                //    MetroMessageBox.Show(this, "\r\nInvalid date was detected by the system, Please check all the date format.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //}
                //else
                //{
                //    MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //}
                return;
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                lblWaitStatus.Text = "Status: Error Encountered while processing";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("External table is not in the expected format"))
                {
                    MetroMessageBox.Show(this, "\r\nPlease save first the file with the extension name of \".xls\".\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "Error Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while reading the files, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else
            {
                if (ErrorLog.CountError() > 0)
                {
                    retrieveWorker.Dispose();

                    DialogResult diag = MetroMessageBox.Show(this, "\r\nValidation Error has been completed. " + ErrorLog.CountError().ToString() + " Error(s) found. Kindly review the errors log. \r\nClick OK Button to open the Notepad.", "Error Found", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    if (diag == DialogResult.OK)
                    {
                        ErrorLog.GetLogFilePath();
                    }
                    return;
                }
                else
                {
                    pastDueAccountFileName = Path.GetFileName(txtFilePath.Text);

                    //dtPastDueAccount.DefaultView.RowFilter = "SYSTEM = 'FAMS' AND statuspersystem = 'PAST DUE'";
                    DataView dv = dtPastDueAccount.DefaultView;
                    dv.Sort = "SYSTEM asc";
                    DataTable sortedDT = dv.ToTable();

                    dgvPastDueAccount.DataSource = sortedDT;

                    lblInfo.Text = "Total Records: " + string.Format("{0:n0}", dtPastDueAccount.Rows.Count);

                    pnlWaitInfo.Visible = false;
                    btnExecute.Enabled = dtPastDueAccount.Rows.Count > 0 ? true : false;
                }
            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string connString = "";

                if (Path.GetExtension(txtFilePath.Text) == ".xls")
                    connString = string.Format("Provider = Microsoft.Jet.OLEDB.4.0;Data Source={0};" + "Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);

                if (Path.GetExtension(txtFilePath.Text) == ".xlsx")
                {
                    MetroMessageBox.Show(this, "\r\nPlease change the file format from XLSX to XLS.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM[" + worksheetname + "] WHERE [F1] <> ''", conn);
                    DataTable dtold = new DataTable(worksheetname);
                    da.Fill(dtold);

                    if (dtold.Rows.Count <= 0)
                    {
                        if (retrieveWorker.IsBusy)
                        {
                            isNoData = true;
                            e.Cancel = true;
                            retrieveWorker.CancelAsync();
                        }
                    }
                    else
                    {
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);
                        dtold.Rows.RemoveAt(0);

                        progressArray[0] = (1 * 100 / dtold.Rows.Count).ToString(); // percent
                        progressArray[1] = "Loading records, Please wait..."; //header text
                        progressArray[2] = "Status: In-progress"; //Status
                        progressArray[3] = "";// i.ToString(); //column
                        progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                        retrieveWorker.ReportProgress(1 * 100 / dtold.Rows.Count, progressArray); // wla lng, just to show the loading information

                        foreach (DataColumn dc in dtold.Columns)
                        {
                            var name = dtold.Rows[0][dc].ToString().Trim().ToUpper();
                            // var newname = Regex.Replace(name, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToUpper();
                            dc.ColumnName = name;
                        }

                        dtold.Rows.RemoveAt(0);

                        dtPastDueAccount = dtold;

                        var invalidExcel = false;
                        var requiredColumns = new HashSet<string>
                        {
                           #region Column Name For NTC
                            "SYSTEM",
                            "ACCOUNT NO",
                            "CLIENT NAME",
                            "AO",
                            "FACILITY CODE",
                            "STATUS PER SYSTEM",
                            "VALUE DATE",
                            "FIRST DUE DATE",
                            "MATURITY DATE",
                            "TOTAL LOAN",
                            "OB",
                            "MONTHLY OB",
                            "UDI BALANCE",
                            "CLIENTS EQUITY",
                            "ACCRUED INTEREST RECEIVABLE",
                            "ORIG ERV",
                            "PVRV",
                            "PVGD",
                            "ORIG GD",
                            "TOTAL LOAN PORTFOLIO",
                            "NTC",
                            "ORIGINAL RATE",
                            "CURRENT RATE",
                            "TERM IN MONTHS",
                            "REMAINING TERM IN MONTHS",
                            "ORIGINAL AMORTIZATION AAF",
                            "PAYMENT SCHEDULE AMORTIZATION AAF",
                            "REPRICED DATE",
                            "AAFICBSRATE TYPE",
                            "REPRICED AMORTIZATION",
                            "PAST DUE DATE ITLDATE EXTRACTED PER AAFICBS",
                            "PER FAMS AAF ICBS INDUSTRY CODE",
                            "INDUSTRY HEADER",
                            "INDUSTRY DETAIL",
                            "COLLATERAL",
                            "PER FAMS AAF ICBS ASSET SIZE",
                            "PER FAMS AAF ICBS ASSET SIZE IN WORDS",
                            "ICBS GLCODE",
                            "ICBS GLNAME",
                            "COST CENTER",
                            "BRANCH NAME OF COST CENTER PER SYSTEM",
                            "STATUS PER GL",
                            "ORIGINATING BRANCH BOOKED",
                            "NATIONALITY PER ICBS",
                            "NEXT RATE REVIEW DATE EXTRACTED PER FAMS AAF ICBS",
                            "TAX ID",
                            "LOAN PURPOSE CODE",
                            "MATURITY TYPE CODE",
                            "BANK RELATIONSHIP",
                            "SYNDICATED LOAN IND",
                            "CUSTOMER TYPE DESCRIPTION",
                            "REL CODE",
                            "REE CODE",
                            "REE ADDTL INFO",
                            "ACCT REF",
                            "RPT",
                            "ASSET COST",
                            "LEASE TYPE",
                            "PROVISIONING",
                            "MATRIX",
                            "REMARKS",
                            "ICBS COLLATERAL CODE",
                            "ASSET VALUE",
                            "APPROVED AMOUNT",
                            "CP NUMBER",
                            "LAST PRINCIPAL PAY",
                            "PRINCIPAL PAY DATE",
                            "LAST INTEREST PAY",
                            "LAST INTEREST PAY DATE",
                            "PREVIOUS MONTHS NPL TAGGING BY RISK",
                            "SPECIFIC REQUIRED PROVISIONS",
                            "GENERAL REQUIRED PROVISIONS"

	#endregion
                        };
                        for (int i = 0; i < dtold.Columns.Count; i++)
                        {
                            string colname = dtold.Columns[i].ColumnName;
                            if (!requiredColumns.Contains(colname.Trim()))
                            {
                                invalidExcel = true;
                                ErrorLog.AddError(colname.Trim().ToUpper() + " column name is not found.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region Save PastDue
        private void btnExecute_Click(object sender, EventArgs e)
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Saving records, Please wait...";
            lblWaitStatus.Text = "Status: In-progress...";

            //Get Date
            dateparam = pastDueAccountRepository.GetDate();

            if (pastDueAccountRepository.GetRecord())
            {
                saveWorker = new BackgroundWorker();
                saveWorker.WorkerReportsProgress = true;
                saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
                saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
                saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
                saveWorker.WorkerSupportsCancellation = true;
                saveWorker.RunWorkerAsync();
            }
            else
            {
                MetroMessageBox.Show(this, "\r\n\r\nPlease consolidate the record first, before you procceed this proccess.", "Invalid Process", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                var iCount = 1;
                foreach (DataRow dritem in dtPastDueAccount.Rows)
                {
                    try
                    {
                        BDOLF_Consolidator data = new BDOLF_Consolidator();

                        #region Data
                        progressArray[0] = (iCount * 100 / dtPastDueAccount.Rows.Count).ToString(); // percent
                        progressArray[1] = "Saving records, Please wait..."; //header text
                        progressArray[2] = "Status: In-progress"; //Status
                        progressArray[3] = "";// i.ToString(); //column
                        progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                        data.RawFiles = pastDueAccountFileName.ToString().Trim();
                        data.isConsolidated = true;
                        data.isDeleted = false;
                        data.UserName = frmConsolidator.UserName;
                        data.TransDate = DateTime.Today;
                        data.RecordDate = dateparam; // Convert.ToDateTime(dritem["VALUEDATE"] == null ? "" : dritem["VALUEDATE"]);
                        data.SYSTEM = dritem["SYSTEM"] == null ? "" : dritem["SYSTEM"].ToString().Trim();
                        data.AccountNo = dritem["Account No"] == null ? "" : dritem["Account No"].ToString().Trim();
                        data.ClientName = dritem["Client Name"] == null ? "" : dritem["Client Name"].ToString().Trim();
                        data.AO = dritem["AO"] == null ? "" : dritem["AO"].ToString();
                        data.FacilityCode = dritem["Facility Code"] == null ? "" : dritem["Facility Code"].ToString().Trim();
                        data.StatusPerSystem = dritem["Status Per System"] == null ? "" : dritem["Status Per System"].ToString().Trim();
                        data.ValueDate = dritem["Value Date"].ToString().Trim() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["Value Date"]);
                        data.FirstDueDate = dritem["First Due Date"].ToString().Trim() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["First Due Date"]);
                        data.MaturityDate = dritem["Maturity Date"].ToString().Trim() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["Maturity Date"]);
                        data.TotalLoan = dritem["Total Loan"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Total Loan"]);
                        data.OB = dritem["OB"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["OB"]);
                        data.MonthlyOB = dritem["Monthly OB"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Monthly OB"]);
                        data.UDIBalance = dritem["UDI Balance"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["UDI Balance"]);
                        data.ClientsEquity = dritem["Clients Equity"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Clients Equity"]);
                        data.AccruedInterestReceivable = dritem["Accrued Interest Receivable"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Accrued Interest Receivable"]);
                        data.OrigERV = dritem["Orig ERV"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Orig ERV"]);
                        data.PVRV = dritem["PVRV"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["PVRV"]);
                        data.OrigGD = dritem["Orig GD"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Orig GD"]);
                        data.PVGD = dritem["PVGD"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["PVGD"]);
                        data.TotalLoanPortfolio = dritem["Total Loan Portfolio"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Total Loan Portfolio"]);
                        data.NTC = dritem["NTC"].ToString().Trim() == "" ? "" : dritem["NTC"].ToString().Trim();
                        data.OriginalRate = dritem["Original Rate"].ToString().Trim();
                        data.CurrentRate = dritem["Current Rate"].ToString().Trim();
                        data.TermInMonths = dritem["Term in months"].ToString().Trim() == "" ? 0 : Convert.ToInt32(dritem["Term in months"]);
                        data.RemainingTermInMonths = dritem["Remaining Term in months"].ToString().Trim() == "" ? 0 : Convert.ToInt32(dritem["Remaining Term in months"]);
                        data.OriginalAmortizationAAF = dritem["Original Amortization AAF"].ToString().Trim();
                        data.PaymentScheduleAmortizationAAF = dritem["Payment Schedule Amortization AAF"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Payment Schedule Amortization AAF"]);
                        data.RepricedDate = dritem["Repriced Date"].ToString().Trim() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["Repriced Date"]);
                        data.AAFICBSRateType = dritem["AAFICBSRate Type"].ToString().Trim() == "" ? "" : dritem["AAFICBSRate Type"].ToString();
                        data.RepricedAmortization = dritem["Repriced Amortization"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Repriced Amortization"]);
                        data.PastDueDateITLDateExtractedPerAAFICBS = dritem["Past Due Date ITLDate Extracted Per AAFICBS"].ToString().Trim();
                        data.PerFaMSAAFICBSIndustryCode = dritem["Per FaMS AAF ICBS Industry Code"].ToString().Trim() == "" ? "" : dritem["Per FaMS AAF ICBS Industry Code"].ToString().Trim();
                        data.IndustryHeader = dritem["Industry Header"].ToString().Trim() == "" ? "" : dritem["Industry Header"].ToString().Trim();
                        data.IndustryDetail = dritem["Industry Detail"].ToString().Trim() == "" ? "" : dritem["Industry Detail"].ToString().Trim();
                        data.Collateral = dritem["COLLATERAL"].ToString().Trim() == "" ? "" : dritem["COLLATERAL"].ToString().Trim();
                        data.PerFaMSAAFICBSAssetSize = (dritem["Per FaMS AAF ICBS Asset Size"].ToString().Trim() == "00" || dritem["Per FaMS AAF ICBS Asset Size"].ToString().Trim() == "-" || dritem["Per FaMS AAF ICBS Asset Size"].ToString().Trim() == ".00") ? "0" : dritem["Per FaMS AAF ICBS Asset Size"].ToString().Trim();
                        data.PerFaMSAAFICBSAssetSizeInWords = dritem["Per FaMS AAF ICBS Asset Size In Words"].ToString().Trim() == "" ? "" : dritem["Per FaMS AAF ICBS Asset Size In Words"].ToString().Trim();
                        data.ICBSGLCode = dritem["ICBS GLCode"].ToString().Trim() == "" ? "" : dritem["ICBS GLCode"].ToString().Trim();
                        data.ICBSGLName = dritem["ICBS GLName"].ToString().Trim() == "" ? "" : dritem["ICBS GLName"].ToString().Trim();
                        data.CostCenter = dritem["Cost Center"].ToString().Trim() == "" ? "" : dritem["Cost Center"].ToString().Trim();
                        data.BranchNameOfCostCenterPerSystem = dritem["Branch Name Of Cost Center Per System"].ToString().Trim() == "" ? "" : dritem["Branch Name Of Cost Center Per System"].ToString().Trim();
                        data.StatusPerGL = dritem["Status Per GL"].ToString().Trim() == "" ? "" : dritem["Status Per GL"].ToString().Trim();
                        data.OriginatingBranchBooked = dritem["Originating Branch Booked"].ToString().Trim() == "" ? "" : dritem["Originating Branch Booked"].ToString().Trim();
                        data.NationalityPerICBS = dritem["Nationality Per ICBS"].ToString().Trim() == "" ? "" : dritem["Nationality Per ICBS"].ToString().Trim();
                        data.NextRateReviewDateExtractedPerFaMSAAFICBS = dritem["Next Rate Review Date Extracted Per FaMS AAF ICBS"].ToString().Trim() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["NEXTRATEREVIEWDATEEXTRACTEDPERFAMSAAFICBS"]);
                        data.TaxID = dritem["TAX ID"].ToString().Trim() == "" ? "" : dritem["TAX ID"].ToString().Trim();
                        data.LoanPurposeCode = dritem["Loan Purpose Code"].ToString().Trim() == "" ? "" : dritem["Loan Purpose Code"].ToString().Trim();
                        data.MaturityTypeCode = dritem["Maturity Type Code"].ToString().Trim() == "" ? "" : dritem["Maturity Type Code"].ToString().Trim();
                        data.BankRelationship = dritem["Bank Relationship"].ToString().Trim() == "" ? "" : dritem["Bank Relationship"].ToString().Trim();
                        data.SyndicatedLoanInd = dritem["Syndicated Loan Ind"].ToString().Trim() == "" ? "" : dritem["Syndicated Loan Ind"].ToString().Trim();
                        data.CustomerTypeDescription = dritem["Customer Type Description"].ToString().Trim() == "" ? "" : dritem["Customer Type Description"].ToString().Trim();
                        data.RELCode = dritem["REL Code"].ToString().Trim() == "" ? "" : dritem["REL Code"].ToString().Trim();
                        data.REECode = dritem["REE Code"].ToString().Trim() == "" ? "" : dritem["REE Code"].ToString().Trim();
                        data.REEAddtlInfo = dritem["REE Addtl Info"].ToString().Trim() == "" ? "" : dritem["REE Addtl Info"].ToString().Trim();
                        data.AcctRef = dritem["Acct Ref"].ToString().Trim() == "" ? "" : dritem["Acct Ref"].ToString().Trim();
                        data.RPT = dritem["RPT"].ToString().Trim() == "" ? "" : dritem["RPT"].ToString().Trim();
                        data.ASSETCOST = dritem["ASSET COST"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["ASSET COST"]);
                        data.LeaseType = dritem["Lease Type"].ToString().Trim() == "" ? "" : dritem["Lease Type"].ToString().Trim();
                        data.Provisioning = dritem["PROVISIONING"].ToString().Trim() == "" ? "" : dritem["PROVISIONING"].ToString().Trim();
                        data.Matrix = dritem["MATRIX"].ToString().Trim() == "" ? "" : dritem["MATRIX"].ToString().Trim();
                        data.Remarks = dritem["REMARKS"].ToString().Trim() == "" ? "" : dritem["REMARKS"].ToString().Trim();
                        data.ICBSCollateralCode = dritem["ICBS Collateral Code"].ToString().Trim() == "" ? "" : dritem["ICBS Collateral Code"].ToString().Trim();
                        data.AssetValue = dritem["Asset Value"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Asset Value"]);
                        data.ApprovedAmount = dritem["Approved Amount"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Approved Amount"]);
                        data.CPNumber = dritem["CP Number"].ToString().Trim() == "" ? "" : dritem["CP Number"].ToString().Trim();
                        data.LastInterestPay = dritem["Last Principal Pay"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Last Principal Pay"]);
                        data.PrincipalPayDate = dritem["Principal Pay Date"].ToString().Trim() == "" ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dritem["Principal Pay Date"]);
                        data.LastInterestPay = dritem["Last Interest Pay"].ToString().Trim() == "" ? 0M : Convert.ToDecimal(dritem["Last Interest Pay"]);
                        data.LastInterestPayDate = Convert.ToDateTime("01/01/1900");
                        data.PreviousMonthsNPLTaggingByRisk = dritem["Previous Months NPL Tagging By Risk"].ToString().Trim() == "" ? "" : dritem["Previous Months NPL Tagging By Risk"].ToString().Trim();
                        data.SpecificRequiredProvisions = dritem["Specific Required Provisions"].ToString().Trim() == "" ? "" : dritem["Specific Required Provisions"].ToString().Trim();
                        data.GeneralRequiredProvisions = dritem["General Required Provisions"].ToString().Trim() == "" ? "" : dritem["General Required Provisions"].ToString().Trim();
                        data.Reason = "";
                        #endregion

                        pastDueAccountRepository.InsertRecord(data);

                        saveWorker.ReportProgress(iCount++ * 100 / dtPastDueAccount.Rows.Count, progressArray); // wla lng

                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError(string.Format("Error found at row {0}. Error message: {2}", iCount.ToString(), ex.Message.ToString()));
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";


                lblWaitStatus.Text = "Status: Error Encountered while processing";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "Error Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while saving the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else
            {
                if (ErrorLog.CountError() > 0)
                {
                    retrieveWorker.Dispose();
                    saveWorker.Dispose();

                    DialogResult diag = MetroMessageBox.Show(this, "\r\nValidation Error has been completed. " + ErrorLog.CountError().ToString() + " Error(s) found. Kindly review the errors log. \r\nClick OK Button to open the Notepad.", "Error Found", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    if (diag == DialogResult.OK)
                    {
                        ErrorLog.GetLogFilePath();
                    }
                    return;
                }
                else
                {
                    pnlWaitInfo.Visible = false;
                    lblWaitInfo.Text = "DONE";
                    lblWaitStatus.Text = "Status: Success";

                    MetroMessageBox.Show(this, "\r\nPast Due Account was successfully appended.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitStatus.Text = labelsreports[2].ToString();
            lblWaitInfo.Text = labelsreports[1].ToString();
        }
        #endregion

        private void frmPastDue_FormClosing(object sender, FormClosingEventArgs e)
        {
            //frmConsolidator frmreload = new frmConsolidator();
            //frmreload.GetConsolidator();

            frmPastDue.frmpastDue = null;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                var retVal = DownloadExcelTemplate.DownloadTemplate("Past Due Account");

                if (retVal == 1)
                {
                    MetroMessageBox.Show(this, "\r\nPast Due excel Template was successfully downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "Error Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while downloading the template, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
