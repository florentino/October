﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmMigratedAccount : MetroFramework.Forms.MetroForm
    {
        #region Properties
        private static frmMigratedAccount frmmigratedAccount = null;
        private IMigratedAccount migratedAccountRepository;
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtmigratedAccount;
        DataTable dtRecords;
        DataTable dtAaf;
        DataTable dtupdated = new DataTable("Updated");
        DataTable dtinserted = new DataTable("Inserted");
        DataRow dru = null;
        DataRow dri = null;
        NumberStyles styles;
        string[] progressArray = new string[5];
        bool isNoData = false;

        #endregion

        //Singleton
        public static frmMigratedAccount Instance()
        {
            if (frmmigratedAccount == null)
            {
                frmmigratedAccount = new frmMigratedAccount();
            }
            return frmmigratedAccount;
        }

        public frmMigratedAccount()
        {
            InitializeComponent();
            this.migratedAccountRepository = new MigratedAccountRepository(new NTCConn(Helper.ConnectionStringChanger.BuildConnectionString()));

            pnlWaitInfo.Location = new Point(
           this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            pnlSummary.Location = new Point(
           this.ClientSize.Width / 2 - pnlSummary.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlSummary.Size.Height / 2);
            pnlSummary.Visible = false;

            pnlInsertUpdate.Location = new Point(
          this.ClientSize.Width / 2 - pnlInsertUpdate.Size.Width / 2,
          this.ClientSize.Height / 2 - pnlInsertUpdate.Size.Height / 2);
            pnlInsertUpdate.Visible = false;
            lblBusy.Text = "";

        }

        private void frmMigratedAccount_Load(object sender, EventArgs e)
        {
            #region Remove Negative(-) Amount inside the parentheses
            styles = NumberStyles.AllowParentheses | NumberStyles.AllowTrailingSign | NumberStyles.Float | NumberStyles.AllowThousands;
            #endregion
            dtmigratedAccount = new DataTable();
            btnExecute.Enabled = dtmigratedAccount.Rows.Count > 0 ? true : false;
        }
        
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Please wait, While loading excel file.";
            lblWaitStatus.Text = "Status: Processing...";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;
                pnlWaitInfo.Visible = true;
                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }
        }

        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                if (isNoData)
                {
                    isNoData = false;
                    MetroMessageBox.Show(this, "\r\n\r\nExcel File contains no data.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                return;
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (e.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.ToString().Contains("External table is not in the expected format"))
                {
                    MetroMessageBox.Show(this, "\r\nPlease save first the file with the extension name of \".xls\".\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "Error Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }

                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                if (ErrorLog.CountError() > 0)
                {
                    retrieveWorker.Dispose();

                    DialogResult diag = MetroMessageBox.Show(this, "\r\nValidation Error has been completed. " + ErrorLog.CountError().ToString() + " Error(s) found. Kindly review the errors log. \r\nClick OK Button to open the Notepad.", "Error Found", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    if (diag == DialogResult.OK)
                    {
                        ErrorLog.GetLogFilePath();
                    }
                    return;
                }
                else
                {

                    //dtFromNTCRecords.DefaultView.RowFilter = "SYSTEM <> 'ICBS'";
                    DataView dv = dtmigratedAccount.DefaultView;
                    dv.Sort = "Account No ASC";
                    DataTable sortedDT = dv.ToTable();

                    dgvAccountUnderLit.DataSource = sortedDT;
                    //dgvAccountUnderLit.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

                    //lblInfo.Text = "Total Records: " + dtFromNTCRecords.Rows.Count.ToString();
                    lblInfo.Text = "Total Records: " + string.Format("{0:n0}", dtmigratedAccount.Rows.Count);

                    //FaMSDataTable();
                    //AAFDataTable();

                    pnlWaitInfo.Visible = false;

                    btnExecute.Enabled = dtmigratedAccount.Rows.Count > 0 ? true : false;
                    //btnExecute.Enabled = dtFromNTCRecords.Rows.Count > 0 ? true : false;
                }

            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string connString = "";

                if (Path.GetExtension(txtFilePath.Text) == ".xls")
                    connString = string.Format("Provider = Microsoft.Jet.OLEDB.4.0;Data Source={0};" + "Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);

                if (Path.GetExtension(txtFilePath.Text) == ".xlsx")
                {
                    MetroMessageBox.Show(this, "\r\nPlease change the file format from XLSX to XLS.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                var invalidExcel = false;
                // string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();
                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM[" + worksheetname + "] WHERE[F1] <> ''", conn);
                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);

                    dtold.Rows.RemoveAt(0);
                    dtold.Rows.RemoveAt(0);
                    dtold.Rows.RemoveAt(0);
                    dtold.Rows.RemoveAt(0);

                    foreach (DataColumn dc in dtold.Columns)
                    {
                        if (!string.IsNullOrEmpty(dtold.Rows[0][dc].ToString()))
                        {
                            dc.ColumnName = dtold.Rows[0][dc].ToString();
                        }
                    }

                    dtold.Rows.RemoveAt(0);

                    if (dtold.Rows.Count <= 0)
                    {
                        if (retrieveWorker.IsBusy)
                        {
                            isNoData = true;
                            e.Cancel = true;
                            retrieveWorker.CancelAsync();
                            return;
                        }
                    }
                    DataView view = new System.Data.DataView(dtold);
                    DataTable selected = view.ToTable("Selected", false, "SYSTEM", "Account No", "UDI Balance", "PVGD", "PVRV");
                    dtmigratedAccount = selected;

                    var requiredColumns = new HashSet<string>
                    {"SYSTEM", "Account No", "UDI Balance", "PVGD", "PVRV" };

                    for (int i = 0; i < dtold.Columns.Count; i++)
                    {
                        string colname = dtold.Columns[i].ColumnName;
                        if (!requiredColumns.Contains(colname.Trim()))
                        {
                            ErrorLog.AddError(colname.Trim().ToUpper() + " column name is not found.");
                            invalidExcel = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            dtupdated = new DataTable("Updated");
            dtinserted = new DataTable("Inserted");

            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Initializing, Please wait...";
            lblWaitStatus.Text = "Status: Initializing...";

            ListItem();

            saveWorker = new BackgroundWorker();
            saveWorker.WorkerReportsProgress = true;
            saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
            saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
            saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
            saveWorker.WorkerSupportsCancellation = true;
            saveWorker.RunWorkerAsync();

        }

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitStatus.Text = labelsreports[2].ToString();
            lblWaitInfo.Text = labelsreports[1].ToString();
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                lblWaitStatus.Text = "Status: Error Encountered while processing";

                if (e.Error.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else if (e.Error.ToString().Contains("does not belong to table"))
                {
                    MetroMessageBox.Show(this, "\r\nInvalid excel template, To verify the excel format.\r\nPlease download the template.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "Error Message: " + e.Error.Message.ToString() + "\r\n\r\nError encountered while saving the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
            else
            {
                if (ErrorLog.CountError() > 0)
                {
                    retrieveWorker.Dispose();
                    saveWorker.Dispose();

                    DialogResult diag = MetroMessageBox.Show(this, "\r\nValidation Error has been completed. " + ErrorLog.CountError().ToString() + " Error(s) found. Kindly review the errors log. \r\nClick OK Button to open the Notepad.", "Error Found", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    if (diag == DialogResult.OK)
                    {
                        ErrorLog.GetLogFilePath();
                    }
                    return;
                }
                else
                {
                    pnlSummary.Visible = false;
                    pnlWaitInfo.Visible = false;
                    lblWaitInfo.Text = "DONE";
                    lblWaitStatus.Text = "Status: Success";

                    DialogResult responseMsg = MetroMessageBox.Show(this, "\r\nData was successfully Updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    if (responseMsg.Equals(DialogResult.OK))
                    {
                        pnlSummary.Visible = true;
                        lnkDetailsUpdated.Text = dtupdated.Rows.Count.ToString() + " out of " + dtmigratedAccount.Rows.Count + ".";
                        lnkDetailsInserted.Text = dtinserted.Rows.Count.ToString() + " out of " + dtmigratedAccount.Rows.Count + ".";
                    }
                }
            }
        }

        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                var iCount = 1;
                foreach (DataRow dritem in dtmigratedAccount.Rows)
                {
                    try
                    {
                        BDOLF_Consolidator data = new BDOLF_Consolidator();
                        
                        #region Data
                        progressArray[0] = (iCount * 100 / dtmigratedAccount.Rows.Count).ToString(); // percent
                        progressArray[1] = "Validating AccountNo, Please wait..."; //header text
                        progressArray[2] = "Status: Proccessing...";// Filtering AccountNo: " + dritem["AccountNo"].ToString(); //Status
                        progressArray[3] = "";// i.ToString(); //column
                        progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                        data.AccountNo = dritem["Account No"].ToString().Trim();

                        var amountUDIBalance = string.IsNullOrEmpty(dritem["UDI Balance"].ToString().Trim()) == true ? "0" : dritem["UDI Balance"].ToString().Trim();
                        data.UDIBalance = Convert.ToDecimal(GetOutputStramount(styles, amountUDIBalance).ToString("#,0.00"));

                        var amountPVRV = string.IsNullOrEmpty(dritem["PVRV"].ToString().Trim()) == true ? "0" : dritem["PVRV"].ToString().Trim();
                        data.PVRV = Convert.ToDecimal(GetOutputStramount(styles, amountPVRV).ToString("#,0.00"));

                        var amountPVGD = string.IsNullOrEmpty(dritem["PVGD"].ToString().Trim()) == true ? "0" : dritem["PVGD"].ToString().Trim();
                        data.PVGD = Convert.ToDecimal(GetOutputStramount(styles, amountPVGD).ToString("#,0.00"));

                        data.SYSTEM = "AAF";
                        #endregion

                        if (migratedAccountRepository.AccountNotExists(data.AccountNo, data.SYSTEM))
                        {
                            migratedAccountRepository.UpdateConsolidator(data);

                            dru = dtupdated.NewRow();
                            dru["AccountNo"] = data.AccountNo;
                            dru["UDIBalance"] = data.UDIBalance;
                            dru["PVGD"] = data.PVGD;
                            dru["PVRV"] = data.PVRV;
                            dtupdated.Rows.Add(dru);
                        }
                        else
                        {
                            dri = dtinserted.NewRow();
                            dri["AccountNo"] = data.AccountNo;
                            dri["UDIBalance"] = data.UDIBalance;
                            dri["PVGD"] = data.PVGD;
                            dri["PVRV"] = data.PVRV;
                            dtinserted.Rows.Add(dri);
                        }

                        saveWorker.ReportProgress(iCount++ * 100 / dtmigratedAccount.Rows.Count, progressArray); // wla lng
                    }
                    catch (Exception ex)
                    {
                        ErrorLog.AddError(string.Format("Error found at row {0}. Error message: {1}", iCount.ToString(), ex.Message.ToString()));
                        continue;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void ListItem()
        {
            dtupdated.Columns.Add("AccountNo");
            dtupdated.Columns.Add("UDIBalance");
            dtupdated.Columns.Add("PVGD");
            dtupdated.Columns.Add("PVRV");

            dtinserted.Columns.Add("AccountNo");
            dtinserted.Columns.Add("UDIBalance");
            dtinserted.Columns.Add("PVGD");
            dtinserted.Columns.Add("PVRV");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.pnlSummary.Visible = false;
        }

        private static decimal GetOutputStramount(NumberStyles styles, string amount)
        {
            var _amount = decimal.Parse(amount, styles).ToString("#,0.00;-#,0.00");
            return decimal.Parse(_amount);
        }

        private void btnpnlUpdateInsert_Click(object sender, EventArgs e)
        {
            this.pnlInsertUpdate.Visible = false;
            this.pnlSummary.Visible = true;
        }

        private void frmMigratedAccount_FormClosed(object sender, FormClosedEventArgs e)
        {
            //frmConsolidator frmreload = new frmConsolidator();
            //frmreload.GetConsolidator();

            frmMigratedAccount.frmmigratedAccount = null;
        }

        private void lnkDetailsUpdated_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            BindData();

            this.pnlSummary.Visible = false;
            this.pnlInsertUpdate.Visible = true;
        }

        private void BindData()
        {
            try
            {
                if (dtupdated.Rows.Count > 0)
                {
                    dgrViewUpdatedList.DataSource = dtupdated;
                }

                if (dtinserted.Rows.Count > 0)
                {
                    dgrViewInserted.DataSource = dtinserted;
                }
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "Error Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while loading the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void lnkDetailsInserted_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            BindData();
            this.pnlSummary.Visible = false;
            this.pnlInsertUpdate.Visible = true;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                var retVal = DownloadExcelTemplate.DownloadTemplate("Migrated Account");
                if (retVal == 1)
                {
                    MetroMessageBox.Show(this, "\r\nMigrated Account excel Template was successfully downloaded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "Error Message: " + ex.Message.ToString() + "\r\n\r\nError encountered while downloading the template, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
